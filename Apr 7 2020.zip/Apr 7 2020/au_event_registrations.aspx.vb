﻿
Partial Class au_event_registrations
    Inherits System.Web.UI.Page

End Class
