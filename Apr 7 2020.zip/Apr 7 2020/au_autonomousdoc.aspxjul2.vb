﻿
Partial Class faculty_au_autonomousdoc
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Dim colid As String
            Dim collegename As String
            Dim facultyid As String
            Try
                colid = Request.Cookies("colid").Value.ToString
            Catch ex As Exception
                Response.Redirect("facultylogin.aspx")
            End Try
            collegename = Request.Cookies("collegename").Value.ToString.Replace(" ", "")
            facultyid = Request.Cookies("nemployeeid").Value.ToString
            Dim type As String

            type = "Documents111"
            HyperLink17.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink18.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink18.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type


            type = "Documents131"
            HyperLink113.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink114.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink114.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            type = "Documents221"
            HyperLink115.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink116.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink116.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type


            type = "Documents231"
            HyperLink1.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink2.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink2.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            type = "Documents234"
            HyperLink3.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink4.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink4.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            type = "Documents253"
            HyperLink49.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink50.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink50.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type


            type = "Documents254"
            HyperLink5.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink6.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink6.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            type = "Documents255"
            HyperLink51.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink52.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink52.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type


            type = "Documents262"
            HyperLink7.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink8.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink8.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            type = "Documents331"
            HyperLink9.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink10.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink10.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type


            type = "Documents361"
            HyperLink11.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink12.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink12.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            type = "Documents411"
            HyperLink13.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink14.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink14.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            type = "Documents412"
            HyperLink15.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink16.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink16.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            type = "Documents431"
            HyperLink19.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink20.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink20.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            type = "Documents532"
            HyperLink21.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink22.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink22.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type


            type = "Documents621"
            HyperLink23.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink24.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink24.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            type = "Documents622"
            HyperLink25.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink26.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink26.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            type = "Documents624"
            HyperLink27.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink28.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink28.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            type = "Documents631"
            HyperLink29.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink30.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink30.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            type = "Documents635"
            HyperLink31.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink32.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink32.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            type = "Documents641"
            HyperLink33.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink34.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink34.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            type = "Documents651"
            HyperLink35.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink36.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink36.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            type = "Documents652"
            HyperLink37.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink38.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink38.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            type = "Documents712"
            HyperLink39.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink40.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink40.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            type = "Documents7114"
            HyperLink53.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink54.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink54.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type


            type = "Green Initiatives"
            HyperLink41.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink42.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink42.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            type = "Documents7118"
            HyperLink43.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink44.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink44.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            type = "Documents721"
            HyperLink45.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink46.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink46.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            type = "Documents731"
            HyperLink47.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink48.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink48.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type




        End If
    End Sub
End Class
