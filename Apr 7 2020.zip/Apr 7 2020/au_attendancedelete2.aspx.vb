﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class au_attendancedelete2
    Inherits System.Web.UI.Page
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try

        Dim fieldValues As List(Of Object) = ASPxGridView1.GetSelectedFieldValues(New String() {"Id"})

        If fieldValues.Count = 0 Then
            Label8.Text = "Please select atleast one data"
            Label8.ForeColor = Drawing.Color.Red
            Exit Sub
            Return
        Else
            For Each item As Object In fieldValues
                Dim str1 As String
                str1 = "Delete from nba_attendance where colid=" & colid & "and Id=" & item
                Dim cs1 As New schoolclass1
                cs1.insertdata(str1)
            Next
            ASPxGridView1.DataBind()
            Label8.Text = "Attendance Deleted Successfully"
            Label8.ForeColor = System.Drawing.Color.Green
        End If



    End Sub
End Class
