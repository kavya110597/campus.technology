﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Data.OleDb
Imports System.Drawing
Partial Class au_committeemembers
    Inherits System.Web.UI.Page
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        LSeminar.Text = ""
        If committee_rcb.SelectedItem Is Nothing OrElse [String].IsNullOrWhiteSpace(committee_rcb.SelectedItem.Text) Then
            LSeminar.Text = "Please select Committiee."
            LSeminar.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If type_rcb.SelectedItem Is Nothing OrElse [String].IsNullOrWhiteSpace(type_rcb.SelectedItem.Text) Then
            LSeminar.Text = "Please select member type."
            LSeminar.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If since_text.Text = "" OrElse to_text.Text = "" Then
            LSeminar.Text = "Please enter all details."
            LSeminar.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If IsDate(since_text.Text) = False OrElse IsDate(to_text.Text) = False Then
            LSeminar.Text = "Invalid Date."
            LSeminar.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        Dim startdate As Date = Convert.ToDateTime(since_text.Text)
        Dim enddate As Date = Convert.ToDateTime(to_text.Text)
        'If Format(startdate, "MM/DD/YYYY") > Format(enddate, "MM/DD/YYYY") Then
        '    LSeminar.Text = "Invalid Date."
        '    LSeminar.ForeColor = Drawing.Color.Red
        '    Exit Sub
        'End If

        If role_rcb.SelectedItem Is Nothing OrElse [String].IsNullOrWhiteSpace(role_rcb.SelectedItem.Text) Then
            LSeminar.Text = "Please select Role."
            LSeminar.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If type_rcb.SelectedValue.ToString = "Internal" Then
            If faculty_rcb.SelectedItem Is Nothing OrElse [String].IsNullOrWhiteSpace(faculty_rcb.SelectedItem.Text) Then
                LSeminar.Text = "Please select Faculty."
                LSeminar.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            addmember_sql.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
            addmember_sql.InsertParameters("empid").DefaultValue = Convert.ToInt32(faculty_rcb.SelectedValue.ToString)
            addmember_sql.InsertParameters("role").DefaultValue = role_rcb.SelectedValue.ToString
            addmember_sql.InsertParameters("sincedate").DefaultValue = Convert.ToDateTime(since_text.Text)
            addmember_sql.InsertParameters("todate").DefaultValue = Convert.ToDateTime(to_text.Text)
            addmember_sql.InsertParameters("committeeid").DefaultValue = Convert.ToInt32(committee_rcb.SelectedValue.ToString)
            addmember_sql.InsertParameters("membertype").DefaultValue = type_rcb.SelectedValue.ToString()
            'addmember_sql.InsertParameters("externalmembername").DefaultValue = "NA"
            addmember_sql.Insert()
            LSeminar.Text = "Member Added."
            LSeminar.ForeColor = Drawing.Color.Green
            ASPxGridView1.DataBind()

        ElseIf type_rcb.SelectedValue.ToString = "External" Then

            If ext_text.Text = "" Then
                LSeminar.Text = "Enter external member's name."
                LSeminar.ForeColor = Drawing.Color.Red
            End If
            addmember_sql.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
            addmember_sql.InsertParameters("empid").DefaultValue = 0
            addmember_sql.InsertParameters("role").DefaultValue = role_rcb.SelectedValue.ToString
            addmember_sql.InsertParameters("sincedate").DefaultValue = Convert.ToDateTime(since_text.Text)
            addmember_sql.InsertParameters("todate").DefaultValue = Convert.ToDateTime(to_text.Text)
            addmember_sql.InsertParameters("committeeid").DefaultValue = Convert.ToInt32(committee_rcb.SelectedValue.ToString)
            addmember_sql.InsertParameters("membertype").DefaultValue = type_rcb.SelectedValue.ToString()
            addmember_sql.InsertParameters("externalmembername").DefaultValue = ext_text.Text

            addmember_sql.Insert()
            LSeminar.Text = "Member Added."
            LSeminar.ForeColor = Drawing.Color.Green
            ASPxGridView1.DataBind()
        End If
    End Sub
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        'type_rcb.DataBind()
        If type_rcb.SelectedIndex = -1 Then
            faculty_rcb.Enabled = False
            ext_text.Enabled = False
        ElseIf type_rcb.SelectedValue.ToString = "Internal" Then
            faculty_rcb.Enabled = True
            ext_text.Enabled = False
        ElseIf type_rcb.SelectedValue.ToString = "External" Then
            faculty_rcb.Enabled = False
            ext_text.Enabled = True
        Else
            faculty_rcb.Enabled = False
            ext_text.Enabled = False
        End If
    End Sub
    Protected Sub type_rcb_SelectedIndexChanged(sender As Object, e As Telerik.Web.UI.RadComboBoxSelectedIndexChangedEventArgs) Handles type_rcb.SelectedIndexChanged
        If type_rcb.SelectedValue.ToString = "Internal" Then
            faculty_rcb.Enabled = True
            ext_text.Enabled = False
        ElseIf type_rcb.SelectedValue.ToString = "External" Then
            faculty_rcb.Enabled = False
            ext_text.Enabled = True
        Else
            faculty_rcb.Enabled = False
        ext_text.Enabled = False
        End If
    End Sub
End Class
