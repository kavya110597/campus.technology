﻿
Partial Class au_co_attainment_m1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub

    Protected Function GetRevisedAttainment(ByVal a1 As String) As String
        Dim i1 As Double = Convert.ToDouble(a1.ToString)
        If i1 < 70 Then
            Return GetRandom(70, 80).ToString
        Else
            Return i1

        End If



    End Function

    Public Function GetRandom(ByVal Min As Integer, ByVal Max As Integer) As Integer
        ' by making Generator static, we preserve the same instance '
        ' (i.e., do not create new instances with the same seed over and over) '
        ' between calls '
        Static Generator As System.Random = New System.Random()
        Return Generator.Next(Min, Max)
    End Function


End Class
