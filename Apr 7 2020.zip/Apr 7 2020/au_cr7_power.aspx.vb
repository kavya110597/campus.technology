﻿
Partial Class au_cr7_power
    Inherits System.Web.UI.Page

End Class
