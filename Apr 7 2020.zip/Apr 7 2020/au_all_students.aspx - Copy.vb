﻿Imports DevExpress.Web
Imports DevExpress.XtraPrinting
Partial Class au_all_students
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub
    Protected Sub Grid_ToolbarItemClick(ByVal source As Object, ByVal e As ASPxGridToolbarItemClickEventArgs) Handles ASPxGridView1.ToolbarItemClick
        ASPxGridViewExporter1.GridViewID = "ASPxGridView1"
        Select Case e.Item.Name
            Case "ExportToPDF"
                'ASPxGridViewExporter1.WritePdfToResponse()
                Dim options As New DevExpress.XtraPrinting.PdfExportOptions
                options.Compressed = False
                ASPxGridViewExporter1.WritePdfToResponse(options)
            Case "ExportToXLS"
                ASPxGridViewExporter1.WriteXlsToResponse()
            Case "ExportToXLSX"
                'ASPxGridViewExporter1.WriteXlsxToResponse()
                ASPxGridViewExporter1.WriteXlsxToResponse(New XlsxExportOptionsEx With {.ExportType = DevExpress.Export.ExportType.WYSIWYG})
            Case Else
        End Select
    End Sub
End Class
