﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class au_adm_login
    Inherits System.Web.UI.Page

    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.QueryString("colid").ToString)

        Catch ex As Exception
            Literal2.Text = "Invalid URL"
            Exit Sub
        End Try
        If TextBox3.Text = "" OrElse TextBox4.Text = "" OrElse TextBox5.Text = "" OrElse TextBox6.Text = "" OrElse TextBox7.Text = "" Then
            Literal2.Text = "All fields are required"
            Exit Sub
        End If
        SqlDataSource1.InsertParameters("colid").DefaultValue = colid
        SqlDataSource1.InsertParameters("name").DefaultValue = TextBox5.Text
        SqlDataSource1.InsertParameters("mob").DefaultValue = TextBox7.Text
        SqlDataSource1.InsertParameters("email").DefaultValue = TextBox6.Text
        SqlDataSource1.InsertParameters("login").DefaultValue = TextBox3.Text
        SqlDataSource1.InsertParameters("password").DefaultValue = TextBox4.Text
        SqlDataSource1.InsertParameters("category").DefaultValue = DropDownList1.SelectedValue.ToString
        SqlDataSource1.Insert()
        Literal2.Text = "Account created. Please login."
        TextBox7.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Dim colid As Integer
        colid = -1
        Dim nuserid As Integer = -1
        Dim nemployeeid As Integer = -1
        Dim name1 As String = ""
        Dim upic As String = ""
        Dim logo As String = ""
        Dim toptext As String = ""
        Dim nstudid As Double
        Dim programid As Integer
        Dim photos1 As String = ""
        colid = -1
        programid = -1
        Dim studid As Integer = -1

        Dim course As String = ""
        Dim batch As String = ""
        Dim semester As String = ""
        Dim section As String = ""
        Dim regno As String = ""
        Dim category As String = ""


        Using con1 As New SqlConnection
            con1.ConnectionString = ConfigurationManager.ConnectionStrings("constr1").ConnectionString 'constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            'cmd1.CommandText = "Select id,colid,employeeid,Name,upic from tableusers where login1=@login1 and Password=@password"
            'cmd1.CommandText = "Select id,colid,firstname,programid,course,batch,section,semester from AU_students where login=@login1 and password=@password"
            'cmd1.CommandText = "Select id,colid,firstname,programid,course,batch,section,semester from AU_students where login=@login1 and password=@password and status='" & status1 & "'"
            'cmd1.CommandText = "Select id,colid,firstname,programid,course,batch,section,semester,photos1,regno from AU_students where login=@login1 and password=@password and status='" & status1 & "'"
            'cmd1.CommandText = "Select id,colid,name,programid,course,batch,section,semester,photos1,regno from AU_students where login=@login1 and password=@password and status='" & status1 & "'"
            cmd1.CommandText = "Select id,colid,name from AU_students_adm where login=@login1 and password=@password"
            cmd1.CommandText = "Select id,colid,name,category from AU_students_adm where login=@login1 and password=@password"

            cmd1.Parameters.AddWithValue("@login1", TextBox1.Text).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@password", TextBox2.Text).DbType = DbType.String
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read

                colid = Convert.ToInt32(rdr1.GetValue(1).ToString)

                Try
                    nstudid = Convert.ToInt32(rdr1.GetValue(0).ToString)
                Catch ex As Exception

                End Try
                name1 = rdr1.GetValue(2).ToString
                category = rdr1.GetValue(3).ToString

                'photos1 = rdr1.GetValue(3).ToString


            Loop
            rdr1.Close()
            con1.Close()
        End Using

        Dim collegename As String
        Using con1 As New SqlConnection
            con1.ConnectionString = ConfigurationManager.ConnectionStrings("constr1").ConnectionString 'constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "select nameofcollege, logo from collegedetails where id=" & colid
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read

                collegename = rdr1.GetValue(0).ToString
                logo = rdr1.GetValue(1).ToString

            Loop
            rdr1.Close()
            con1.Close()
        End Using

        'Using con1 As New SqlConnection
        '    con1.ConnectionString = ConfigurationManager.ConnectionStrings("constr1").ConnectionString 'constr1
        '    con1.Open()
        '    Dim cmd1 As New SqlCommand
        '    cmd1.Connection = con1
        '    cmd1.CommandText = "select programs from nba_programs where id=" & programid
        '    Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
        '    Do While rdr1.Read

        '        course = rdr1.GetValue(0).ToString

        '    Loop
        '    rdr1.Close()
        '    con1.Close()
        'End Using

        'Dim dt1 As Date = DateTime.Now.Date.AddDays(-1)
        'Dim pstatus As String = ""
        'Using con1 As New SqlConnection
        '    con1.ConnectionString = ConfigurationManager.ConnectionStrings("constr1").ConnectionString 'constr1
        '    con1.Open()
        '    Dim cmd1 As New SqlCommand
        '    cmd1.Connection = con1
        '    cmd1.CommandText = "Select EndDate from au_col_pay where studid=" & nstudid & " and ProductCode=1"
        '    cmd1.CommandText = "Select DueDate, RegPayStatus from au_students where id=" & nstudid
        '    Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
        '    Do While rdr1.Read

        '        Try
        '            dt1 = Convert.ToDateTime(rdr1.GetValue(0).ToString)
        '        Catch ex As Exception

        '        End Try
        '        pstatus = rdr1.GetValue(1).ToString
        '    Loop
        '    rdr1.Close()
        '    con1.Close()
        'End Using

        'Dim paccess As String = ""
        'If dt1 < DateTime.Now Then
        '    paccess = "No"
        'Else
        '    paccess = "Yes"
        'End If



        If colid = -1 Then
            'Label1.Text = "Invalid username and password."
            'Page.ClientScript.RegisterStartupScript(Me.[GetType](), "Toast", "showAndroidToast('Invalid username and password!');", True)
            Literal1.Text = "Invalid username and password!"
            Exit Sub
        Else

            Dim cooki1 As New HttpCookie("colid")
            cooki1.Value = colid.ToString
            cooki1.Expires = DateTime.Now.AddMinutes(180)
            Dim cooki2 As New HttpCookie("nstudid")
            cooki2.Value = nstudid.ToString
            cooki2.Expires = DateTime.Now.AddMinutes(180)
            'Dim cooki3 As New HttpCookie("programid")
            'cooki3.Value = programid.ToString
            'cooki3.Expires = DateTime.Now.AddMinutes(180)
            Dim cooki4 As New HttpCookie("name")
            cooki4.Value = name1.ToString
            cooki4.Expires = DateTime.Now.AddMinutes(180)
            Dim cooki5 As New HttpCookie("category")
            cooki5.Value = category.ToString
            cooki5.Expires = DateTime.Now.AddMinutes(180)
            'Dim cooki5 As New HttpCookie("course")
            'cooki5.Value = course.ToString
            'cooki5.Expires = DateTime.Now.AddMinutes(180)
            'Dim cooki6 As New HttpCookie("batch")
            'cooki6.Value = batch.ToString
            'cooki6.Expires = DateTime.Now.AddMinutes(180)
            'Dim cooki8 As New HttpCookie("section")
            'cooki8.Value = section.ToString
            'cooki8.Expires = DateTime.Now.AddMinutes(180)
            'Dim cooki9 As New HttpCookie("semester")
            'cooki9.Value = semester.ToString
            'cooki9.Expires = DateTime.Now.AddMinutes(180)
            'Dim cooki10 As New HttpCookie("status")
            'cooki10.Value = RadComboBox1.SelectedValue.ToString
            'cooki10.Expires = DateTime.Now.AddMinutes(180)
            Dim cooki11 As New HttpCookie("collegename")
            cooki11.Value = collegename
            cooki11.Expires = DateTime.Now.AddMinutes(180)
            Dim cooki12 As New HttpCookie("logo")
            cooki12.Value = logo
            cooki12.Expires = DateTime.Now.AddMinutes(180)
            Dim cooki13 As New HttpCookie("photos1")
            cooki13.Value = photos1
            cooki13.Expires = DateTime.Now.AddMinutes(180)
            'Dim cooki14 As New HttpCookie("regno")
            'cooki14.Value = regno
            'cooki14.Expires = DateTime.Now.AddMinutes(180)
            'Dim cooki15 As New HttpCookie("paccess")
            'cooki15.Value = paccess
            'cooki15.Expires = DateTime.Now.AddMinutes(180)


            Response.Cookies.Add(cooki1)
            Response.Cookies.Add(cooki2)
            'Response.Cookies.Add(cooki3)
            Response.Cookies.Add(cooki4)
            Response.Cookies.Add(cooki5)
            'Response.Cookies.Add(cooki6)
            'Response.Cookies.Add(cooki8)
            'Response.Cookies.Add(cooki9)
            'Response.Cookies.Add(cooki10)
            Response.Cookies.Add(cooki11)
            Response.Cookies.Add(cooki12)
            Response.Cookies.Add(cooki13)
            'Response.Cookies.Add(cooki14)
            'Response.Cookies.Add(cooki15)

            Response.Redirect("k_adm_student.aspx")


            'Response.Redirect("attendance_dashboardm1.aspx?colid=" & colid & "&nemployeeid=" & nemployeeid)
            'If status1 = "Alumni" Then
            '    Response.Redirect("au_mob_a_dashboard.aspx")
            'Else
            '    'Response.Redirect("au_mob_dashboard_t1.aspx")
            '    'Response.Redirect("au_mob_landing_1.aspx")
            '    Response.Redirect("au_mob_landing_21.aspx")
            'End If


        End If
    End Sub
End Class
