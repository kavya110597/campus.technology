﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class au_att_periods_any
    Inherits System.Web.UI.Page

    Dim classid As Integer
    'Protected Sub RadButton1_Click(sender As Object, e As EventArgs) Handles RadButton1.Click

    '    'Literal1.Text = RadDateTimePicker1.SelectedDate & "<br>" & RadDateTimePicker2.SelectedDate & "<br>" & DateDiff(DateInterval.Hour, RadDateTimePicker1.SelectedDate, RadDateTimePicker2.SelectedDate).ToString
    '    'If Convert.ToDouble(DateDiff(DateInterval.Hour, RadDateTimePicker1.SelectedDate, RadDateTimePicker2.SelectedDate)) > 3 Then
    '    '    Literal1.Text = Literal1.Text & "<br> Invalid selection."
    '    'End If
    '    Literal1.Text = ""
    '    Dim classexists As Boolean = False
    '    Dim classid As Integer

    '    Dim colid As Integer
    '    Try
    '        colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
    '    Catch ex As Exception
    '        Response.Redirect("facultylogin.aspx")
    '    End Try
    '    Dim classgid As Integer
    '    If RadComboBox1.SelectedIndex = -1 Then
    '        Literal1.Text = "Please select MyClass."
    '        Exit Sub
    '    End If
    '    classgid = Convert.ToInt32(RadComboBox1.SelectedValue.ToString)
    '    Dim constr1 As String
    '    constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
    '    Using con1 As New SqlConnection
    '        con1.ConnectionString = constr1
    '        con1.Open()
    '        Dim cmd1 As New SqlCommand
    '        cmd1.Connection = con1

    '        Dim starttime1 As DateTime = Convert.ToDateTime(RadDateTimePicker1.SelectedDate)
    '        Dim endtime1 As DateTime = Convert.ToDateTime(RadDateTimePicker1.SelectedDate).AddMinutes(Convert.ToDouble(RadNumericTextBox1.Text))
    '        cmd1.CommandText = "Select id From au_periods where starttime='" & starttime1 & "' and endtime='" & endtime1 & "' and classgid=" & classgid
    '        Dim rdr1 As SqlDataReader = cmd1.ExecuteReader


    '        Do While rdr1.Read
    '            classexists = True
    '            classid = Convert.ToInt32(rdr1.GetValue(0).ToString)
    '        Loop
    '        rdr1.Close()
    '        con1.Close()
    '    End Using
    '    SqlDataSource4.SelectParameters("classgid").DefaultValue = classgid
    '    SqlDataSource4.SelectParameters("classid").DefaultValue = classid
    '    RadGrid3.DataBind()

    '    SqlDataSource7.SelectParameters("classgid").DefaultValue = classgid
    '    SqlDataSource7.SelectParameters("classid").DefaultValue = classid
    '    ASPxGridView2.DataBind()
    'End Sub
    Public Sub createclass()
        Literal1.Text = ""
        Dim classexists As Boolean = False
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        Dim classgid As Integer
        If RadComboBox1.SelectedIndex = -1 Then
            Literal1.Text = "Please select MyClass."
            Exit Sub
        End If
        classgid = Convert.ToInt32(RadComboBox1.SelectedValue.ToString)
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Dim programid, courseid, empid As Integer
        Dim batch, semester, section, group1, coursename As String
        Dim sh, sm, sd As Integer
        If DropDownList1.SelectedIndex = -1 Then
            Literal1.Text = "Please select periods."
            Exit Sub
        End If
        'empid = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
        empid = Convert.ToInt32(DropDownList2.SelectedValue.ToString)
        Dim starttime1 As DateTime
        Dim endtime1 As DateTime
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "Select progid, courseid, batch, semester, section, group1 from au_assign_fac where id=" & classgid

            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                programid = Convert.ToInt32(rdr1.GetValue(0).ToString)
                courseid = Convert.ToInt32(rdr1.GetValue(1).ToString)
                batch = rdr1.GetValue(2).ToString
                semester = rdr1.GetValue(3).ToString
                section = rdr1.GetValue(4).ToString
                group1 = rdr1.GetValue(5).ToString

            Loop
            rdr1.Close()

            Dim periodid As Integer = Convert.ToInt32(DropDownList1.SelectedValue.ToString)
            cmd1.CommandText = "Select StartHour,StartMinutes,DurationInMinutes from au_periods_conf where id=" & periodid


            rdr1 = cmd1.ExecuteReader
            Do While rdr1.Read
                Try
                    sh = Convert.ToDouble(rdr1.GetValue(0).ToString)
                    sm = Convert.ToDouble(rdr1.GetValue(1).ToString)
                    sd = Convert.ToDouble(rdr1.GetValue(2).ToString)
                Catch ex As Exception
                    Literal1.Text = "Invalid configuration."
                    Exit Sub
                End Try

            Loop
            rdr1.Close()




            cmd1.CommandText = "Select coursename from nba_course where id=" & courseid

            rdr1 = cmd1.ExecuteReader
            Do While rdr1.Read
                coursename = rdr1.GetValue(0).ToString
            Loop
            rdr1.Close()
            'Dim starttime1 As DateTime = Convert.ToDateTime(RadDateTimePicker1.SelectedDate)
            'Dim endtime1 As DateTime = Convert.ToDateTime(RadDateTimePicker1.SelectedDate).AddMinutes(Convert.ToDouble(RadNumericTextBox1.Text))

            starttime1 = Convert.ToDateTime(TextBox1.Text)

            'starttime1 = Now.AddHours(10.5).AddHours(sh).AddMinutes(sm)
            starttime1 = starttime1.AddHours(sh).AddMinutes(sm)
            endtime1 = starttime1.AddMinutes(sd)

            cmd1.CommandText = "Select id From au_periods where starttime='" & starttime1 & "' and endtime='" & endtime1 & "' and classgid=" & classgid
            rdr1 = cmd1.ExecuteReader
            Do While rdr1.Read
                classexists = True
            Loop
            rdr1.Close()

            con1.Close()
        End Using
        If classexists Then
            Literal1.Text = "Attendance already taken."
            Exit Sub
        End If
        SqlDataSource3.InsertParameters("courseid").DefaultValue = courseid
        SqlDataSource3.InsertParameters("programid").DefaultValue = programid
        SqlDataSource3.InsertParameters("starttime").DefaultValue = starttime1 ' Convert.ToDateTime(RadDateTimePicker1.SelectedDate)
        SqlDataSource3.InsertParameters("endtime").DefaultValue = endtime1 ' Convert.ToDateTime(RadDateTimePicker1.SelectedDate).AddMinutes(Convert.ToDouble(RadNumericTextBox1.Text))
        SqlDataSource3.InsertParameters("Subject").DefaultValue = coursename
        SqlDataSource3.InsertParameters("batchname").DefaultValue = batch
        SqlDataSource3.InsertParameters("semester").DefaultValue = semester
        SqlDataSource3.InsertParameters("section1").DefaultValue = section
        SqlDataSource3.InsertParameters("group1").DefaultValue = group1
        SqlDataSource3.InsertParameters("classgid").DefaultValue = classgid
        SqlDataSource3.Insert()

        Dim fieldValues As List(Of Object) = ASPxGridView1.GetSelectedFieldValues(New String() {"id"})
        Dim i As Integer = 0
        For Each item As Object In fieldValues
            'Dim str1 As String
            'str1 = "Update activity_pub set approvestatus='Approved' where colid=" & colid & "and Id=" & item
            'str1 = "Update au_client_te set status='Approved' where colid=" & colid & "and Id=" & item

            'sendsmsstud(item, ASPxTextBox1.Text)
            SqlDataSource6.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
            SqlDataSource6.InsertParameters("classid").DefaultValue = classid
            SqlDataSource6.InsertParameters("programid").DefaultValue = programid
            SqlDataSource6.InsertParameters("courseid").DefaultValue = courseid
            SqlDataSource6.InsertParameters("facultyid").DefaultValue = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
            SqlDataSource6.InsertParameters("classgid").DefaultValue = classgid
            SqlDataSource6.InsertParameters("studid").DefaultValue = Convert.ToInt32(item)
            SqlDataSource6.InsertParameters("attendancestatus").DefaultValue = True
            SqlDataSource6.InsertParameters("status").DefaultValue = "Present"
            SqlDataSource6.Insert()
            i = i + 1
        Next

        Dim str2 As String
        str2 = "SELECT Id AS id, firstname AS Name, gender AS Gender, regno AS Regno FROM (SELECT AU_students_1.Id, AU_students_1.firstname, AU_students_1.familyname, AU_students_1.email, AU_students_1.gender, AU_students_1.regno FROM nba_course_stud INNER JOIN AU_students AS AU_students_1 ON nba_course_stud.studid = AU_students_1.Id WHERE (nba_course_stud.classgid = " & classgid & ")) AS a WHERE (Id NOT IN (SELECT DISTINCT studid FROM nba_attendance WHERE (classid = " & classid & ") AND (colid = " & colid & "))) ORDER BY Regno"
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = str2


            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                SqlDataSource6.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
                SqlDataSource6.InsertParameters("classid").DefaultValue = classid
                SqlDataSource6.InsertParameters("programid").DefaultValue = programid
                SqlDataSource6.InsertParameters("courseid").DefaultValue = courseid
                SqlDataSource6.InsertParameters("facultyid").DefaultValue = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
                SqlDataSource6.InsertParameters("classgid").DefaultValue = classgid
                SqlDataSource6.InsertParameters("studid").DefaultValue = Convert.ToInt32(rdr1.GetValue(0).ToString)
                SqlDataSource6.InsertParameters("attendancestatus").DefaultValue = False
                SqlDataSource6.InsertParameters("status").DefaultValue = "Absent"
                SqlDataSource6.Insert()
            Loop
            rdr1.Close()
            con1.Close()
        End Using

        SqlDataSource4.SelectParameters("classgid").DefaultValue = classgid
        SqlDataSource4.SelectParameters("classid").DefaultValue = classid
        RadGrid3.DataBind()

        SqlDataSource7.SelectParameters("classgid").DefaultValue = classgid
        SqlDataSource7.SelectParameters("classid").DefaultValue = classid
        ASPxGridView2.DataBind()



        Literal1.Text = "Attendance taken for " & i.ToString & " students successfully."
    End Sub

    Protected Sub RadButton2_Click(sender As Object, e As EventArgs) Handles RadButton2.Click
        'If RadNumericTextBox1.Text = "" Then
        '    Literal1.Text = "Please enter class duration in minutes."
        '    Exit Sub
        'End If
        If DropDownList1.SelectedIndex = -1 Then
            Literal1.Text = "Please select Period."
            Exit Sub
        End If
        If DropDownList2.SelectedIndex = -1 Then
            Literal1.Text = "Please select Faculty."
            Exit Sub
        End If
        createclass()

    End Sub
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub
    Protected Sub SqlDataSource3_Selecting(sender As Object, e As SqlDataSourceSelectingEventArgs) Handles SqlDataSource3.Selecting

    End Sub

    Private Sub SqlDataSource3_Inserted(sender As Object, e As SqlDataSourceStatusEventArgs) Handles SqlDataSource3.Inserted
        classid = Convert.ToInt32(e.Command.Parameters("@classid").Value.ToString)
        'Literal1.Text = classid

    End Sub
    Protected Sub RadButton3_Click(sender As Object, e As EventArgs) Handles RadButton3.Click
        Dim s1 As Boolean = False
        Dim status As String
        If RadComboBox2.SelectedValue.ToString.Contains("Present") Then
            s1 = True
            status = "Present"
        Else
            s1 = False
            status = "Absent"
        End If
        Dim fieldValues As List(Of Object) = ASPxGridView2.GetSelectedFieldValues(New String() {"Id"})
        Dim i As Integer = 0
        For Each item As Object In fieldValues
            'Dim str1 As String
            'str1 = "Update activity_pub set approvestatus='Approved' where colid=" & colid & "and Id=" & item
            'str1 = "Update au_client_te set status='Approved' where colid=" & colid & "and Id=" & item

            'sendsmsstud(item, ASPxTextBox1.Text)
            SqlDataSource8.UpdateParameters("attendancestatus").DefaultValue = s1
            SqlDataSource8.UpdateParameters("status").DefaultValue = status
            SqlDataSource8.UpdateParameters("editedbyempid").DefaultValue = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
            SqlDataSource8.UpdateParameters("category").DefaultValue = RadComboBox3.SelectedValue.ToString
            SqlDataSource8.UpdateParameters("slevel").DefaultValue = RadComboBox4.SelectedValue.ToString
            SqlDataSource8.UpdateParameters("id").DefaultValue = Convert.ToInt32(item)
            SqlDataSource8.UpdateParameters("comments").DefaultValue = RadTextBox1.Text
            SqlDataSource8.Update()

            'SqlDataSource6.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
            'SqlDataSource6.InsertParameters("classid").DefaultValue = classid
            'SqlDataSource6.InsertParameters("programid").DefaultValue = programid
            'SqlDataSource6.InsertParameters("courseid").DefaultValue = courseid
            'SqlDataSource6.InsertParameters("facultyid").DefaultValue = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
            'SqlDataSource6.InsertParameters("classgid").DefaultValue = classgid
            'SqlDataSource6.InsertParameters("studid").DefaultValue = Convert.ToInt32(item)
            'SqlDataSource6.InsertParameters("attendancestatus").DefaultValue = True
            'SqlDataSource6.InsertParameters("status").DefaultValue = "Present"
            'SqlDataSource6.Insert()
            i = i + 1



        Next
        refreshdata()
        Literal1.Text = "Attendance updated."
    End Sub

    Public Sub refreshdata()
        Literal1.Text = ""
        Dim classexists As Boolean = False
        Dim classid As Integer

        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        Dim classgid As Integer
        If RadComboBox1.SelectedIndex = -1 Then
            Literal1.Text = "Please select MyClass."
            Exit Sub
        End If
        classgid = Convert.ToInt32(RadComboBox1.SelectedValue.ToString)
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString



        Dim periodid As Integer = Convert.ToInt32(DropDownList1.SelectedValue.ToString)
        Dim starttime1 As DateTime
        Dim endtime1 As DateTime
        Dim sh, sm, sd As Integer
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1


            cmd1.CommandText = "Select StartHour,StartMinutes,DurationInMinutes from au_periods_conf where id=" & periodid
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                Try
                    sh = Convert.ToDouble(rdr1.GetValue(0).ToString)
                    sm = Convert.ToDouble(rdr1.GetValue(1).ToString)
                    sd = Convert.ToDouble(rdr1.GetValue(2).ToString)
                Catch ex As Exception
                    Literal1.Text = "Invalid configuration."
                    Exit Sub
                End Try
            Loop
            rdr1.Close()
            con1.Close()
        End Using

        starttime1 = Now.AddHours(10.5).AddHours(sh).AddMinutes(sm)
        endtime1 = starttime1.AddMinutes(sd)










        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1

            'Dim starttime1 As DateTime = Convert.ToDateTime(RadDateTimePicker1.SelectedDate)
            'Dim endtime1 As DateTime = Convert.ToDateTime(RadDateTimePicker1.SelectedDate).AddMinutes(Convert.ToDouble(RadNumericTextBox1.Text))
            cmd1.CommandText = "Select id From au_periods where starttime='" & starttime1 & "' and endtime='" & endtime1 & "' and classgid=" & classgid
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader


            Do While rdr1.Read
                classexists = True
                classid = Convert.ToInt32(rdr1.GetValue(0).ToString)
            Loop
            rdr1.Close()
            con1.Close()
        End Using
        SqlDataSource4.SelectParameters("classgid").DefaultValue = classgid
        SqlDataSource4.SelectParameters("classid").DefaultValue = classid
        RadGrid3.DataBind()

        SqlDataSource7.SelectParameters("classgid").DefaultValue = classgid
        SqlDataSource7.SelectParameters("classid").DefaultValue = classid
        ASPxGridView2.DataBind()
    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        'Literal1.Text = RadDateTimePicker1.SelectedDate & "<br>" & RadDateTimePicker2.SelectedDate & "<br>" & DateDiff(DateInterval.Hour, RadDateTimePicker1.SelectedDate, RadDateTimePicker2.SelectedDate).ToString
        'If Convert.ToDouble(DateDiff(DateInterval.Hour, RadDateTimePicker1.SelectedDate, RadDateTimePicker2.SelectedDate)) > 3 Then
        '    Literal1.Text = Literal1.Text & "<br> Invalid selection."
        'End If
        Literal1.Text = ""
        Dim classexists As Boolean = False
        Dim classid As Integer
        If DropDownList1.SelectedIndex = -1 Then
            Literal1.Text = "Please select period."
            Exit Sub
        End If

        Dim periodid As Integer = Convert.ToInt32(DropDownList1.SelectedValue.ToString)
        Dim starttime1 As DateTime
        Dim endtime1 As DateTime
        Dim sh, sm, sd As Integer
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1


            cmd1.CommandText = "Select StartHour,StartMinutes,DurationInMinutes from au_periods_conf where id=" & periodid
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                Try
                    sh = Convert.ToDouble(rdr1.GetValue(0).ToString)
                    sm = Convert.ToDouble(rdr1.GetValue(1).ToString)
                    sd = Convert.ToDouble(rdr1.GetValue(2).ToString)
                Catch ex As Exception
                    Literal1.Text = "Invalid configuration."
                    Exit Sub
                End Try
            Loop
            rdr1.Close()
            con1.Close()
        End Using

        starttime1 = Now.AddHours(10.5).AddHours(sh).AddMinutes(sm)
        endtime1 = starttime1.AddMinutes(sd)



        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        Dim classgid As Integer
        If RadComboBox1.SelectedIndex = -1 Then
            Literal1.Text = "Please select MyClass."
            Exit Sub
        End If
        classgid = Convert.ToInt32(RadComboBox1.SelectedValue.ToString)

        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1




            cmd1.CommandText = "Select id From au_periods where starttime='" & starttime1 & "' and endtime='" & endtime1 & "' and classgid=" & classgid
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader


            Do While rdr1.Read
                classexists = True
                classid = Convert.ToInt32(rdr1.GetValue(0).ToString)
            Loop
            rdr1.Close()
            con1.Close()
        End Using
        SqlDataSource4.SelectParameters("classgid").DefaultValue = classgid
        SqlDataSource4.SelectParameters("classid").DefaultValue = classid
        RadGrid3.DataBind()

        SqlDataSource7.SelectParameters("classgid").DefaultValue = classgid
        SqlDataSource7.SelectParameters("classid").DefaultValue = classid
        ASPxGridView2.DataBind()
    End Sub
End Class
