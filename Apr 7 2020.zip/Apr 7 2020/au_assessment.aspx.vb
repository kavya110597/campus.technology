﻿
Partial Class au_assessment
    Inherits System.Web.UI.Page

End Class
