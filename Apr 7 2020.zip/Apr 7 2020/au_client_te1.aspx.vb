﻿Imports DevExpress.Web
Imports System.Data
Imports System.Data.SqlClient

Partial Class au_client_te1
    Inherits System.Web.UI.Page

    Protected Sub ASPxGridView1_CellEditorInitialize(sender As Object, e As DevExpress.Web.ASPxGridViewEditorEventArgs) Handles ASPxGridView1.CellEditorInitialize
        If (Not ASPxGridView1.IsEditing) OrElse e.Column.FieldName <> "milestoneid" Then
            Return
        End If
        If e.KeyValue Is DBNull.Value OrElse e.KeyValue Is Nothing Then
            Return
        End If
        Dim val As Object = ASPxGridView1.GetRowValuesByKeyValue(e.KeyValue, "clientid")
        If val Is DBNull.Value Then
            Return
        End If
        'Dim country As String = CStr(val)
        Dim clientid As Integer = Convert.ToInt32(CStr(val))

        Dim combo As ASPxComboBox = TryCast(e.Editor, ASPxComboBox)
        FillCityCombo(combo, clientid)

        AddHandler combo.Callback, AddressOf cmbCity_OnCallback
    End Sub
    Protected Sub FillCityCombo(ByVal cmb As ASPxComboBox, ByVal clientid As Integer)



        cmb.Items.Clear()
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "Select id,milestone from au_milestone where clientid=" & clientid
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                cmb.Items.Add(rdr1.GetValue(1).ToString, Convert.ToInt32(rdr1.GetValue(0).ToString))
            Loop
            rdr1.Close()
            con1.Close()
        End Using






    End Sub
    Private Sub cmbCity_OnCallback(ByVal source As Object, ByVal e As CallbackEventArgsBase)
        FillCityCombo(TryCast(source, ASPxComboBox), Convert.ToInt32(e.Parameter.ToString))
    End Sub
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            'ASPxGridView1.StartEdit(3)
        End If
    End Sub
    Protected Sub RadButton1_Click(sender As Object, e As EventArgs) Handles RadButton1.Click
        SqlDataSource1.InsertParameters("milestoneid").DefaultValue = Convert.ToInt32(RadComboBox2.SelectedValue.ToString)
        SqlDataSource1.InsertParameters("clientid").DefaultValue = Convert.ToInt32(RadComboBox1.SelectedValue.ToString)
        SqlDataSource1.InsertParameters("description").DefaultValue = RadTextBox1.Text
        SqlDataSource1.InsertParameters("dateofwork").DefaultValue = RadDatePicker1.SelectedDate
        SqlDataSource1.InsertParameters("hours").DefaultValue = Convert.ToDouble(RadNumericTextBox2.Text)
        SqlDataSource1.InsertParameters("expenses").DefaultValue = Convert.ToDouble(RadNumericTextBox1.Text)
        SqlDataSource1.Insert()
        ASPxGridView1.DataBind()




    End Sub
    Protected Sub ASPxButton1_Click(sender As Object, e As EventArgs) Handles ASPxButton1.Click
        Dim colid As Integer
        Dim cookie1 As HttpCookie = Request.Cookies("colid")
        If cookie1 Is Nothing Then
            Response.Redirect("facultylogin.aspx")
        Else
            colid = Convert.ToInt32(cookie1.Value.ToString)
        End If
        'If RadComboBox1.SelectedItem Is Nothing OrElse RadComboBox1.SelectedIndex = -1 Then
        '    Label1.Text = "Please select Department"
        '    Label1.ForeColor = Drawing.Color.Red
        '    Exit Sub
        'End If
        Dim fieldValues As List(Of Object) = ASPxGridView1.GetSelectedFieldValues(New String() {"Id"})

        If fieldValues.Count = 0 Then
            Label1.Text = "Please select atleast one data"
            Label1.ForeColor = Drawing.Color.Red
            Exit Sub
            Return
        Else
            For Each item As Object In fieldValues
                Dim str1 As String
                str1 = "Update activity_pub set approvestatus='Approved' where colid=" & colid & "and Id=" & item
                str1 = "Update au_client_te set status='Approved' where colid=" & colid & "and Id=" & item
                Dim cs1 As New schoolclass1
                cs1.insertdata(str1)
            Next
            'ASPxGridView6.DataBind()
            Label2.Text = "Approved Successfully!!"
            Label2.ForeColor = Drawing.Color.Green
        End If

    End Sub
End Class
