﻿
Partial Class au_config
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        SqlDataSource12.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        SqlDataSource12.InsertParameters("Branchname").DefaultValue = TextBox1.Text
        SqlDataSource12.InsertParameters("Email1").DefaultValue = TextBox3.Text
        SqlDataSource12.InsertParameters("Phone1").DefaultValue = TextBox4.Text
        SqlDataSource12.Insert()
        GridView1.DataBind()
        Gender.DataBind()
        DropDownList1.DataBind()



    End Sub
    Protected Sub Button2t_Click(sender As Object, e As EventArgs) Handles Button2t.Click
        SqlDataSource9.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        SqlDataSource9.InsertParameters("branchid").DefaultValue = Convert.ToInt32(Gender.SelectedValue.ToString)
        SqlDataSource9.InsertParameters("depname").DefaultValue = Category.Text

        SqlDataSource9.Insert()
        GridView2.DataBind()
        DropDownList2.DataBind()

    End Sub


    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        SqlDataSource5.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        SqlDataSource5.InsertParameters("deptid").DefaultValue = Convert.ToInt32(DropDownList2.SelectedValue.ToString)
        SqlDataSource5.InsertParameters("programs").DefaultValue = TextBox2.Text

        SqlDataSource5.Insert()
        GridView3.DataBind()
    End Sub
    Protected Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        SqlDataSource17.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        SqlDataSource17.InsertParameters("deptid").DefaultValue = Convert.ToInt32(DropDownList4.SelectedValue.ToString)
        SqlDataSource17.InsertParameters("programid").DefaultValue = Convert.ToInt32(DropDownList5.SelectedValue.ToString)

        SqlDataSource17.InsertParameters("coursename").DefaultValue = TextBox5.Text
        SqlDataSource17.InsertParameters("coursecode").DefaultValue = TextBox6.Text

        SqlDataSource17.Insert()
        GridView4.DataBind()
    End Sub
End Class
