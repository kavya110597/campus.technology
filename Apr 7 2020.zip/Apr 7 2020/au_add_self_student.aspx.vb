﻿
Partial Class au_add_self_student
    Inherits System.Web.UI.Page

End Class
