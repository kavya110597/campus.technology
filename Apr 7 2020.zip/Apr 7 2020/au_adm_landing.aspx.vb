﻿
Partial Class au_adm_landing
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If Page.IsValid Then
        Else
            Label1.Text = "Invalid captcha."
            Exit Sub
        End If
        Dim colid As String = Request.QueryString("colid").ToString
        Dim cooki10 As New HttpCookie("colid")
        cooki10.Value = colid.ToString
        cooki10.Expires = DateTime.Now.AddMinutes(180)
        Response.Cookies.Add(cooki10)

        Response.Redirect("au_enroll_stud.aspx")
    End Sub
End Class
