﻿
Partial Class au_cbcs_cons
    Inherits System.Web.UI.Page

End Class
