﻿
Partial Class au_alumnitree
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim str1 As String = String.Empty
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.QueryString("colid").ToString)
        Catch ex As Exception
            Label2.Text = "Invalid URL. Please contact your administrator."
            Exit Sub

        End Try
        str1 = "Insert into au_alumnitree(colid,name,email,phone,batch,workingat) values('" & colid & "',@payee,@category,@others,@others12,@others13)"
        Dim cs1 As New schoolclass1
        cs1.insertdata(str1, TextBox1.Text, TextBox2.Text, TextBox3.Text, TextBox4.Text, TextBox5.Text)
        Label2.Text = "Alumni details updated."
    End Sub
End Class
