﻿
Partial Class au_enrollment_form_view
    Inherits System.Web.UI.Page

    Protected Sub RadButton1_Click(sender As Object, e As EventArgs) Handles RadButton1.Click
        If RadComboBox1.SelectedIndex = -1 OrElse RadComboBox2.SelectedIndex = -1 Then
            Exit Sub
        End If
        Dim progid As Integer = Convert.ToInt32(RadComboBox1.SelectedValue.ToString)
        Dim batch As String = RadComboBox2.SelectedValue.ToString
        HyperLink1.NavigateUrl = "au_enrollment_form_1.aspx?programid=" & progid & "&batch=" & batch
        HyperLink1.Text = "View enrollment form"
    End Sub
End Class
