﻿
Partial Class adminlogin_report2
    Inherits System.Web.UI.Page

End Class
