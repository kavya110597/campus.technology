﻿Imports DevExpress.XtraPrinting
Partial Class au_examsearchbysubject
    Inherits System.Web.UI.Page
    Protected Sub ImageWord_Click(sender As Object, e As ImageClickEventArgs) Handles ImageWord.Click

        ASPxGridViewExporter1.GridViewID = "ASPxGridView1"

        ASPxGridViewExporter1.WriteRtfToResponse()

    End Sub
    Protected Sub ImageExcel_Click(sender As Object, e As ImageClickEventArgs) Handles ImageExcel.Click

        ASPxGridViewExporter1.GridViewID = "ASPxGridView1"

        ASPxGridViewExporter1.WriteXlsxToResponse(New XlsxExportOptionsEx With {.ExportType = DevExpress.Export.ExportType.WYSIWYG})
    End Sub
    Protected Sub ImagePDF_Click(sender As Object, e As ImageClickEventArgs) Handles ImagePDF.Click

        ASPxGridViewExporter1.GridViewID = "ASPxGridView1"

        Dim options As New DevExpress.XtraPrinting.PdfExportOptions

        options.Compressed = False
        ASPxGridViewExporter1.WritePdfToResponse(options)

    End Sub
End Class
