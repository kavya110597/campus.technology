﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Data.OleDb
Partial Class au_deptteachingmethod
    Inherits System.Web.UI.Page
    'Protected Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
    '    Label12.Text = ""
    '    If SubjectTextBox.Text = "" OrElse FacultyTextBox.Text = "" OrElse BatchTextBox.Text = "" OrElse SemesterTextBox.Text = "" OrElse DirectTextBox.Text = "" OrElse IndirectTextBox.Text = "" OrElse dept_ddl.SelectedIndex = -1 OrElse po_ddl.SelectedIndex = -1 OrElse co_ddl.SelectedIndex = -1 Then
    '        Label12.Text = "Please enter all details."
    '        Label12.ForeColor = Drawing.Color.Red
    '        Exit Sub
    '    End If


    '    Dim colid, empid As Integer
    '    colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
    '    empid = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)


    '    SqlDataSource4.InsertParameters("colid").DefaultValue = colid
    '    SqlDataSource4.InsertParameters("empid").DefaultValue = empid
    '    SqlDataSource4.InsertParameters("deptid").DefaultValue = Convert.ToInt32(dept_ddl.SelectedValue.ToString)
    '    SqlDataSource4.InsertParameters("coid").DefaultValue = Convert.ToInt32(co_ddl.SelectedValue.ToString)
    '    SqlDataSource4.InsertParameters("poid").DefaultValue = Convert.ToInt32(po_ddl.SelectedValue.ToString)
    '    SqlDataSource4.InsertParameters("batch").DefaultValue = BatchTextBox.Text
    '    SqlDataSource4.InsertParameters("semester").DefaultValue = SemesterTextBox.Text
    '    SqlDataSource4.InsertParameters("direct").DefaultValue = DirectTextBox.Text
    '    SqlDataSource4.InsertParameters("indirect").DefaultValue = IndirectTextBox.Text
    '    SqlDataSource4.InsertParameters("subject").DefaultValue = SubjectTextBox.Text
    '    SqlDataSource4.InsertParameters("facultyname").DefaultValue = FacultyTextBox.Text

    '    SqlDataSource4.Insert()

    '    Label12.Text = "Details Added."
    '    Label12.ForeColor = Drawing.Color.Green
    '    GridView2.DataBind()

    'End Sub
    Protected Sub BSemExcel_Click(sender As Object, e As EventArgs) Handles BSemExcel.Click
        Label12.Text = ""
        Dim colid, empid, facultyid As Integer
        colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        empid = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
        If dept_ddl.SelectedIndex = -1 Then
            Label12.Text = "Please select department."
            Label12.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If FileUpload1.HasFile Then
            Dim file As HttpPostedFile = FileUpload1.PostedFile
            Dim filesize As Integer = file.ContentLength
            If filesize > 4194304 Then
                Label12.Text = "File exceeds the maximum size limit i.e. 4MB"
                Label12.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim filename As String = Path.GetFileName(FileUpload1.FileName)
            Dim extension As String = Path.GetExtension(filename)

            If extension <> ".xls" AndAlso extension <> ".xlsx" Then
                Label12.Text = "Invalid file extension.Please upload .xls or .xlsx file"
                Label12.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim path1 As String = "employee/photos/" & filename
            Dim dir1 As String = Server.MapPath(".") & "\employee\files"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If
            Dim path2 As String = Server.MapPath(".") & "\employee\files\" & filename

            FileUpload1.SaveAs(path2)


            Dim constr1 As String

            constr1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & path2 & ";Extended Properties=""Excel 12.0 Xml;HDR=YES"";"
            Using con1 As New OleDbConnection
                con1.ConnectionString = constr1
                con1.Open()
                Dim cmd1 As New OleDbCommand
                cmd1.Connection = con1
                cmd1.CommandText = "Select * from [Sheet1$]"
                Dim rdr1 As OleDbDataReader = cmd1.ExecuteReader

                Do While rdr1.Read

                    facultyid = getfacultyid(rdr1.GetValue(3).ToString, Convert.ToInt32(dept_ddl.SelectedValue.ToString))
                    If facultyid = -1 Then
                        Label12.Text = "Faculty with name '" & rdr1.GetValue(3).ToString & "' is not available in database."
                        Label12.ForeColor = Drawing.Color.Red
                        Exit Sub
                    End If

                    SqlDataSource4.InsertParameters("colid").DefaultValue = colid
                    SqlDataSource4.InsertParameters("empid").DefaultValue = empid
                    SqlDataSource4.InsertParameters("deptid").DefaultValue = Convert.ToInt32(dept_ddl.SelectedValue.ToString)
                    SqlDataSource4.InsertParameters("coid").DefaultValue = Convert.ToInt32(rdr1.GetValue(2).ToString)
                    SqlDataSource4.InsertParameters("poid").DefaultValue = Convert.ToInt32(rdr1.GetValue(1).ToString)
                    SqlDataSource4.InsertParameters("batch").DefaultValue = rdr1.GetValue(4).ToString
                    SqlDataSource4.InsertParameters("semester").DefaultValue = rdr1.GetValue(5).ToString
                    SqlDataSource4.InsertParameters("direct").DefaultValue = rdr1.GetValue(6).ToString
                    SqlDataSource4.InsertParameters("indirect").DefaultValue = rdr1.GetValue(7).ToString
                    SqlDataSource4.InsertParameters("courseid").DefaultValue = Convert.ToInt32(rdr1.GetValue(0).ToString)
                    SqlDataSource4.InsertParameters("facultyid").DefaultValue = facultyid
                    SqlDataSource4.Insert()

                    GridView2.DataBind()


                Loop
                rdr1.Close()
                con1.Close()
            End Using

            Label12.Text = "Details Added."
            Label12.ForeColor = Drawing.Color.Green
            GridView2.DataBind()
        Else
            Label12.Text = "File is either not Selected or is Empty."
            Label12.ForeColor = Drawing.Color.Red
            Exit Sub
        End If

    End Sub
    Public Function getfacultyid(ByVal faculty As String, ByVal deptid As Integer) As Integer
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString
        Dim facid As Integer = -1
        Dim colid As Integer
        colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "SELECT [Id], [NameOfDesignator] FROM [designation] WHERE NameOfDesignator=@NameOfDesignator and deptid=@deptid and colid=@colid"
            cmd1.Parameters.AddWithValue("@NameOfDesignator", faculty).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@deptid", deptid).DbType = DbType.Int32
            cmd1.Parameters.AddWithValue("@colid", colid).DbType = DbType.Int32
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                Try
                    facid = Convert.ToInt32(rdr1.GetValue(0).ToString)
                Catch ex As Exception

                End Try
            Loop


            rdr1.Close()
            con1.Close()
        End Using
        Return facid

    End Function
End Class
