﻿
Partial Class au_capacity_stud
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Response.Redirect("au_capacity_stud1.aspx")
    End Sub
End Class
