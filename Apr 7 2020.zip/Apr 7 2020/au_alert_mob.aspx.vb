﻿
Partial Class au_alert_mob
    Inherits System.Web.UI.Page

End Class
