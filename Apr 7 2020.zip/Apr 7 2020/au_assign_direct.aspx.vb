﻿
Partial Class au_assign_direct
    Inherits System.Web.UI.Page

End Class
