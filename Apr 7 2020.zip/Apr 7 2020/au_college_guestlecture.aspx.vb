﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Data.OleDb
Imports System.Drawing
Partial Class au_college_guestlecture
    Inherits System.Web.UI.Page
    Protected Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Labelguest.Text = ""
        LGuest.Text = ""
        If TextBox9.Text = "" OrElse TextBox10.Text = "" OrElse TextBox11.Text = "" OrElse TBstartdate8.Text = "" OrElse guestResource.Text = "" Then
            LGuest.Text = "Please enter all details."
            LGuest.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If IsDate(TBstartdate8.Text) = False Then
            LGuest.Text = "Invalid Date."
            LGuest.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If FileUploadguest.HasFile Then
            Dim file As HttpPostedFile = FileUploadguest.PostedFile
            Dim filesize As Integer = file.ContentLength
            If filesize > 1000000 Then
                LGuest.Text = "File exceeds the maximum size limit i.e. 1MB"
                LGuest.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim extensionlist() As String = {".doc", ".docx", ".jpeg", ".gif", ".png", ".pdf", ".jpg"}
            Dim filename As String = Path.GetFileName(FileUploadguest.FileName)
            Dim extension As String = Path.GetExtension(filename)

            If extensionlist.Contains(extension) = False Then
                LGuest.Text = "Invalid file extension.Please upload .doc or .pdf or .jpeg or .png or .jpg or .gif"
                LGuest.ForeColor = Drawing.Color.Red
                Exit Sub
            End If


            Dim path1 As String = "students/photos/" & filename
            Dim dir1 As String = Server.MapPath(".") & "\students\photos"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If
            Dim path2 As String = Server.MapPath(".") & "\students\photos\" & filename
            FileUploadguest.SaveAs(path2)
            SqlDataSource1.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
            SqlDataSource1.InsertParameters("empid").DefaultValue = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
            SqlDataSource1.InsertParameters("resourceperson").DefaultValue = guestResource.Text
            SqlDataSource1.InsertParameters("methodname").DefaultValue = TextBox9.Text
            SqlDataSource1.InsertParameters("po").DefaultValue = TextBox10.Text
            SqlDataSource1.InsertParameters("organizedby").DefaultValue = TextBox11.Text
            SqlDataSource1.InsertParameters("startdate").DefaultValue = Convert.ToDateTime(TBstartdate8.Text)
            SqlDataSource1.InsertParameters("type").DefaultValue = DropDownList11.SelectedValue.ToString()
            SqlDataSource1.InsertParameters("deliverymethod").DefaultValue = DropDownList12.SelectedValue.ToString()
            SqlDataSource1.InsertParameters("certificate").DefaultValue = path1
            SqlDataSource1.InsertParameters("Relation").DefaultValue = "College"
            SqlDataSource1.Insert()
            LGuest.Text = "Guest Lecture Details Added."
            LGuest.ForeColor = Drawing.Color.Green
            GridView6.DataBind()

        Else
            SqlDataSource1.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
            SqlDataSource1.InsertParameters("empid").DefaultValue = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
            SqlDataSource1.InsertParameters("resourceperson").DefaultValue = guestResource.Text
            SqlDataSource1.InsertParameters("methodname").DefaultValue = TextBox9.Text
            SqlDataSource1.InsertParameters("po").DefaultValue = TextBox10.Text
            SqlDataSource1.InsertParameters("organizedby").DefaultValue = TextBox11.Text
            SqlDataSource1.InsertParameters("startdate").DefaultValue = Convert.ToDateTime(TBstartdate8.Text)
            SqlDataSource1.InsertParameters("type").DefaultValue = DropDownList11.SelectedValue.ToString()
            SqlDataSource1.InsertParameters("deliverymethod").DefaultValue = DropDownList12.SelectedValue.ToString()
            SqlDataSource1.InsertParameters("Relation").DefaultValue = "College"
            SqlDataSource1.Insert()
            LGuest.Text = "Guest Lecture Details Added."
            LGuest.ForeColor = Drawing.Color.Green
            GridView6.DataBind()

        End If
    End Sub
    Private Sub GridView6_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView6.RowCommand
        LGuest.Text = ""
        Labelguest.Text = ""
        If e.CommandName = "save" Then
            Dim rowid As Integer = Convert.ToInt32(e.CommandArgument.ToString)
            Dim lbl1 As Label = CType(GridView6.Rows(rowid).FindControl("Labelid2guest"), Label)
            Dim fileid As Integer = Convert.ToInt32(lbl1.Text.ToString)
            Dim FileUploadsave As FileUpload
            FileUploadsave = CType(GridView6.Rows(rowid).FindControl("FileUploadcertiguest"), FileUpload)
            Dim filename As String = ""
            Dim path1 As String = ""

            If FileUploadsave.HasFile Then
                Dim file As HttpPostedFile = FileUploadsave.PostedFile
                Dim filesize As Integer = file.ContentLength
                If filesize > 1000000 Then
                    Labelguest.Text = "File exceeds the maximum size limit i.e. 1MB"
                    Labelguest.ForeColor = Drawing.Color.Red
                    Exit Sub
                End If
                Dim extensionlist() As String = {".doc", ".docx", ".jpeg", ".gif", ".png", ".pdf", ".jpg"}
                filename = Path.GetFileName(FileUploadsave.FileName)
                Dim extension As String = Path.GetExtension(filename)

                If extensionlist.Contains(extension) = False Then
                    Labelguest.Text = "Invalid file extension.Please upload .doc or .pdf or .jpeg or .png or .jpg or .gif"
                    Labelguest.ForeColor = Drawing.Color.Red
                    Exit Sub
                End If
                path1 = "students/photos/" & filename
                Dim dir1 As String = Server.MapPath(".") & "\students\photos\"
                If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                    My.Computer.FileSystem.CreateDirectory(dir1)
                End If
                Dim path2 As String = Server.MapPath(".") & "\students\photos\" & filename

                FileUploadsave.SaveAs(path2)


            End If
            Dim str1 As String
            str1 = "Update dept_guests set certificate=@path1 where Id=@id"
            updatedata(str1, path1, fileid)
            Labelguest.Text = "File Uploaded."
            Labelguest.ForeColor = Drawing.Color.Green
            GridView6.DataBind()

        End If
    End Sub
    Protected Sub BGuestExcel_Click(sender As Object, e As EventArgs) Handles BGuestExcel.Click
        LGuest.Text = ""
        Labelguest.Text = ""
        If FileUpload6.HasFile Then
            Dim file As HttpPostedFile = FileUpload6.PostedFile
            Dim filesize As Integer = file.ContentLength
            If filesize > 4194304 Then
                LGuest.Text = "File exceeds the maximum size limit i.e. 4MB"
                LGuest.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim filename As String = Path.GetFileName(FileUpload6.FileName)
            Dim extension As String = Path.GetExtension(filename)


            If extension <> ".xls" AndAlso extension <> ".xlsx" Then
                LGuest.Text = "Invalid file extension.Please upload .xls or .xlsx file"
                LGuest.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim path1 As String = "employee/photos/" & filename
            Dim dir1 As String = Server.MapPath(".") & "\employee\files"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If
            Dim path2 As String = Server.MapPath(".") & "\employee\files\" & filename

            FileUpload6.SaveAs(path2)


            Dim constr1 As String

            constr1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & path2 & ";Extended Properties=""Excel 12.0 Xml;HDR=YES"";"
            Using con1 As New OleDbConnection
                con1.ConnectionString = constr1
                con1.Open()
                Dim cmd1 As New OleDbCommand
                cmd1.Connection = con1
                cmd1.CommandText = "Select * from [Sheet1$]"
                Dim rdr1 As OleDbDataReader = cmd1.ExecuteReader

                Do While rdr1.Read


                    Dim startdate As Date
                    Try
                        startdate = Convert.ToDateTime(rdr1.GetValue(1).ToString)

                    Catch ex As Exception
                        LGuest.Text = "Invalid Date."
                        LGuest.ForeColor = Drawing.Color.Red
                        Exit Sub
                    End Try
                    SqlDataSource1.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
                    SqlDataSource1.InsertParameters("empid").DefaultValue = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)

                    SqlDataSource1.InsertParameters("methodname").DefaultValue = rdr1.GetValue(0).ToString
                    SqlDataSource1.InsertParameters("po").DefaultValue = rdr1.GetValue(2).ToString
                    SqlDataSource1.InsertParameters("organizedby").DefaultValue = rdr1.GetValue(3).ToString
                    SqlDataSource1.InsertParameters("startdate").DefaultValue = startdate
                    SqlDataSource1.InsertParameters("type").DefaultValue = rdr1.GetValue(4).ToString
                    SqlDataSource1.InsertParameters("deliverymethod").DefaultValue = rdr1.GetValue(5).ToString
                    SqlDataSource1.InsertParameters("Relation").DefaultValue = "College"
                    SqlDataSource1.Insert()



                    GridView6.DataBind()



                Loop
                rdr1.Close()
                con1.Close()
            End Using

            LGuest.Text = "Guest Lecture Details Added."
            LGuest.ForeColor = Drawing.Color.Green
            GridView6.DataBind()
        Else
            LGuest.Text = "File is either not Selected or is Empty."
            LGuest.ForeColor = Drawing.Color.Red
            Exit Sub
        End If

    End Sub
    Public Sub updatedata(ByVal str As String, ByVal path1 As String, ByVal rowid As Integer)
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = str

            cmd1.Parameters.AddWithValue("@id", rowid).DbType = DbType.Int32
            cmd1.Parameters.AddWithValue("@path1", path1).DbType = DbType.String
            cmd1.ExecuteNonQuery()
            con1.Close()

        End Using
    End Sub
End Class
