﻿
Partial Class au_attcourse_report
    Inherits System.Web.UI.Page

End Class
