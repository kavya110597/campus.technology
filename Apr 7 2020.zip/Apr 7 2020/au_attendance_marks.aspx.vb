﻿
Partial Class au_attendance_marks
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim assignment, internal, seminar, model As Double


        For Each r1 As GridViewRow In GridView1.Rows
            Dim studid As String = r1.Cells(3).Text
            Dim percentage As String = r1.Cells(6).Text
            'Literal1.Text = Literal1.Text & studid & "," & "attendance," & percentage & "<br>"
            enterdata(studid, percentage, "Attendance")

        Next
        Dim m1 As New msgbox11
        m1.showmessage1("Attendance data entered")
    End Sub
    Public Sub enterdata(ByVal studid As Integer, ByVal marks As Double, ByVal type As String)


        SqlDataSource6.InsertParameters("ActualMarks").DefaultValue = marks
        SqlDataSource6.InsertParameters("studid").DefaultValue = studid
        SqlDataSource6.InsertParameters("Type").DefaultValue = type
        SqlDataSource6.Insert()
    End Sub
End Class
