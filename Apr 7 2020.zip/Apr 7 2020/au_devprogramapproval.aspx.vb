﻿
Partial Class au_devprogramapproval
    Inherits System.Web.UI.Page
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim colid As Integer
        Dim cookie1 As HttpCookie = Request.Cookies("colid")
        If cookie1 Is Nothing Then
            Response.Redirect("facultylogin.aspx")
        Else
            colid = Convert.ToInt32(cookie1.Value.ToString)
        End If
        If RadComboBox1.SelectedItem Is Nothing OrElse RadComboBox1.SelectedIndex = -1 Then
            Label1.Text = "Please select Department"
            Label1.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        Dim fieldValues As List(Of Object) = ASPxGridView6.GetSelectedFieldValues(New String() {"Id"})

        If fieldValues.Count = 0 Then
            Label1.Text = "Please select atleast one data"
            Label1.ForeColor = Drawing.Color.Red
            Exit Sub
            Return
        Else
            For Each item As Object In fieldValues
                Dim str1 As String
                str1 = "Update activity_refresher set approvestatus='Approved' where colid=" & colid & "and Id=" & item
                Dim cs1 As New schoolclass1
                cs1.insertdata(str1)
            Next
            ASPxGridView6.DataBind()
            Label1.Text = "Approved Successfully!!"
            Label1.ForeColor = Drawing.Color.Green
        End If


    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim colid As Integer
        Dim cookie1 As HttpCookie = Request.Cookies("colid")
        If cookie1 Is Nothing Then
            Response.Redirect("facultylogin.aspx")
        Else
            colid = Convert.ToInt32(cookie1.Value.ToString)
        End If
        If RadComboBox1.SelectedItem Is Nothing OrElse RadComboBox1.SelectedIndex = -1 Then
            Label1.Text = "Please select Department"
            Label1.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        Dim fieldValues As List(Of Object) = ASPxGridView6.GetSelectedFieldValues(New String() {"Id"})

        If fieldValues.Count = 0 Then
            Label1.Text = "Please select atleast one data"
            Label1.ForeColor = Drawing.Color.Red
            Exit Sub
            Return
        Else
            For Each item As Object In fieldValues
                Dim str1 As String
                str1 = "Update activity_refresher set approvestatus='Inactive' where colid=" & colid & "and Id=" & item
                Dim cs1 As New schoolclass1
                cs1.insertdata(str1)
            Next
            ASPxGridView6.DataBind()
            Label1.Text = "Inactive Status Added Successfully."
            Label1.ForeColor = Drawing.Color.Green
        End If

    End Sub
End Class
