﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class au_bookissue
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim colid As Integer
        Dim cookie1 As HttpCookie = Request.Cookies("colid")
        If cookie1 Is Nothing Then
            Response.Redirect("facultylogin.aspx")
        Else
            colid = Convert.ToInt32(cookie1.Value.ToString)
        End If
        If student_rcb.SelectedItem Is Nothing OrElse student_rcb.SelectedIndex = -1 Then
            Label1.Text = "Please select Student"
            Label1.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If Tb_borrow.Text = "" OrElse Tb_return.Text = "" Then
            Label1.Text = "Enter Borrow/Return Date"
            Label1.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If IsDate(Tb_borrow.Text) = False OrElse IsDate(Tb_return.Text) = False Then
            Label1.Text = "Invalid Date"
            Label1.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        Dim borrowdate As Date = Convert.ToDateTime(Tb_borrow.Text)
        Dim duedate As Date = Convert.ToDateTime(Tb_return.Text)
        Dim studentid As Integer = Convert.ToInt32(student_rcb.SelectedValue.ToString)
        Dim fieldValues As List(Of Object) = ASPxGridView1.GetSelectedFieldValues(New String() {"Id"})

        If fieldValues.Count = 0 Then
            Label1.Text = "Please select atleast one data"
            Label1.ForeColor = Drawing.Color.Red
            Exit Sub
            Return
        Else
            For Each item As Object In fieldValues
                Dim str1 As String
                str1 = "Insert into lib2issue(bookid,Borrowdate,Duedate,studid,status,colid)values(@bookid,@Borrowdate,@Duedate,@studid,'Open',@colid)"

                insertdata(str1, item, borrowdate, duedate, studentid, colid)
            Next
            ASPxGridView1.DataBind()
            Label1.Text = "Book Issued"
            Label1.ForeColor = Drawing.Color.Green
        End If

    End Sub
    Public Sub insertdata(ByVal str1 As String, ByVal bookid As Integer, ByVal Borrowdate As Date, ByVal DueDate As Date, ByVal studid As Integer, ByVal colid As Integer)
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = str1
            cmd1.Parameters.AddWithValue("@colid", colid).DbType = DbType.Int32
            cmd1.Parameters.AddWithValue("@bookid", bookid).DbType = DbType.Int32

            cmd1.Parameters.AddWithValue("@Borrowdate", Borrowdate).DbType = DbType.Date
            cmd1.Parameters.AddWithValue("@DueDate", DueDate).DbType = DbType.Date
            cmd1.Parameters.AddWithValue("@studid", studid).DbType = DbType.Int32

            cmd1.ExecuteNonQuery()
            con1.Close()
        End Using
    End Sub
End Class
