﻿
Partial Class au_add_single_student
    Inherits System.Web.UI.Page

End Class
