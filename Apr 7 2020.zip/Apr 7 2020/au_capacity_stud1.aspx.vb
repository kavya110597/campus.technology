﻿Imports System.IO
Imports System.Data.OleDb
Imports DevExpress.XtraPrinting
Imports Telerik.Web.UI
Imports System.Data
Imports System.Data.SqlClient

Partial Class au_capacity_stud1
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click



        Dim fieldValues As List(Of Object) = ASPxGridView2.GetSelectedFieldValues(New String() {"Id"})
        Dim i As Integer = 0
        For Each item As Object In fieldValues
            SqlDataSource1.InsertParameters("schemeid").DefaultValue = Convert.ToInt32(RadComboBox3.SelectedValue.ToString)
            SqlDataSource1.InsertParameters("studid").DefaultValue = Convert.ToInt32(item)
            SqlDataSource1.InsertParameters("StartDate").DefaultValue = Convert.ToDateTime(RadDatePicker1.SelectedDate)
            SqlDataSource1.InsertParameters("EndDate").DefaultValue = Convert.ToDateTime(RadDatePicker2.SelectedDate)
            SqlDataSource1.InsertParameters("YearImplemented").DefaultValue = RadComboBox5.SelectedValue.ToString
            SqlDataSource1.InsertParameters("Status").DefaultValue = RadComboBox4.SelectedValue.ToString

            SqlDataSource1.Insert()

            ASPxGridView1.DataBind()

        Next
    End Sub
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub

    Protected Sub ImageWord_Click(sender As Object, e As ImageClickEventArgs) Handles ImageWord.Click

        ASPxGridViewExporter1.GridViewID = "ASPxGridView1"

        ASPxGridViewExporter1.WriteRtfToResponse()

    End Sub
    Protected Sub ImageExcel_Click(sender As Object, e As ImageClickEventArgs) Handles ImageExcel.Click

        ASPxGridViewExporter1.GridViewID = "ASPxGridView1"

        ASPxGridViewExporter1.WriteXlsxToResponse(New XlsxExportOptionsEx With {.ExportType = DevExpress.Export.ExportType.WYSIWYG})
    End Sub
    Protected Sub ImagePDF_Click(sender As Object, e As ImageClickEventArgs) Handles ImagePDF.Click

        ASPxGridViewExporter1.GridViewID = "ASPxGridView1"

        Dim options As New DevExpress.XtraPrinting.PdfExportOptions

        options.Compressed = False
        ASPxGridViewExporter1.WritePdfToResponse(options)

    End Sub
End Class
