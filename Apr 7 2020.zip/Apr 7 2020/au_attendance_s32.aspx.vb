﻿Imports Telerik.Web.UI

Partial Class au_attendance_s32
    Inherits System.Web.UI.Page

    Protected Sub RadGrid1_RowDrop(sender As Object, e As Telerik.Web.UI.GridDragDropEventArgs) Handles RadGrid1.RowDrop
        For Each item As GridDataItem In e.DraggedItems
            Dim id As Integer = Convert.ToInt32(item("id").Text)
            Dim str1 As String
            'str1 = "Update au_students set status='Active' where id=" & id
            'Dim cs1 As New schoolclass1
            'cs1.insertdata(str1)
            SqlDataSource6.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
            SqlDataSource6.InsertParameters("classid").DefaultValue = Convert.ToInt32(Request.Cookies("classid").Value.ToString)
            SqlDataSource6.InsertParameters("programid").DefaultValue = Convert.ToInt32(Request.Cookies("programid").Value.ToString)
            SqlDataSource6.InsertParameters("courseid").DefaultValue = Convert.ToInt32(Request.Cookies("courseid").Value.ToString)
            SqlDataSource6.InsertParameters("facultyid").DefaultValue = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
            SqlDataSource6.InsertParameters("studid").DefaultValue = id
            SqlDataSource6.InsertParameters("attendancestatus").DefaultValue = True
            SqlDataSource6.InsertParameters("status").DefaultValue = "Present"
            SqlDataSource6.Insert()

            RadGrid1.DataBind()
            RadGrid2.DataBind()
            RadToolTip1.Show()

            'Literal1.Text = Literal1.Text & id.ToString & "<br>"
        Next
    End Sub
    Protected Sub RadGrid2_RowDrop(sender As Object, e As GridDragDropEventArgs) Handles RadGrid2.RowDrop
        For Each item As GridDataItem In e.DraggedItems
            Dim id As Integer = Convert.ToInt32(item("id").Text)
            Dim str1 As String
            Dim classid As Integer = Convert.ToInt32(Request.Cookies("classid").Value.ToString)
            Dim colid As Integer = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
            str1 = "delete from nba_attendance where studid=" & id & " and classid=" & classid & " and colid=" & colid
            Dim cs1 As New schoolclass1
            cs1.insertdata(str1)
            RadGrid1.DataBind()
            RadGrid2.DataBind()
            RadToolTip1.Show()

            'Literal1.Text = Literal1.Text & id.ToString & "<br>"
        Next
    End Sub
End Class
