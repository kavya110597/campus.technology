﻿
Partial Class au_deptime_view_3
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub
    Protected Sub RadButton2_Click(sender As Object, e As EventArgs) Handles RadButton2.Click
        RadScheduler1.ExportToPdf()

    End Sub
    Protected Sub RadScheduler1_AppointmentClick(sender As Object, e As Telerik.Web.UI.SchedulerEventArgs) Handles RadScheduler1.AppointmentClick
        Response.Redirect("take_attendance.aspx?classid=" & e.Appointment.ID)
    End Sub
End Class
