﻿
Partial Class au_Access_denied
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim paystatus As String
        Dim duedate As Date
        Dim colid As Integer
        Dim amount As Double

        Try
            paystatus = Request.Cookies("paystatus").Value.ToString
            duedate = Convert.ToDateTime(Request.Cookies("duedate").Value.ToString)
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
            amount = Convert.ToDouble(Request.Cookies("amount").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        If paystatus = "trial" AndAlso duedate >= DateTime.Now.Date Then
            Panel1.Visible = False
            Panel2.Visible = True
            Literal1.Text = "Your trial ends on " & duedate.Month & "/" & duedate.Day & "/" & duedate.Year

            HyperLink3.NavigateUrl = "http://campus.technology/erpnew/faculty/payments/transaction121.aspx?orderid=" & colid & "&amount=" & amount & ".00"
            HyperLink2.NavigateUrl = "au_access_select.aspx" ' "au_dashboard_t1.aspx"
        Else
            Panel1.Visible = True
            Panel2.Visible = False
            HyperLink1.NavigateUrl = "http://campus.technology/erpnew/faculty/payments/transaction121.aspx?orderid=" & colid & "&amount=" & amount & ".00"
        End If
    End Sub
End Class
