﻿
Partial Class adminlogin_report1
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim cookie1 As HttpCookie = Request.Cookies("colid")

        If cookie1 Is Nothing Then
            Response.Redirect("admin_log.aspx")
        Else


        End If



    End Sub
End Class
