﻿
Partial Class faculty_au_collaborative
    Inherits System.Web.UI.Page

End Class
