﻿
Partial Class au_course_mcq_data
    Inherits System.Web.UI.Page

End Class
