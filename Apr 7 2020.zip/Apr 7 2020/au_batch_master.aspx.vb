﻿
Partial Class au_batch_master
    Inherits System.Web.UI.Page

End Class
