﻿
Partial Class au_clientdetail
    Inherits System.Web.UI.Page

End Class
