﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class au_billing
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            Dim paystatus As String
            Dim duedate As Date
            Dim colid As Integer
            Dim amount As Double

            Try
                paystatus = Request.Cookies("paystatus").Value.ToString
                duedate = Convert.ToDateTime(Request.Cookies("duedate").Value.ToString)
                colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
                'amount = Convert.ToDouble(Request.Cookies("amount").Value.ToString)
            Catch ex As Exception
                Response.Redirect("facultylogin.aspx")
            End Try

            Dim nusers As Int16 = getfacultycount()

            Label6.Text = nusers
            TextBox1.Text = nusers

            Label2.Visible = False

            'amount = getfacultycount() * 250
            If paystatus = "ok" Then
                Label1.Text = "Active"
            Else
                Label1.Text = paystatus.ToUpper
            End If
            Label2.Text = amount.ToString
            Label3.Text = duedate.Month & "/" & duedate.Day & "/" & duedate.Year

            Dim name1 As String = Request.Cookies("empname").Value.ToString
            Dim email1 As String = Request.Cookies("nemployeeid").Value.ToString

            'HyperLink1.NavigateUrl = "http://campus.technology/erpnew/faculty/payments/transaction121.aspx?orderid=" & colid & "&amount=" & amount & ".00"
            'HyperLink1.NavigateUrl = "http://campus.technology/erpnew/faculty/payments/transaction121.aspx?orderid=" & colid & "&amount=" & amount & ".00"

            'Response.Redirect("sendtoairpay3.aspx?name=" & name1 & "&email=" & email1 & "&amount=" & amount & ".00" & "&orderid=" & studid & "r1r" & colid & "&chmod=" & chmod)
            HyperLink1.Visible = False

        End If

    End Sub
    Public Function getfacultycount() As Integer
        Dim constr1 As String
        Dim colid As Integer
        Label2.Visible = True

        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        Dim fcount As Integer = 0

        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "Select count(*) from designation where colid=" & colid

            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                fcount = Convert.ToInt32(rdr1.GetValue(0).ToString)
            Loop
            rdr1.Close()
            con1.Close()
        End Using
        Return fcount

    End Function
    Public Function getperuserfee() As Integer
        Dim constr1 As String
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        Dim fcount As Integer = 0

        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "Select PayPerUser from collegedetails where id=" & colid

            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                fcount = Convert.ToInt32(rdr1.GetValue(0).ToString)
            Loop
            rdr1.Close()
            con1.Close()
        End Using
        Return fcount

    End Function
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim name1 As String = Request.Cookies("empname").Value.ToString
        Dim email1 As String = Request.Cookies("nemployeeid").Value.ToString

        Dim amount As Double
        Dim tax As Double
        Dim total As Double

        Dim colid As Integer = Convert.ToInt32(Request.Cookies("colid").Value.ToString)

        Dim months As Integer = Convert.ToInt32(DropDownList1.SelectedValue.ToString)


        Dim nusers As Int16 = getfacultycount()

        If TextBox1.Text = "" OrElse IsNumeric(TextBox1.Text) = False Then
            TextBox1.Text = nusers

        End If

        Dim tusers As Integer = Convert.ToInt32(TextBox1.Text)


        Label6.Text = TextBox1.Text



        Dim productcode As Integer = Convert.ToInt32(DropDownList3.SelectedValue.ToString)

        If productcode > 1 Then
            tusers = 0
        End If


        If productcode = 1 Then
            Dim peruserfee As Double = getperuserfee()
            amount = tusers * peruserfee
        ElseIf productcode = 2 Then
            amount = 10000
        ElseIf productcode = 3 Then
            amount = 20000
        ElseIf productcode = 4 Then
            amount = 100000
        ElseIf productcode = 5 Then
            amount = 50000
        ElseIf productcode = 6 Then
            amount = 100000
        ElseIf productcode = 7 Then
            amount = 100000

        End If


        If months < 6 Then
            amount = amount * months
        ElseIf months = 6 Then
            amount = amount * months * 0.9
        ElseIf months = 12 Then
            amount = amount * months * 0.8

        End If

        Label2.Text = amount


        'HyperLink1.NavigateUrl = "http://campus.technology/erpnew/faculty/payments/transaction121.aspx?orderid=" & colid & "&amount=" & amount & ".00"

        Dim surcharge As Double = Math.Round(amount * 0.18, 2)
        amount = amount + surcharge
        Label4.Text = surcharge
        Label5.Text = amount

        Dim chmod As String

        If DropDownList2.SelectedValue.ToString.Contains("Netbanking") Then
            'surcharge = 30
            chmod = "nb"
        ElseIf DropDownList2.SelectedValue.ToString.Contains("Credit") Then
            'surcharge = totalfees * 0.02
            chmod = "pgcc"
        ElseIf DropDownList2.SelectedValue.ToString.Contains("Debit") Then
            'If totalfees < 2000 Then
            '    surcharge = 0
            'Else
            '    surcharge = totalfees * 0.02
            'End If
            chmod = "pgdc"
        Else
            'surcharge = totalfees * 0.025
            chmod = "onclik"
        End If

        'HyperLink1.NavigateUrl = "sendtoairpay3.aspx?name=" & name1 & "&email=" & "abc@abc.com" & "&amount=" & amount & ".00" & "&orderid=" & email1 & "r" & DropDownList1.SelectedValue.ToString & "r" & colid & "&chmod=" & chmod
        HyperLink1.NavigateUrl = "sendtoairpay3.aspx?name=" & name1 & "&email=" & "abc@abc.com" & "&amount=" & amount & "&orderid=" & email1 & "r" & DropDownList1.SelectedValue.ToString & "r" & colid & "&chmod=" & chmod
        HyperLink1.NavigateUrl = "sendtoairpay3.aspx?name=" & name1 & "&email=" & "abc@abc.com" & "&amount=" & amount & "&orderid=" & email1 & "r" & DropDownList1.SelectedValue.ToString & "r" & colid & "r" & DropDownList3.SelectedValue.ToString & "r" & tusers & "&chmod=" & chmod
        HyperLink1.Visible = True

        'Response.Redirect()

    End Sub
End Class
