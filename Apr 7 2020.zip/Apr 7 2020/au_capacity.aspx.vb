﻿
Partial Class au_capacity
    Inherits System.Web.UI.Page

End Class
