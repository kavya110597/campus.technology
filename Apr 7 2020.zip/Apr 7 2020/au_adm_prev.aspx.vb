﻿
Partial Class au_adm_prev
    Inherits System.Web.UI.Page

End Class
