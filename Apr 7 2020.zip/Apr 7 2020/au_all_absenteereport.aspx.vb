﻿
Partial Class au_all_absenteereport
    Inherits System.Web.UI.Page

End Class
