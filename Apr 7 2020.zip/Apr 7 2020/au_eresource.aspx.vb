﻿
Partial Class faculty_au_eresource
    Inherits System.Web.UI.Page

End Class
