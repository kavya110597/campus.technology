﻿
Partial Class au_attendance_mod_admin
    Inherits System.Web.UI.Page

End Class
