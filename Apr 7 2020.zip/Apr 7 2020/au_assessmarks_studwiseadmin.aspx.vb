﻿
Partial Class au_assessmarks_studwiseadmin
    Inherits System.Web.UI.Page

End Class
