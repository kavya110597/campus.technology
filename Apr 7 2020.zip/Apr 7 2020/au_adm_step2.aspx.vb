﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class au_adm_step2
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim colid As Integer = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Dim constr1 As String
        Dim mercid As String = ""
        Dim amount As Double = -1
        Dim username As String = ""
        Dim password As String = ""
        Dim secretkey As String = ""



        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "Select MID, AdmissionFormFee from collegedetails where id=" & colid
            cmd1.CommandText = "Select MID, AdmissionFormFee,username,Password,SecretKey from collegedetails where id=" & colid
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                Try
                    mercid = rdr1.GetValue(0).ToString
                    amount = Convert.ToDouble(rdr1.GetValue(1).ToString)
                    username = rdr1.GetValue(2).ToString
                    password = rdr1.GetValue(3).ToString
                    secretkey = rdr1.GetValue(4).ToString

                Catch ex As Exception

                End Try

            Loop
            rdr1.Close()
            con1.Close()
        End Using


        If amount = -1 OrElse mercid = "" OrElse username = "" OrElse password = "" OrElse secretkey = "" Then
            Literal1.Text = "Online payment is not available. Please contact the institution for payment. Thank you for your application."
            Exit Sub
        End If


        Dim str12 As String
        Dim name As String = Request.Cookies("name").Value.ToString
        Dim studid As String = Request.Cookies("studid").Value.ToString


        str12 = "http://campus.technology/erpnew/faculty/sendtoapnew1.aspx?name=" & "Anura" & "&email=" & "abc@abc.com" & "&amount=" & "1" & "&orderid=" & "12" & "r" & colid & "r" & "12" & "r" & "12" & "r" & "1" & "&chmod=" & "" & "&mercid=" & mercid
        str12 = "http://campus.technology/erpnew/faculty/sendtoapnew1.aspx?name=" & name & "&email=" & "abc@abc.com" & "&amount=" & amount & "&orderid=" & studid & "r" & colid & "r" & "1" & "r" & "1" & "r" & "1" & "&chmod=" & "" & "&mercid=" & mercid

        Response.Redirect(str12)

    End Sub
End Class
