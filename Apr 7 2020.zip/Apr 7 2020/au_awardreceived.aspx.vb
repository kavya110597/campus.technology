﻿
Partial Class au_awardreceived
    Inherits System.Web.UI.Page

End Class
