﻿
Partial Class au_all_attendancereport
    Inherits System.Web.UI.Page

End Class
