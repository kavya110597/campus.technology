﻿
Partial Class au_course_chat
    Inherits System.Web.UI.Page

    Protected Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        ListView1.DataBind()

    End Sub
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Timer1.Enabled = True

        End If
    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ListView1.DataBind()

    End Sub
End Class
