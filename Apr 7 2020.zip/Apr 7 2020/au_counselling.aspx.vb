﻿
Partial Class au_counselling
    Inherits System.Web.UI.Page

End Class
