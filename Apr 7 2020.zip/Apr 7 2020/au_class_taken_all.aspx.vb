﻿
Partial Class au_class_taken_all
    Inherits System.Web.UI.Page

End Class
