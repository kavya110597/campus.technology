﻿
Partial Class au_copo
    Inherits System.Web.UI.Page

End Class
