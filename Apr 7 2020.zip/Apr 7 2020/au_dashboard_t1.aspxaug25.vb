﻿Imports System.Data.SqlClient
Imports System.Data

Partial Class au_dashboard_t1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            checkleave()
            'checkevent()
            'checkworkdiary()

        End If
    End Sub
    Public Sub checkleave()
        Dim count1 As Integer = 0
        Dim colid As Integer = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Dim empid As Integer = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
        Dim constr1 As String = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "select nba_leave.empid, count(nba_leave.empid) as count1 FROM nba_leave " &
  "WHERE (nba_leave.empid IN (SELECT DISTINCT empid FROM leavemanager WHERE (managerid = " & empid & ")))  " &
  "AND (nba_leave.colid = " & colid & ") AND (nba_leave.status IS NULL OR nba_leave.status = 'Reviewed by HOD')  " &
  "group by nba_leave.empid"
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                Try
                    count1 = Convert.ToInt32(rdr1.GetValue(1).ToString)
                Catch ex As Exception

                End Try
            Loop
            rdr1.Close()
            con1.Close()
        End Using
        If count1 > 0 Then
            Literal1.Text = Literal1.Text & "<span style=""color:#ff6a00;"">" & count1.ToString & "</span> New <a href=""au_leave_approve.aspx"">Leave Request(s)</a><br>"
        Else
            Literal1.Text = Literal1.Text & "No new leave request.<br>"
        End If
    End Sub
    Public Sub checkevent()
        Dim count1 As Integer = 0
        Dim count2 As Integer = 0
        Dim colid As Integer = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Dim empid As Integer = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
        Dim constr1 As String = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "select count(*) from dept_events where id not in (select eventid from dept_estat) and colid=" & colid
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                Try
                    count1 = Convert.ToInt32(rdr1.GetValue(0).ToString)
                Catch ex As Exception

                End Try
            Loop
            rdr1.Close()
            cmd1.CommandText = "select count(*) from dept_events where id  in (select eventid from dept_estat) and colid=" & colid
            rdr1 = cmd1.ExecuteReader
            Do While rdr1.Read
                Try
                    count2 = Convert.ToInt32(rdr1.GetValue(0).ToString)
                Catch ex As Exception

                End Try
            Loop
            rdr1.Close()
            con1.Close()
        End Using
        Literal1.Text = Literal1.Text & "<span style=""color:#ff6a00;"">" & count1.ToString & "</span> New <a href=""au_workload3.aspx"">Event expenditure not added.</a>" & count2.ToString & " Event expenditure added.<br>"
    End Sub
    Public Sub checkworkdiary()
        Dim count1 As Integer = 0
        Dim count2 As Integer = 0
        Dim colid As Integer = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Dim empid As Integer = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
        Dim constr1 As String = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "select count(*) from (select distinct id from designation where id not in (select empid from nba_work_diary) and colid=" & colid & ") as a"
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                Try
                    count1 = Convert.ToInt32(rdr1.GetValue(0).ToString)
                Catch ex As Exception

                End Try
            Loop
            rdr1.Close()
            cmd1.CommandText = "select count(*) from (select distinct id from designation where id in (select empid from nba_work_diary) and colid=" & colid & ") as a"
            rdr1 = cmd1.ExecuteReader
            Do While rdr1.Read
                Try
                    count2 = Convert.ToInt32(rdr1.GetValue(0).ToString)
                Catch ex As Exception

                End Try
            Loop
            rdr1.Close()
            con1.Close()
        End Using
        Literal1.Text = Literal1.Text & "<span style=""color:#ff6a00;"">" & count1.ToString & " Faculties did not update </span><a href=""au_workload3.aspx"">Work Diary.</a>" & count2.ToString & " Faculties have updated work diary.<br>"
    End Sub
End Class
