﻿
Partial Class au_cgpa
    Inherits System.Web.UI.Page

End Class
