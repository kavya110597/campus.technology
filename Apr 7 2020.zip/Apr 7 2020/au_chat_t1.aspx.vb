﻿
Partial Class au_chat_t1
    Inherits System.Web.UI.Page

End Class
