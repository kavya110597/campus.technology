﻿Imports System.Data.SqlClient
Partial Class faculty_admitcardview
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim studid As Integer
        ' Dim semester As String
        Try
            studid = Convert.ToInt32(Request.QueryString("studid").ToString)
            'semester = Request.QueryString("semester").ToString
        Catch ex As Exception
            Response.Redirect("au_admitcard1.aspx")
        End Try
        If Not Page.IsPostBack Then
            Image1.ImageUrl = photoselect()
            Dim ret1 As String = loadgridview1(studid)
            Dim array1 As String() = ret1.Split("~")
            Dim studentname As String = array1(0).ToString()
            Dim enroll_no As String = array1(1).ToString()
            Dim father As String = array1(2).ToString()
            Dim mother As String = array1(3).ToString()
            Literal1.Text = studid.ToString
            Literal2.Text = studentname.ToString
            Literal3.Text = father.ToString
            Literal4.Text = mother.ToString
            Literal5.Text = enroll_no.ToString
            ' Literal6.Text = semester.ToString

        End If
    End Sub
    Public Function loadgridview1(ByVal studid As Integer) As String
        Dim ret1 As String

        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString

        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "Select distinct studentname,enroll_no,fathersname,mothersname from au_studentadmitcard where Id=" & studid
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                ret1 = rdr1.GetValue(0).ToString & "~" & rdr1.GetValue(1).ToString & "~" & rdr1.GetValue(2).ToString & "~" & rdr1.GetValue(3).ToString


            Loop
            rdr1.Close()
            con1.Close()
        End Using
        Return ret1

    End Function
    Protected Function photoselect() As String
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString
        Dim studid As Integer
        studid = Convert.ToInt32(Request.QueryString("studid").ToString)
        Dim path1 As String
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1

            cmd1.CommandText = "SELECT photos1 from au_studentadmitcard where id=" & studid


            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read

                path1 = rdr1.GetValue(0).ToString

            Loop
            rdr1.Close()
            con1.Close()
        End Using

        Return path1
    End Function
End Class

