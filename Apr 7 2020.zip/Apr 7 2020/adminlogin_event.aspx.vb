﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Data.OleDb
Imports System.Drawing
Partial Class adminlogin_event
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim cookie1 As HttpCookie = Request.Cookies("colid")
        If cookie1 Is Nothing Then
            Response.Redirect("faculty_log.aspx")
        Else


        End If
    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)

        Catch ex As Exception
            Response.Redirect("faculty_log.aspx")
        End Try
        If dept_ddl.SelectedIndex = -1 OrElse event_text.Text = "" OrElse date_text.Text = "" OrElse emp_ddl.SelectedIndex = -1 Then
            Page.ClientScript.RegisterStartupScript(Me.[GetType](), "Alert", "alert('All fields are required.');", True)

            Exit Sub
        End If

        If IsDate(date_text.Text) = False Then
            Page.ClientScript.RegisterStartupScript(Me.[GetType](), "Alert", "alert('Invalid Date.');", True)

            Exit Sub
        End If
        If (DateAndTime.Year(date_text.Text)) < 1950 OrElse (DateAndTime.Year(date_text.Text)) > 2020 Then
            Page.ClientScript.RegisterStartupScript(Me.[GetType](), "Alert", "alert('Invalid Date.');", True)
            Exit Sub
        End If


        Dim deptid As Integer = Convert.ToInt32(dept_ddl.SelectedValue.ToString)
        Dim assignedtoempid As Integer = Convert.ToInt32(emp_ddl.SelectedValue.ToString)
        Dim eventname As String = event_text.Text
        Dim dateofevent As Date = Convert.ToDateTime(date_text.Text)


        Dim str1 As String
        str1 = "Insert into adminlogin_event(colid,deptid,assignedtoempid,eventname,dateofevent) values (@colid,@deptid,@assignedtoempid,@eventname,@dateofevent)"

        insertdata(str1, colid, deptid, assignedtoempid, eventname, dateofevent)
        GridView1.DataBind()

        Page.ClientScript.RegisterStartupScript(Me.[GetType](), "Alert", "alert('Details are Added.');", True)

    End Sub
    Public Sub insertdata(ByVal str As String, ByVal colid As Integer, ByVal deptid As Integer, ByVal assignedtoempid As Integer, ByVal eventname As String, ByVal dateofevent As Date)
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = str
            cmd1.Parameters.AddWithValue("@colid", colid).DbType = DbType.Int32
            cmd1.Parameters.AddWithValue("@deptid", deptid).DbType = DbType.Int32
            cmd1.Parameters.AddWithValue("@eventname", eventname).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@dateofevent", dateofevent).DbType = DbType.Date
            cmd1.Parameters.AddWithValue("@assignedtoempid", assignedtoempid).DbType = DbType.Int32

            cmd1.ExecuteNonQuery()
            con1.Close()

        End Using
    End Sub
    Protected Sub GridView1_RowDeleted(sender As Object, e As GridViewDeletedEventArgs) Handles GridView1.RowDeleted
        If e.Exception IsNot Nothing Then
            If e.AffectedRows = 0 Then
                Page.ClientScript.RegisterStartupScript(Me.[GetType](), "Alert", "alert('An exception occurred deleting the contact. ' &  'Please verify your values and try again.');", True)

            Else
                Page.ClientScript.RegisterStartupScript(Me.[GetType](), "Alert", "alert('An exception occurred deleting the contact. ' & 'Please verify the values in the recently updated item.');", True)

            End If

            e.ExceptionHandled = True
        Else
            Page.ClientScript.RegisterStartupScript(Me.[GetType](), "Alert", "alert('Content Deleted.');", True)

        End If

    End Sub

    Protected Sub GridView1_RowUpdated(sender As Object, e As GridViewUpdatedEventArgs) Handles GridView1.RowUpdated
        If e.Exception IsNot Nothing Then
            If e.AffectedRows = 0 Then
                e.KeepInEditMode = True
                Page.ClientScript.RegisterStartupScript(Me.[GetType](), "Alert", "alert('An exception occurred updating the contact. ' &  'Please verify your values and try again.');", True)

            Else
                Page.ClientScript.RegisterStartupScript(Me.[GetType](), "Alert", "alert('An exception occurred updating the contact. ' & 'Please verify the values in the recently updated item.');", True)

            End If

            e.ExceptionHandled = True
        Else
            Page.ClientScript.RegisterStartupScript(Me.[GetType](), "Alert", "alert('Content Updated.');", True)

        End If
    End Sub
End Class
