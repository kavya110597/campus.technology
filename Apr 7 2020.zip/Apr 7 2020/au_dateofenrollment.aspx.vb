﻿
Partial Class au_dateofenrollment
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub
    Protected Sub ASPxButton1_Click(sender As Object, e As EventArgs) Handles ASPxButton1.Click
        Literal1.Text = ""
        Dim date1 As Date
        Try
            date1 = Convert.ToDateTime(ASPxDateEdit1.Date)
        Catch ex As Exception
            Literal1.Text = "Please select a valid date"
            Exit Sub
        End Try
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        Dim fieldValues As List(Of Object) = ASPxGridView1.GetSelectedFieldValues(New String() {"Id"})
        Dim i As Integer = 0
        For Each item As Object In fieldValues
            Dim str1 As String
            str1 = "Update au_students set DateOfApplication='" & date1 & "' where id=" & Convert.ToInt32(item) & " and colid=" & colid
            Dim cs1 As New schoolclass1
            cs1.insertdata(str1)
            i = i + 1
        Next
        Literal1.Text = i.ToString & " records updated."
        ASPxGridView1.DataBind()

    End Sub
End Class
