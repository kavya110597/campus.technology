﻿Imports DevExpress.Web
Imports System.Data
Imports System.Data.SqlClient
Imports DevExpress.XtraGrid.Views.Base
Imports System.Globalization
Imports DevExpress.XtraPrinting
Partial Class au_edit_attendance
    Inherits System.Web.UI.Page
    Protected Sub ASPxGridView2_BeforePerformDataSelect(sender As Object, e As EventArgs)
        Dim dxgv1 As ASPxGridView = CType(sender, ASPxGridView)
        Dim lid As Integer = Convert.ToInt32(dxgv1.GetMasterRowKeyValue)

        Session("classid") = lid
    End Sub
End Class
