﻿
Partial Class au_codetails
    Inherits System.Web.UI.Page

End Class
