﻿Imports System.IO
Imports System.Data
Imports System.Data.SqlClient


Partial Class au_clubs
    Inherits System.Web.UI.Page

    Protected Sub RadButton1_Click(sender As Object, e As EventArgs) Handles RadButton1.Click
        Dim filePath As String = FileUpload1.PostedFile.FileName
        Dim filename As String = Path.GetFileName(filePath)
        Dim ext As String = Path.GetExtension(filename)
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try

        If FileUpload1.HasFile Then
            Dim file As HttpPostedFile = FileUpload1.PostedFile
            Dim filesize As Integer = file.ContentLength
            If filesize > 4194304 Then
                Label1.Text = "File exceeds the maximum size limit i.e. 4MB"
                ' Label1.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            'Dim extensionlist() As String = {".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".txt", ".rtf", ".bmp", ".jpeg", ".gif", ".tiff", ".png", ".pcx", ".emf", ".rle", ".dib", ".pdf"}
            Dim filename1 As String = Path.GetFileName(FileUpload1.FileName)
            Dim extension As String = Path.GetExtension(filename1)
            If extension = ".png" OrElse extension = ".jpg" OrElse extension = ".jpeg" Then
            Else
                Label1.Text = "Invalid file."
                Exit Sub
            End If

            Dim fs As Stream = FileUpload1.PostedFile.InputStream
            Dim br As New BinaryReader(fs)
            Dim bytes As Byte() = br.ReadBytes(fs.Length)

            Dim constr1 As String
            constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString

            Using con1 As New SqlConnection
                con1.ConnectionString = constr1
                con1.Open()
                Dim cmd1 As New SqlCommand
                cmd1.Connection = con1
                cmd1.CommandText = "insert into au_clubs(Name,Description,colid,Logo) values(@Name,@Description,'" & colid & "',@Logo)"
                cmd1.Parameters.AddWithValue("@Name", RadTextBox1.Text).DbType = DbType.String  ' = RadTextBox1.Text
                cmd1.Parameters.AddWithValue("@Description", TextBox1.Text).DbType = DbType.String
                cmd1.Parameters.AddWithValue("@Logo", bytes).DbType = DbType.Binary
                cmd1.ExecuteNonQuery()
                con1.Close()
            End Using
            Label1.Text = "Club details updated."
            ASPxGridView1.DataBind()


        Else

        End If
    End Sub
End Class
