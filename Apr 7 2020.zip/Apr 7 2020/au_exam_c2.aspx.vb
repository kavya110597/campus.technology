﻿
Partial Class au_exam_c2
    Inherits System.Web.UI.Page

End Class
