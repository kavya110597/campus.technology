﻿Imports Telerik.Web.UI
Partial Class au_class2
    Inherits System.Web.UI.Page

    Protected Sub RadGrid1_RowDrop(sender As Object, e As Telerik.Web.UI.GridDragDropEventArgs) Handles RadGrid1.RowDrop
        For Each item As GridDataItem In e.DraggedItems
            Dim id As Integer = Convert.ToInt32(item("id").Text)
            Dim coursename As String = item("coursename").Text
            Dim str1 As String
            If TypeOf e.DestDataItem Is GridDataItem Then

                Dim id2 As Integer = Convert.ToInt32(e.DestDataItem("id").Text)
                str1 = "Update au_periods set courseid=" & id & ", coursename='" & coursename & "' where id=" & id2

                'str1 = "Update au_students set status='Alumni' where id=" & id
                Dim cs1 As New schoolclass1
                cs1.insertdata(str1)
            Else
                'Literal1.Text = Literal1.Text & "Invalid drop"
            End If




            'RadGrid1.DataBind()
            RadGrid2.DataBind()

            'Literal1.Text = Literal1.Text & id.ToString & "<br>"
        Next
    End Sub
    Protected Sub RadGrid2_RowDrop(sender As Object, e As Telerik.Web.UI.GridDragDropEventArgs) Handles RadGrid2.RowDrop
        For Each item As GridDataItem In e.DraggedItems
            Dim id As Integer = Convert.ToInt32(item("id").Text)
            'Dim coursename As String = item("coursename").Text
            Dim str1 As String
            Dim id2 As Integer = -1 ' Convert.ToInt32(e.DestDataItem("id").Text)


            str1 = "Update au_periods set courseid=" & id & ", coursename='' where id=" & id

            'str1 = "Update au_students Set status='Alumni' where id=" & id
            Dim cs1 As New schoolclass1
            cs1.insertdata(str1)

            'RadGrid1.DataBind()
            RadGrid2.DataBind()





            'Literal1.Text = Literal1.Text & id.ToString & "<br>"
        Next
    End Sub
End Class
