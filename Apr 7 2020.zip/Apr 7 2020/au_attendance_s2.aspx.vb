﻿
Partial Class au_attendance_s2
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Literal1.Text = Request.Cookies("programid").Value.ToString & "," & Request.Cookies("courseid").Value.ToString & "." & Request.Cookies("batchname").Value.ToString
    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim cooki16 As New HttpCookie("section")
        cooki16.Value = RadTextBox1.ToString
        cooki16.Expires = DateTime.Now.AddMinutes(30)
        Dim cooki17 As New HttpCookie("sgroup")
        cooki17.Value = RadTextBox2.ToString
        cooki17.Expires = DateTime.Now.AddMinutes(30)

        Response.Cookies.Add(cooki16)
        Response.Cookies.Add(cooki17)

        Response.Redirect("au_attendance_s3.aspx")
    End Sub
End Class
