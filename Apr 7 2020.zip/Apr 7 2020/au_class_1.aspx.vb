﻿Imports DevExpress.XtraScheduler
Imports DevExpress.Web.ASPxScheduler

Partial Class au_class_1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub
    Protected Sub ASPxScheduler1_AppointmentInserting(sender As Object, e As DevExpress.XtraScheduler.PersistentObjectCancelEventArgs) Handles ASPxScheduler1.AppointmentInserting
        Dim apt As Appointment = CType(e.Object, Appointment)
        If apt.AllDay Or apt.Type <> AppointmentType.Normal Then
            e.Cancel = True
        End If
    End Sub
End Class
