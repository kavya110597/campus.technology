﻿Imports Telerik.Web.UI.ExportInfrastructure
Imports Telerik.Web.UI

Partial Class au_112n
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub
    Protected Sub RadGrid1_InfrastructureExporting(sender As Object, e As Telerik.Web.UI.GridInfrastructureExportingEventArgs) Handles RadGrid1.InfrastructureExporting

        Dim exportStructure As ExportStructure = e.ExportStructure

        Dim table As Telerik.Web.UI.ExportInfrastructure.Table = exportStructure.Tables(0)

        table.ShiftRowsDown(1, 3)

        table.Cells("A1").Value = "1. Curricular Aspects (100)"
        table.Cells("A2").Value = "1.1 Curriculum planning and implementation (20)"
        table.Cells("A3").Value = "1.1.2 Number of certificate/diploma program introduced during last five years (5)"

    End Sub
    Protected Sub RadGrid2_InfrastructureExporting(sender As Object, e As Telerik.Web.UI.GridInfrastructureExportingEventArgs) Handles RadGrid2.InfrastructureExporting

        Dim exportStructure As ExportStructure = e.ExportStructure

        Dim table As Telerik.Web.UI.ExportInfrastructure.Table = exportStructure.Tables(0)

        table.ShiftRowsDown(1, 1)

        table.Cells("A1").Value = "1.1.3 Percentage of participation of full time teachers in various bodies of the Universities/Autonomous Colleges/ Other Colleges, such as BoS and Academic Council during the last five years. (5)"

    End Sub
    Protected Sub RadGrid3_InfrastructureExporting(sender As Object, e As Telerik.Web.UI.GridInfrastructureExportingEventArgs) Handles RadGrid3.InfrastructureExporting

        Dim exportStructure As ExportStructure = e.ExportStructure

        Dim table As Telerik.Web.UI.ExportInfrastructure.Table = exportStructure.Tables(0)

        table.ShiftRowsDown(1, 2)

        table.Cells("A1").Value = "1.2 Academic Flexibility (30)"
        table.Cells("A2").Value = "1.2.1 Percentage of new courses introduced of the total number of courses across all programs offered during the last five years (10)"


    End Sub
    Protected Sub RadGrid4_InfrastructureExporting(sender As Object, e As Telerik.Web.UI.GridInfrastructureExportingEventArgs) Handles RadGrid4.InfrastructureExporting

        Dim exportStructure As ExportStructure = e.ExportStructure

        Dim table As Telerik.Web.UI.ExportInfrastructure.Table = exportStructure.Tables(0)

        table.ShiftRowsDown(1, 1)

        'table.Cells("A1").Value = "1.2 Academic Flexibility (30)"
        table.Cells("A1").Value = "1.2.2 Percentage of programs in which Choice Based Credit System (CBCS)/elective course system has been implemented (10)"


    End Sub
End Class
