﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Data.OleDb
Imports System.Drawing
Partial Class au_actconsultancy
    Inherits System.Web.UI.Page
    Protected Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click

        Labelconsult.Text = ""
        Lconsultancy.Text = ""
        If TextBox6.Text = "" OrElse TextBox7.Text = "" OrElse TextBox8.Text = "" OrElse TBstartdate7.Text = "" Then
            Lconsultancy.Text = "Please enter all details."
            Lconsultancy.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If IsDate(TBstartdate7.Text) = False Then
            Lconsultancy.Text = "Invalid Date."
            Lconsultancy.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        Dim consultancytype As String = consulttype.SelectedItem.ToString
        If FileUploadconsultancy.HasFile Then
            Dim file As HttpPostedFile = FileUploadconsultancy.PostedFile
            Dim filesize As Integer = file.ContentLength
            If filesize > 1000000 Then
                Lconsultancy.Text = "File exceeds the maximum size limit i.e. 1MB"
                Lconsultancy.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim extensionlist() As String = {".doc", ".docx", ".jpeg", ".gif", ".png", ".pdf", ".jpg"}
            Dim filename As String = Path.GetFileName(FileUploadconsultancy.FileName)
            Dim extension As String = Path.GetExtension(filename)

            If extensionlist.Contains(extension) = False Then
                Lconsultancy.Text = "Invalid file extension.Please upload .doc or .pdf or .jpeg or .png or .jpg or .gif"
                Lconsultancy.ForeColor = Drawing.Color.Red
                Exit Sub
            End If


            Dim path1 As String = "students/photos/" & filename
            Dim dir1 As String = Server.MapPath(".") & "\students\photos"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If
            Dim path2 As String = Server.MapPath(".") & "\students\photos\" & filename
            FileUploadconsultancy.SaveAs(path2)
            SqlDataSource2.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
            SqlDataSource2.InsertParameters("empid").DefaultValue = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
            SqlDataSource2.InsertParameters("consultancytype").DefaultValue = consultancytype
            SqlDataSource2.InsertParameters("methodname").DefaultValue = TextBox6.Text
            SqlDataSource2.InsertParameters("po").DefaultValue = TextBox7.Text
            SqlDataSource2.InsertParameters("organizedby").DefaultValue = TextBox8.Text
            SqlDataSource2.InsertParameters("startdate").DefaultValue = Convert.ToDateTime(TBstartdate7.Text)
            SqlDataSource2.InsertParameters("type").DefaultValue = DropDownList9.SelectedValue.ToString()
            SqlDataSource2.InsertParameters("deliverymethod").DefaultValue = DropDownList10.SelectedValue.ToString()
            SqlDataSource2.InsertParameters("certificate").DefaultValue = path1
            SqlDataSource2.Insert()
            Lconsultancy.Text = "Consultancy Added."
            Lconsultancy.ForeColor = Drawing.Color.Green
            GridView5.DataBind()

        Else
            SqlDataSource2.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
            SqlDataSource2.InsertParameters("empid").DefaultValue = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
            SqlDataSource2.InsertParameters("consultancytype").DefaultValue = consultancytype
            SqlDataSource2.InsertParameters("methodname").DefaultValue = TextBox6.Text
            SqlDataSource2.InsertParameters("po").DefaultValue = TextBox7.Text
            SqlDataSource2.InsertParameters("organizedby").DefaultValue = TextBox8.Text
            SqlDataSource2.InsertParameters("startdate").DefaultValue = Convert.ToDateTime(TBstartdate7.Text)
            SqlDataSource2.InsertParameters("type").DefaultValue = DropDownList9.SelectedValue.ToString()
            SqlDataSource2.InsertParameters("deliverymethod").DefaultValue = DropDownList10.SelectedValue.ToString()
            SqlDataSource2.Insert()
            Lconsultancy.Text = "Consultancy Added."
            Lconsultancy.ForeColor = Drawing.Color.Green
            GridView5.DataBind()
        End If
    End Sub
    Private Sub GridView5_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView5.RowCommand
        Labelconsult.Text = ""
        Lconsultancy.Text = ""
        If e.CommandName = "save" Then
            Dim rowid As Integer = Convert.ToInt32(e.CommandArgument.ToString)
            Dim lbl1 As Label = CType(GridView5.Rows(rowid).FindControl("Labelid2consult"), Label)
            Dim fileid As Integer = Convert.ToInt32(lbl1.Text.ToString)
            Dim FileUploadsave As FileUpload
            FileUploadsave = CType(GridView5.Rows(rowid).FindControl("FileUploadcerticonsult"), FileUpload)
            Dim filename As String = ""
            Dim path1 As String = ""

            If FileUploadsave.HasFile Then
                Dim file As HttpPostedFile = FileUploadsave.PostedFile
                Dim filesize As Integer = file.ContentLength
                If filesize > 1000000 Then
                    Labelconsult.Text = "File exceeds the maximum size limit i.e. 1MB"
                    Labelconsult.ForeColor = Drawing.Color.Red
                    Exit Sub
                End If
                Dim extensionlist() As String = {".doc", ".docx", ".jpeg", ".gif", ".png", ".pdf", ".jpg"}
                filename = Path.GetFileName(FileUploadsave.FileName)
                Dim extension As String = Path.GetExtension(filename)

                If extensionlist.Contains(extension) = False Then
                    Labelconsult.Text = "Invalid file extension.Please upload .doc or .pdf or .jpeg or .png or .jpg or .gif"
                    Labelconsult.ForeColor = Drawing.Color.Red
                    Exit Sub
                End If
                path1 = "students/photos/" & filename
                Dim dir1 As String = Server.MapPath(".") & "\students\photos\"
                If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                    My.Computer.FileSystem.CreateDirectory(dir1)
                End If
                Dim path2 As String = Server.MapPath(".") & "\students\photos\" & filename

                FileUploadsave.SaveAs(path2)


            End If
            Dim str1 As String
            str1 = "Update activity_consultancy set certificate=@path1 where Id=@id"
            updatedata(str1, path1, fileid)
            Labelconsult.Text = "File Uploaded."
            Labelconsult.ForeColor = Drawing.Color.Green
            GridView5.DataBind()

        End If
    End Sub
    Protected Sub BConsultExcel_Click(sender As Object, e As EventArgs) Handles BConsultExcel.Click
        Labelconsult.Text = ""
        Lconsultancy.Text = ""
        If FileUpload5.HasFile Then
            Dim file As HttpPostedFile = FileUpload5.PostedFile
            Dim filesize As Integer = file.ContentLength
            If filesize > 4194304 Then
                Lconsultancy.Text = "File exceeds the maximum size limit i.e. 4MB"
                Lconsultancy.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim filename As String = Path.GetFileName(FileUpload5.FileName)
            Dim extension As String = Path.GetExtension(filename)



            If extension <> ".xls" AndAlso extension <> ".xlsx" Then
                Lconsultancy.Text = "Invalid file extension.Please upload .xls or .xlsx file"
                Lconsultancy.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim path1 As String = "employee/photos/" & filename
            Dim dir1 As String = Server.MapPath(".") & "\employee\files"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If
            Dim path2 As String = Server.MapPath(".") & "\employee\files\" & filename

            FileUpload5.SaveAs(path2)



            Dim constr1 As String

            constr1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & path2 & ";Extended Properties=""Excel 12.0 Xml;HDR=YES"";"
            Using con1 As New OleDbConnection
                con1.ConnectionString = constr1
                con1.Open()
                Dim cmd1 As New OleDbCommand
                cmd1.Connection = con1
                cmd1.CommandText = "Select * from [Sheet1$]"
                Dim rdr1 As OleDbDataReader = cmd1.ExecuteReader

                Do While rdr1.Read


                    Dim startdate As Date
                    Try
                        startdate = Convert.ToDateTime(rdr1.GetValue(2).ToString)

                    Catch ex As Exception
                        Lconsultancy.Text = "Invalid Date."
                        Lconsultancy.ForeColor = Drawing.Color.Red
                        Exit Sub
                    End Try
                    SqlDataSource2.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
                    SqlDataSource2.InsertParameters("empid").DefaultValue = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
                    SqlDataSource2.InsertParameters("consultancytype").DefaultValue = rdr1.GetValue(0).ToString
                    SqlDataSource2.InsertParameters("methodname").DefaultValue = rdr1.GetValue(1).ToString
                    SqlDataSource2.InsertParameters("po").DefaultValue = rdr1.GetValue(3).ToString
                    SqlDataSource2.InsertParameters("organizedby").DefaultValue = rdr1.GetValue(4).ToString
                    SqlDataSource2.InsertParameters("startdate").DefaultValue = startdate
                    SqlDataSource2.InsertParameters("type").DefaultValue = rdr1.GetValue(5).ToString
                    SqlDataSource2.InsertParameters("deliverymethod").DefaultValue = rdr1.GetValue(6).ToString
                    SqlDataSource2.Insert()


                    GridView5.DataBind()



                Loop
                rdr1.Close()
                con1.Close()
            End Using

            Lconsultancy.Text = "Consultancy Details Added."
            Lconsultancy.ForeColor = Drawing.Color.Green
            GridView5.DataBind()
        Else
            Lconsultancy.Text = "File is either not Selected or is Empty."
            Lconsultancy.ForeColor = Drawing.Color.Red
            Exit Sub
        End If

    End Sub
    Public Sub updatedata(ByVal str As String, ByVal path1 As String, ByVal rowid As Integer)
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = str

            cmd1.Parameters.AddWithValue("@id", rowid).DbType = DbType.Int32
            cmd1.Parameters.AddWithValue("@path1", path1).DbType = DbType.String
            cmd1.ExecuteNonQuery()
            con1.Close()

        End Using
    End Sub
End Class
