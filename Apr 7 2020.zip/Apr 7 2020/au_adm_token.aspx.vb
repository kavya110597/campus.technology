﻿
Partial Class au_adm_token
    Inherits System.Web.UI.Page

End Class
