﻿Imports System
Imports Telerik.Web.UI
Imports DevExpress.Web
Imports System.Data
Imports System.Data.SqlClient
Imports DevExpress.XtraPrinting
Imports System.Drawing.Color
Partial Class faculty_au_examregistration
    Inherits System.Web.UI.Page

    Protected Sub RadButton2_Click(sender As Object, e As EventArgs) Handles RadButton2.Click
        Dim colid, empid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        Dim classgid As Integer
        Try
            classgid = Convert.ToInt32(RadComboBox1.SelectedValue.ToString)
        Catch ex As Exception
            Label1.Text = "Please Select Class"
            Label1.ForeColor = Red
            Exit Sub
        End Try
        Dim examtype As String
        Try
            examtype = RadComboBox5.SelectedValue.ToString
        Catch ex As Exception

        End Try

        If ASPxGridView1.Selection.Count = 0 Then
            Dim script As String = "window.onload = function(){ alert('"
            script += "There were no Students Selected. \nYou need to select atleast one student "
            'script += "using the first check."
            script += "')};"
            ClientScript.RegisterStartupScript(Me.[GetType](), "FailMessage", script, True)
        Else
            For i As Integer = 0 To ASPxGridView1.VisibleRowCount - 1
                'Here I need to identify if the row I am iterating through is selected or not 
                If ASPxGridView1.Selection.IsRowSelected(i) Then
                    'exa = New ExchangeAccounts()
                    Dim id As Integer = Convert.ToInt32(ASPxGridView1.GetRowValues(i, ASPxGridView1.KeyFieldName))
                    ' If exa.GetRecord(id, Cn) Then


                    If checkstud(id, classgid, colid, examtype) = True Then
                        Literal1.Text += id.ToString & ","
                    Else
                        Literal2.Text += id.ToString & ","
                        SqlDataSource5.InsertParameters("colid").DefaultValue = colid
                        SqlDataSource5.InsertParameters("studid").DefaultValue = id
                        SqlDataSource5.InsertParameters("examtype").DefaultValue = examtype
                        SqlDataSource5.InsertParameters("classgid").DefaultValue = classgid

                        SqlDataSource5.Insert()
                    End If



                    'RadGrid3.DataBind()
                    Label1.Text = "Students with following ids are Registered Successfully :"
                    Label1.ForeColor = Green
                    Literal2.Text = Literal2.Text.TrimStart(",")
                    If Literal1.Text = "" Then
                    Else
                        Label2.Text = "Students with following ids were already registered :"
                        Label2.ForeColor = Red
                        Literal1.Text = Literal1.Text.TrimStart(",")
                    End If

                    'End If
                End If
            Next
        End If
    End Sub
    Public Function checkstud(ByVal studid As Integer, ByVal classgid As Integer, ByVal colid As Integer, ByVal examtype As String) As Boolean
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString
        Dim a As Boolean = False
        Dim em As String = ""
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "Select studid from au_examregistration where studid=@studid AND classgid=@classgid AND colid=@colid AND examtype=@examtype"
            cmd1.Parameters.AddWithValue("@studid", studid)
            cmd1.Parameters.AddWithValue("@classgid", classgid)
            cmd1.Parameters.AddWithValue("@colid", colid)
            cmd1.Parameters.AddWithValue("@examtype", examtype)
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                em = rdr1.GetValue(0).ToString

            Loop
            rdr1.Close()
            con1.Close()
        End Using
        If em.Length > 0 Then
            a = True
        End If
        Return a

    End Function
End Class
