﻿
Partial Class au_ext_events
    Inherits System.Web.UI.Page

End Class
