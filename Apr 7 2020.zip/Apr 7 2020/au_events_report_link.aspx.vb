﻿
Partial Class au_events_report_link
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        HyperLink1.NavigateUrl = "http://www.campus.technology/erpnew/faculty/au_events_report.aspx?colid=" & colid
        HyperLink1.Text = "http://www.campus.technology/erpnew/faculty/au_events_report.aspx?colid=" & colid
    End Sub
End Class
