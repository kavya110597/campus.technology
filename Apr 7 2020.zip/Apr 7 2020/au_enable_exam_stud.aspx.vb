﻿
Partial Class au_enable_exam_stud
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If RadComboBox1.SelectedIndex = -1 OrElse RadComboBox2.SelectedIndex = -1 OrElse RadComboBox3.SelectedIndex = -1 Then
            Literal1.Text = "All fields are mandatory."
            Exit Sub
        End If
        Dim assessmentid As Integer = Convert.ToInt32(RadComboBox1.SelectedValue.ToString)
        Dim studid As Integer = Convert.ToInt32(RadComboBox2.SelectedValue.ToString)
        Dim examid As Integer = Convert.ToInt32(RadComboBox3.SelectedValue.ToString)
        Dim str1 As String
        Dim cs1 As New schoolclass1
        str1 = "Delete from au_exam_score where assessmentid=" & assessmentid & " and examid=" & examid & " and studid=" & studid
        cs1.insertdata(str1)
        str1 = "Delete from au_mcq_history where assessmentid=" & assessmentid & " and studid=" & studid & " and examid=" & examid
        cs1.insertdata(str1)
        Literal1.Text = "Access has been enabled."
    End Sub
End Class
