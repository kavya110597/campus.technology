﻿
Partial Class au_batch_change
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Literal1.Text = ""
        If TextBox1.Text = "" Then
            Literal1.Text = "Please enter New batch Name."
            Exit Sub
        End If
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        Dim str1 As String
        str1 = "Update au_students set batch=@payee where batch='" & RadComboBox2.SelectedValue.ToString & "' and colid=" & colid
        Dim cs1 As New schoolclass1
        cs1.insertdata(str1, TextBox1.Text)
        Literal1.Text = "Batch updated."


    End Sub
End Class
