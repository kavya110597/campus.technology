﻿Imports System.IO
Imports System.Data
Imports System.Data.SqlClient


Partial Class au_clubs
    Inherits System.Web.UI.Page

    Protected Sub RadButton1_Click(sender As Object, e As EventArgs) Handles RadButton1.Click
        Dim filePath As String = FileUpload1.PostedFile.FileName
        Dim filename As String = Path.GetFileName(filePath)
        Dim ext As String = Path.GetExtension(filename)
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try

        If FileUpload1.HasFile Then
            Dim fs As Stream = FileUpload1.PostedFile.InputStream
            Dim br As New BinaryReader(fs)
            Dim bytes As Byte() = br.ReadBytes(fs.Length)

            Dim constr1 As String
            constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString

            Using con1 As New SqlConnection
                con1.ConnectionString = constr1
                con1.Open()
                Dim cmd1 As New SqlCommand
                cmd1.Connection = con1
                cmd1.CommandText = "insert into au_clubs(Name,Description,colid,Logo) values(@Name,@Description,'" & colid & "',@Logo)"
                cmd1.Parameters.AddWithValue("@Name", RadTextBox1.Text).DbType = DbType.String  ' = RadTextBox1.Text
                cmd1.Parameters.AddWithValue("@Description", TextBox1.Text).DbType = DbType.String
                cmd1.Parameters.AddWithValue("@Logo", bytes).DbType = DbType.Binary
                cmd1.ExecuteNonQuery()
                con1.Close()
            End Using
            Label1.Text = "Club details updated."
            ASPxGridView1.DataBind()


        Else

        End If
    End Sub
End Class
