﻿
Partial Class au_detailview
    Inherits System.Web.UI.Page

End Class
