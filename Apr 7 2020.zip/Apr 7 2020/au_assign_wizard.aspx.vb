﻿
Partial Class au_assign_wizard
    Inherits System.Web.UI.Page
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim facstring As String = HiddenField1.Value.ToString.Replace("undefined", "")
        If facstring = "" Then
            Label1.Text = "Please select faculties."
            Exit Sub
        End If
        Dim coursestring As String = HiddenField2.Value.ToString.Replace("undefined", "")
        If coursestring = "" Then
            Label1.Text = "Please select course."
            Exit Sub
        End If
        Label1.Text = Mid(facstring, 1, facstring.Length - 1)
        Label7.Text = Mid(coursestring, 1, coursestring.Length - 1)
        Dim ar1() As String = Mid(facstring, 1, facstring.Length - 1).Split("-")
        Dim ar2() As String = Mid(coursestring, 1, coursestring.Length - 1).Split("-")
        Dim colid As Integer = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Dim progid As Integer = Convert.ToInt32(RadComboBox5.SelectedValue.ToString)
        Dim branchid As Integer = Convert.ToInt32(RadComboBox3.SelectedValue.ToString)
        Dim deptid As Integer = Convert.ToInt32(RadComboBox4.SelectedValue.ToString)
        For i = 0 To ar1.Length - 1
            For j = 0 To ar2.Length - 1
                Dim facultyid As Integer = Convert.ToInt32(ar1(i).ToString)
                Dim courseid As Integer = Convert.ToInt32(ar2(j).ToString)
                SqlDataSource8.InsertParameters("colid").DefaultValue = colid
                SqlDataSource8.InsertParameters("empid").DefaultValue = facultyid
                SqlDataSource8.InsertParameters("branchid").DefaultValue = branchid
                SqlDataSource8.InsertParameters("deptid").DefaultValue = deptid
                SqlDataSource8.InsertParameters("progid").DefaultValue = progid
                SqlDataSource8.InsertParameters("courseid").DefaultValue = courseid
                SqlDataSource8.Insert()

            Next
        Next
        Label1.Text = "Faculty assigned."
        RadGrid3.DataBind()

    End Sub
    Protected Sub RadWizard1_FinishButtonClick(sender As Object, e As Telerik.Web.UI.WizardEventArgs) Handles RadWizard1.FinishButtonClick
        Dim facstring As String = HiddenField1.Value.ToString.Replace("undefined", "")
        If facstring = "" Then
            Label1.Text = "Please select faculties."
            Exit Sub
        End If
        Dim coursestring As String = HiddenField2.Value.ToString.Replace("undefined", "")
        If coursestring = "" Then
            Label1.Text = "Please select course."
            Exit Sub
        End If
        Label1.Text = Mid(facstring, 1, facstring.Length - 1)
        Label7.Text = Mid(coursestring, 1, coursestring.Length - 1)
        Dim ar1() As String = Mid(facstring, 1, facstring.Length - 1).Split("-")
        Dim ar2() As String = Mid(coursestring, 1, coursestring.Length - 1).Split("-")
        Dim colid As Integer = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Dim progid As Integer = Convert.ToInt32(RadComboBox5.SelectedValue.ToString)
        Dim branchid As Integer = Convert.ToInt32(RadComboBox3.SelectedValue.ToString)
        Dim deptid As Integer = Convert.ToInt32(RadComboBox4.SelectedValue.ToString)
        For i = 0 To ar1.Length - 1
            For j = 0 To ar2.Length - 1
                Dim facultyid As Integer = Convert.ToInt32(ar1(i).ToString)
                Dim courseid As Integer = Convert.ToInt32(ar2(j).ToString)
                SqlDataSource8.InsertParameters("colid").DefaultValue = colid
                SqlDataSource8.InsertParameters("empid").DefaultValue = facultyid
                SqlDataSource8.InsertParameters("branchid").DefaultValue = branchid
                SqlDataSource8.InsertParameters("deptid").DefaultValue = deptid
                SqlDataSource8.InsertParameters("progid").DefaultValue = progid
                SqlDataSource8.InsertParameters("courseid").DefaultValue = courseid
                SqlDataSource8.Insert()

            Next
        Next
        Label1.Text = "Faculty assigned."
        RadGrid3.DataBind()

    End Sub
End Class
