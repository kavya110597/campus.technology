﻿
Partial Class au_any_leave_apply_n1
    Inherits System.Web.UI.Page

End Class
