﻿
Partial Class au_estimate
    Inherits System.Web.UI.Page

    Protected Sub RadButton1_Click(sender As Object, e As EventArgs) Handles RadButton1.Click
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        Dim str1 As String
        str1 = "SELECT 1 AS Sl, 'Jan' AS Month, SUM(expectedamount) AS ExpectedAmount FROM au_clientdetails WHERE (colid = @colid) AND (expecteddate BETWEEN '1/1/2017' AND '1/31/2017') UNION SELECT 2 AS Sl, 'Feb' AS Month, SUM(expectedamount) AS ExpectedAmount FROM au_clientdetails AS au_clientdetails_11 WHERE (colid = @colid) AND (expecteddate BETWEEN '2/1/2017' AND '2/28/2017') UNION SELECT 3 AS Sl, 'Mar' AS Month, SUM(expectedamount) AS ExpectedAmount FROM au_clientdetails AS au_clientdetails_10 WHERE (colid = @colid) AND (expecteddate BETWEEN '3/1/2017' AND '3/31/2017') UNION SELECT 4 AS Sl, 'Apr' AS Month, SUM(expectedamount) AS ExpectedAmount FROM au_clientdetails AS au_clientdetails_9 WHERE (colid = @colid) AND (expecteddate BETWEEN '4/1/2017' AND '4/30/2017') UNION SELECT 5 AS Sl, 'May' AS Month, SUM(expectedamount) AS ExpectedAmount FROM au_clientdetails AS au_clientdetails_8 WHERE (colid = @colid) AND (expecteddate BETWEEN '5/1/2017' AND '5/31/2017') UNION SELECT 6 AS Sl, 'Jun' AS Month, SUM(expectedamount) AS ExpectedAmount FROM au_clientdetails AS au_clientdetails_7 WHERE (colid = @colid) AND (expecteddate BETWEEN '6/1/2017' AND '6/30/2017') UNION SELECT 7 AS Sl, 'Jul' AS Month, SUM(expectedamount) AS ExpectedAmount FROM au_clientdetails AS au_clientdetails_6 WHERE (colid = @colid) AND (expecteddate BETWEEN '7/1/2017' AND '7/31/2017') UNION SELECT 8 AS Sl, 'Aug' AS Month, SUM(expectedamount) AS ExpectedAmount FROM au_clientdetails AS au_clientdetails_5 WHERE (colid = @colid) AND (expecteddate BETWEEN '8/1/2017' AND '8/31/2017') UNION SELECT 9 AS Sl, 'Sep' AS Month, SUM(expectedamount) AS ExpectedAmount FROM au_clientdetails AS au_clientdetails_4 WHERE (colid = @colid) AND (expecteddate BETWEEN '9/1/2017' AND '9/30/2017') UNION SELECT 10 AS Sl, 'Oct' AS Month, SUM(expectedamount) AS ExpectedAmount FROM au_clientdetails AS au_clientdetails_3 WHERE (colid = @colid) AND (expecteddate BETWEEN '10/1/2017' AND '10/31/2017') UNION SELECT 11 AS Sl, 'Nov' AS Month, SUM(expectedamount) AS ExpectedAmount FROM au_clientdetails AS au_clientdetails_2 WHERE (colid = @colid) AND (expecteddate BETWEEN '11/1/2017' AND '11/30/2017') UNION SELECT 12 AS Sl, 'Dec' AS Month, SUM(expectedamount) AS ExpectedAmount FROM au_clientdetails AS au_clientdetails_1 WHERE (colid = @colid) AND (expecteddate BETWEEN '12/1/2017' AND '12/31/2017') ORDER BY Sl"
        If RadComboBox1.SelectedIndex > -1 Then
            SqlDataSource1.SelectCommand = str1.Replace("2017", RadComboBox1.SelectedValue.ToString)
            RadHtmlChart1.DataBind()

        End If

    End Sub
End Class
