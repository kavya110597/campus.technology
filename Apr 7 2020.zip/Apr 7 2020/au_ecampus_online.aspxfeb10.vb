﻿
Partial Class au_ecampus_online
    Inherits System.Web.UI.Page

    Protected Sub ASPxButton1_Click(sender As Object, e As EventArgs) Handles ASPxButton1.Click
        If ASPxComboBox1.SelectedIndex = -1 OrElse ASPxComboBox2.SelectedIndex = -1 Then
            Literal1.Text = "Please select Program and Course."
            Exit Sub
        End If
        Dim collegename As String
        collegename = Request.Cookies("collegename").Value.ToString
        Dim prog As String = ASPxComboBox1.SelectedItem.Text.ToString
        Dim course As String = ASPxComboBox2.SelectedItem.Text.ToString
        Dim path1 As String
        path1 = "files/" & collegename & "/ecampus/" & prog & "/" & course & "/"
        Dim dir1 As String = Server.MapPath(".") & "\files\" & collegename & "\ecampus\" & prog & "\" & course & "\"
        If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
            My.Computer.FileSystem.CreateDirectory(dir1)
        End If
        'Dim path2 As String = Server.MapPath(".") & "\files\" & collegename & "\events\" & filename
        Dim path3 As String = "~/" & path1
        If RadTextBox1.Text = "" Then
            Literal1.Text = "Please select filename"
            Exit Sub

        End If
        My.Computer.FileSystem.WriteAllText(dir1 & RadTextBox1.Text & ".html", ASPxHtmlEditor2.Html, False)
        Literal1.Text = "File created successfully." ' Location:" & dir1 & RadTextBox1.Text & ".html"
    End Sub
End Class
