﻿
Partial Class au_classify_fdp
    Inherits System.Web.UI.Page

    Protected Sub RadButton1_Click(sender As Object, e As EventArgs) Handles RadButton1.Click
        Literal1.Text = ""
        Dim date1 As Date

        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        Dim fieldValues As List(Of Object) = ASPxGridView1.GetSelectedFieldValues(New String() {"Id"})
        Dim i As Integer = 0
        For Each item As Object In fieldValues
            Dim str1 As String
            str1 = "Update activity_refresher set ForWhom=@payee where id=" & Convert.ToInt32(item) & " and colid=" & colid
            Dim cs1 As New schoolclass1
            cs1.insertdata(str1, RadComboBox1.SelectedValue.ToString)
            i = i + 1
        Next
        Literal1.Text = i.ToString & " records updated."
        ASPxGridView1.DataBind()

    End Sub
End Class
