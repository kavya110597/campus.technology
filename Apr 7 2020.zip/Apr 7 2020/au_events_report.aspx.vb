﻿
Partial Class au_events_report
    Inherits System.Web.UI.Page

End Class
