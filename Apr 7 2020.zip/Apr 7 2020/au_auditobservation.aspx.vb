﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Drawing
Partial Class au_auditobservation
    Inherits System.Web.UI.Page
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        LSeminar.Text = ""

        If type_rcb.SelectedItem Is Nothing OrElse [String].IsNullOrWhiteSpace(type_rcb.SelectedItem.Text) Then
            LSeminar.Text = "Please Select/enter all details."
            LSeminar.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If objective_rcb.SelectedItem Is Nothing OrElse [String].IsNullOrWhiteSpace(objective_rcb.SelectedItem.Text) Then
            LSeminar.Text = "Please Select/enter all details."
            LSeminar.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If control_rcb.SelectedItem Is Nothing OrElse [String].IsNullOrWhiteSpace(control_rcb.SelectedItem.Text) Then
            LSeminar.Text = "Please Select/enter all details."
            LSeminar.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If value_rcb.SelectedItem Is Nothing OrElse [String].IsNullOrWhiteSpace(value_rcb.SelectedItem.Text) Then
            LSeminar.Text = "Please Select/enter all details."
            LSeminar.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If TByear.Text = "" OrElse memo1.Text = "" Then
            LSeminar.Text = "Please Select/enter all details."
            LSeminar.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        SqlDataSource13.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        SqlDataSource13.InsertParameters("valueid").DefaultValue = Convert.ToInt32(value_rcb.SelectedValue.ToString)
        SqlDataSource13.InsertParameters("year").DefaultValue = TByear.Text
        SqlDataSource13.InsertParameters("type").DefaultValue = type_rcb.SelectedValue.ToString
        SqlDataSource13.InsertParameters("observation").DefaultValue = memo1.Text
        SqlDataSource13.Insert()
        LSeminar.Text = "Details Added."
        LSeminar.ForeColor = Drawing.Color.Green
        ASPxGridView2.DataBind()

    End Sub
End Class
