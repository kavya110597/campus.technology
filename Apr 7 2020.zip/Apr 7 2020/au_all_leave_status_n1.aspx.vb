﻿
Partial Class au_all_leave_status_n1
    Inherits System.Web.UI.Page

End Class
