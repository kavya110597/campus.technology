﻿
Partial Class au_allocation_edit
    Inherits System.Web.UI.Page

End Class
