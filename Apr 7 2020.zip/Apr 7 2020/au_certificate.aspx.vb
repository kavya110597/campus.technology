﻿
Partial Class faculty_au_certificate
    Inherits System.Web.UI.Page

End Class
