﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Data.OleDb
Imports System.Drawing
Partial Class au_actteaching
    Inherits System.Web.UI.Page
    Protected Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        LTeach.Text = ""
        If TBmethodname.Text = "" OrElse TBpo.Text = "" OrElse TextBox5.Text = "" OrElse TBstartdate5.Text = "" Then
            LTeach.Text = "Please enter all details."
            LTeach.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If IsDate(TBstartdate5.Text) = False Then
            LTeach.Text = "Invalid Date."
            LTeach.ForeColor = Drawing.Color.Red
            Exit Sub
        End If

        If FileUploadmethod.HasFile Then
            Dim file As HttpPostedFile = FileUploadmethod.PostedFile
            Dim filesize As Integer = file.ContentLength
            If filesize > 1000000 Then
                LTeach.Text = "File exceeds the maximum size limit i.e. 1MB"
                LTeach.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim extensionlist() As String = {".doc", ".docx", ".jpeg", ".gif", ".png", ".pdf", ".jpg"}
            Dim filename As String = Path.GetFileName(FileUploadmethod.FileName)
            Dim extension As String = Path.GetExtension(filename)

            If extensionlist.Contains(extension) = False Then
                LTeach.Text = "Invalid file extension.Please upload .doc or .pdf or .jpeg or .png or .jpg or .gif"
                LTeach.ForeColor = Drawing.Color.Red
                Exit Sub
            End If


            Dim path1 As String = "students/photos/" & filename
            Dim dir1 As String = Server.MapPath(".") & "\students\photos"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If
            Dim path2 As String = Server.MapPath(".") & "\students\photos\" & filename
            FileUploadmethod.SaveAs(path2)
            SqlDataSource20.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
            SqlDataSource20.InsertParameters("empid").DefaultValue = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)

            SqlDataSource20.InsertParameters("methodname").DefaultValue = TBmethodname.Text
            SqlDataSource20.InsertParameters("po").DefaultValue = TBpo.Text
            SqlDataSource20.InsertParameters("organizedby").DefaultValue = TextBox5.Text
            SqlDataSource20.InsertParameters("startdate").DefaultValue = Convert.ToDateTime(TBstartdate5.Text)
            SqlDataSource20.InsertParameters("type").DefaultValue = DropDownList8.SelectedValue.ToString()
            SqlDataSource20.InsertParameters("deliverymethod").DefaultValue = DLdeliverymethod.SelectedValue.ToString()
            SqlDataSource20.InsertParameters("certificate").DefaultValue = path1
            SqlDataSource20.Insert()
            LTeach.Text = "Teaching Method Added."
            LTeach.ForeColor = Drawing.Color.Green
            GridView4.DataBind()

        Else
            SqlDataSource20.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
            SqlDataSource20.InsertParameters("empid").DefaultValue = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)

            SqlDataSource20.InsertParameters("methodname").DefaultValue = TBmethodname.Text
            SqlDataSource20.InsertParameters("po").DefaultValue = TBpo.Text
            SqlDataSource20.InsertParameters("organizedby").DefaultValue = TextBox5.Text
            SqlDataSource20.InsertParameters("startdate").DefaultValue = Convert.ToDateTime(TBstartdate5.Text)
            SqlDataSource20.InsertParameters("type").DefaultValue = DropDownList8.SelectedValue.ToString()
            SqlDataSource20.InsertParameters("deliverymethod").DefaultValue = DLdeliverymethod.SelectedValue.ToString()
            SqlDataSource20.Insert()
            LTeach.Text = "Teaching Method Added."
            LTeach.ForeColor = Drawing.Color.Green
            GridView4.DataBind()
        End If
    End Sub
    Private Sub GridView4_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView4.RowCommand
        Labelmethod.Text = ""
        LTeach.Text = ""
        If e.CommandName = "save" Then
            Dim rowid As Integer = Convert.ToInt32(e.CommandArgument.ToString)
            Dim lbl1 As Label = CType(GridView4.Rows(rowid).FindControl("Labelid2method"), Label)
            Dim fileid As Integer = Convert.ToInt32(lbl1.Text.ToString)
            Dim FileUploadsave As FileUpload
            FileUploadsave = CType(GridView4.Rows(rowid).FindControl("FileUploadcertimethod"), FileUpload)
            Dim filename As String = ""
            Dim path1 As String = ""

            If FileUploadsave.HasFile Then
                Dim file As HttpPostedFile = FileUploadsave.PostedFile
                Dim filesize As Integer = file.ContentLength
                If filesize > 1000000 Then
                    Labelmethod.Text = "File exceeds the maximum size limit i.e. 1MB"
                    Labelmethod.ForeColor = Drawing.Color.Red
                    Exit Sub
                End If
                Dim extensionlist() As String = {".doc", ".docx", ".jpeg", ".gif", ".png", ".pdf", ".jpg"}
                filename = Path.GetFileName(FileUploadsave.FileName)
                Dim extension As String = Path.GetExtension(filename)

                If extensionlist.Contains(extension) = False Then
                    Labelmethod.Text = "Invalid file extension.Please upload .doc or .pdf or .jpeg or .png or .jpg or .gif"
                    Labelmethod.ForeColor = Drawing.Color.Red
                    Exit Sub
                End If
                path1 = "students/photos/" & filename
                Dim dir1 As String = Server.MapPath(".") & "\students\photos\"
                If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                    My.Computer.FileSystem.CreateDirectory(dir1)
                End If
                Dim path2 As String = Server.MapPath(".") & "\students\photos\" & filename

                FileUploadsave.SaveAs(path2)


            End If
            Dim str1 As String
            str1 = "Update activity_teaching set certificate=@path1 where Id=@id"
            updatedata(str1, path1, fileid)
            Labelmethod.Text = "File Uploaded."
            Labelmethod.ForeColor = Drawing.Color.Green
            GridView4.DataBind()

        End If
    End Sub
    Protected Sub BTeachExcel_Click(sender As Object, e As EventArgs) Handles BTeachExcel.Click
        LTeach.Text = ""
        If FileUpload4.HasFile Then
            Dim file As HttpPostedFile = FileUpload4.PostedFile
            Dim filesize As Integer = file.ContentLength
            If filesize > 4194304 Then
                LTeach.Text = "File exceeds the maximum size limit i.e. 4MB"
                LTeach.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim filename As String = Path.GetFileName(FileUpload4.FileName)
            Dim extension As String = Path.GetExtension(filename)



            If extension <> ".xls" AndAlso extension <> ".xlsx" Then
                LTeach.Text = "Invalid file extension.Please upload .xls or .xlsx file"
                LTeach.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim path1 As String = "employee/photos/" & filename
            Dim dir1 As String = Server.MapPath(".") & "\employee\files"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If
            Dim path2 As String = Server.MapPath(".") & "\employee\files\" & filename

            FileUpload4.SaveAs(path2)

            Dim constr1 As String

            constr1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & path2 & ";Extended Properties=""Excel 12.0 Xml;HDR=YES"";"
            Using con1 As New OleDbConnection
                con1.ConnectionString = constr1
                con1.Open()
                Dim cmd1 As New OleDbCommand
                cmd1.Connection = con1
                cmd1.CommandText = "Select * from [Sheet1$]"
                Dim rdr1 As OleDbDataReader = cmd1.ExecuteReader

                Do While rdr1.Read


                    Dim startdate As Date
                    Try
                        startdate = Convert.ToDateTime(rdr1.GetValue(1).ToString)

                    Catch ex As Exception
                        LTeach.Text = "Invalid Date."
                        LTeach.ForeColor = Drawing.Color.Red
                        Exit Sub
                    End Try
                    SqlDataSource20.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
                    SqlDataSource20.InsertParameters("empid").DefaultValue = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)

                    SqlDataSource20.InsertParameters("methodname").DefaultValue = rdr1.GetValue(0).ToString
                    SqlDataSource20.InsertParameters("po").DefaultValue = rdr1.GetValue(2).ToString
                    SqlDataSource20.InsertParameters("organizedby").DefaultValue = rdr1.GetValue(3).ToString
                    SqlDataSource20.InsertParameters("startdate").DefaultValue = startdate
                    SqlDataSource20.InsertParameters("type").DefaultValue = rdr1.GetValue(4).ToString
                    SqlDataSource20.InsertParameters("deliverymethod").DefaultValue = rdr1.GetValue(5).ToString
                    SqlDataSource20.Insert()


                    GridView4.DataBind()



                Loop
                rdr1.Close()
                con1.Close()
            End Using

            LTeach.Text = "Teaching Method(s) Added."
            LTeach.ForeColor = Drawing.Color.Green
            GridView4.DataBind()
        Else
            LTeach.Text = "File is either not Selected or is Empty."
            LTeach.ForeColor = Drawing.Color.Red
            Exit Sub
        End If

    End Sub
    Public Sub updatedata(ByVal str As String, ByVal path1 As String, ByVal rowid As Integer)
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = str

            cmd1.Parameters.AddWithValue("@id", rowid).DbType = DbType.Int32
            cmd1.Parameters.AddWithValue("@path1", path1).DbType = DbType.String
            cmd1.ExecuteNonQuery()
            con1.Close()

        End Using
    End Sub
End Class
