﻿
Partial Class au_bos_minutes_s1
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Literal1.Text = ""
        If DropDownList1.SelectedIndex = -1 OrElse DropDownList2.SelectedIndex = -1 OrElse DropDownList3.SelectedIndex = -1 Then
            Literal1.Text = "All fields are required."
            Exit Sub
        End If
        Dim dep1 As String = DropDownList3.SelectedValue.ToString
        Dim coursetype As String = DropDownList2.SelectedValue.ToString
        Dim academicyear As String = DropDownList1.SelectedValue.ToString


        Dim cooki1 As New HttpCookie("AcademicYear")
        cooki1.Value = academicyear.ToString
        cooki1.Expires = DateTime.Now.AddMinutes(180)

        Dim cooki3 As New HttpCookie("CourseType")
        cooki3.Value = coursetype.ToString
        cooki3.Expires = DateTime.Now.AddMinutes(180)

        Dim cooki6 As New HttpCookie("dep1")
        cooki6.Value = dep1.ToString
        cooki6.Expires = DateTime.Now.AddMinutes(180)


        Response.Cookies.Add(cooki1)
        Response.Cookies.Add(cooki3)
        Response.Cookies.Add(cooki6)

        Literal1.Text = "<a href=""au_bos_minutes_s2.aspx"" target=""_blank"">Click here to generate report</a>"



    End Sub

End Class
