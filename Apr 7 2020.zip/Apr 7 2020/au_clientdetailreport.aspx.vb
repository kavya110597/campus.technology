﻿Imports System.Data.SqlClient
Imports System.Data
Imports DevExpress.XtraPrinting
Partial Class au_clientdetailreport
    Inherits System.Web.UI.Page
    Protected Sub ImageExcel_Click(sender As Object, e As ImageClickEventArgs) Handles ImageExcel.Click

        ASPxGridViewExporter1.GridViewID = "ASPxGridView1"

        ASPxGridViewExporter1.WriteXlsxToResponse(New XlsxExportOptionsEx With {.ExportType = DevExpress.Export.ExportType.WYSIWYG})
    End Sub
    Public Function GetExpenses(ByVal id As Integer) As String
        Dim expenses As String = ""
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "select clientid,sum(expenses) from au_client_te where clientid=" & id & " group by clientid"
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                expenses = rdr1.GetValue(1).ToString
            Loop
            rdr1.Close()
            con1.Close()
        End Using
        Return expenses
    End Function
    Public Function GetPayment(ByVal id As Integer) As String
        Dim expenses As String = ""
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "select clientid, sum(PaymentReceived) from au_milestone where clientid=" & id & " group by clientid"
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                expenses = rdr1.GetValue(1).ToString
            Loop
            rdr1.Close()
            con1.Close()
        End Using
        Return expenses

    End Function

    Public Function GetActivities(ByVal id As Integer) As String
        Dim expenses As String = ""
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "SELECT description + ', ' AS 'data()' " &
"FROM  " &
"(Select convert(varchar(11),dateofwork,106) + ' ' + description as description from au_client_te  " &
"where clientid=" & id & ") as a " &
"FOR XML PATH('')"
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                expenses = rdr1.GetValue(0).ToString
            Loop
            rdr1.Close()
            con1.Close()
        End Using
        Return expenses
    End Function
End Class
