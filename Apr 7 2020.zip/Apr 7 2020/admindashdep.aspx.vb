﻿Imports AjaxControlToolkit

Partial Class admindashdep
    Inherits System.Web.UI.Page

    Protected Sub AjaxFileUploadEvent(ByVal sender As Object, ByVal e As AjaxFileUploadEventArgs)
        Dim filename As String = System.IO.Path.GetFileName(e.FileName)
        Dim strUploadPath As String = "~/Folder/"

        Dim path1 As String

        path1 = "ajax/" & filename
        Dim dir1 As String = Server.MapPath(".") & "\ajax"
        If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
            My.Computer.FileSystem.CreateDirectory(dir1)
        End If
        Dim path2 As String = Server.MapPath(".") & "\ajax\" & filename

        AjaxFileUpload1.SaveAs(path2)

        Dim str1 As String
        str1 = "Insert into nba_depdoc(filename,location,group,keyword) values('" & filename & "','" & path1 & "','" & TextBox2.Text & "','" & TextBox3.Text & "')"
        Dim cs1 As New schoolclass1
        cs1.insertdata(str1)

        Literal1.Text = filename & " uploaded successfully."
        Label2.Text = filename & " uploaded successfully."

        'AjaxFileUpload1.SaveAs(Server.MapPath(strUploadPath) + filename)

    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If DropDownList1.SelectedIndex = -1 Then
            Exit Sub
        End If
        Dim branchid As Integer = Convert.ToInt32(DropDownList1.SelectedValue.ToString)
        Dim depname As String = TextBox1.Text
        Dim colid As Integer = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Dim str1 As String
        str1 = "Insert into depall1(colid,branchid,depname) values('" & colid & "','" & branchid & "',@payee)"
        Dim cs1 As New schoolclass1
        cs1.insertdata(str1, depname)
        ListView2.DataBind()
        'Response.Redirect("admindashdep.aspx")
        GridView2.DataSourceID = SqlDataSource14.ID
        GridView2.DataBind()
        'Dim gv1 As GridView = CType(UpdatePanel1.FindControl("GridView1"), GridView)
        'gv1.DataBind()

        'UpdatePanel1.Update()

    End Sub
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        ListView2.Visible = False
        Page.MaintainScrollPositionOnPostBack = True
        AddHandler GridView2.PreRender, AddressOf GridView2_PreRender


        If Not Page.IsPostBack Then
            Panel1.Visible = False
            makeinvisible()

        End If
    End Sub
    Public Sub makeinvisible()
        facpanel.Visible = False
    End Sub

    Private Sub admindashdep_LoadComplete(sender As Object, e As EventArgs) Handles Me.LoadComplete
        ListView1.DataBind()

    End Sub
    Protected Sub ListView2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView2.SelectedIndexChanged

    End Sub

    Private Sub ListView2_ItemCommand(sender As Object, e As ListViewCommandEventArgs) Handles ListView2.ItemCommand
        If e.CommandName = "Info" Then
            Label1.Text = e.CommandArgument
            GridView1.DataBind()
            makeinvisible()

            Panel1.Visible = True
            Panel2.Visible = False

        End If

    End Sub
    Protected Sub ImageButton2_Click(sender As Object, e As ImageClickEventArgs) Handles ImageButton2.Click
        makeinvisible()
        GridView1.DataBind()

        facpanel.Visible = True

    End Sub
    Protected Sub ImageButton8_Click(sender As Object, e As ImageClickEventArgs) Handles ImageButton8.Click
        makeinvisible()
        Panel2.Visible = True
        Panel1.Visible = False

    End Sub
    Protected Sub GridView2_SelectedIndexChanged(sender As Object, e As EventArgs) Handles GridView2.SelectedIndexChanged

    End Sub

    Private Sub GridView2_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView2.RowCommand
        If e.CommandName = "Details" Then
            Dim lnk1 As LinkButton
            lnk1 = CType(e.CommandSource, LinkButton)
            Label1.Text = lnk1.CommandArgument
            makeinvisible()
            Panel1.Visible = True
            Panel2.Visible = False
            'UpdatePanel1.Update()


        End If
        If e.CommandName = "Faculty" Then
            Dim lnk1 As ImageButton
            lnk1 = CType(e.CommandSource, ImageButton)
            Label1.Text = lnk1.CommandArgument
            GridView1.DataBind()
            makeinvisible()
            GridView1.DataBind()
            Panel2.Visible = False
            Panel1.Visible = True

            facpanel.Visible = True
        End If
    End Sub
    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        adddiv1.Visible = True

    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        adddiv1.Visible = False
    End Sub

    Private Sub GridView2_PreRender(sender As Object, e As EventArgs) Handles GridView2.PreRender
        GridView2.DataBind()
        If GridView2.Rows.Count > 0 Then
            'This replaces <td> with <th> And adds the scope attribute
            GridView2.UseAccessibleHeader = True

            'This will add the <thead> And <tbody> elements
            GridView2.HeaderRow.TableSection = TableRowSection.TableHeader

            'This adds the <tfoot> element. 
            'Remove if you don't have a footer row
            'GridView2.FooterRow.TableSection = TableRowSection.TableFooter
        End If
    End Sub
End Class
