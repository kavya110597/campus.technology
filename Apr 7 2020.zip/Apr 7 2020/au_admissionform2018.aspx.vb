﻿Imports System.Data.SqlClient
Partial Class faculty_au_admissionform2018
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim colid As Integer = Convert.ToInt32(Request.QueryString("colid").ToString)
        If DropDownList2.SelectedIndex = -1 Then
            Label1.Text = "Please select course."
            Label1.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If DropDownList1.SelectedIndex = -1 Then
            Label1.Text = "Please select gender."
            Label1.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If DropDownList2.SelectedIndex = -1 Then
            Label1.Text = "Please select category."
            Label1.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If DropDownList5.SelectedIndex = -1 Then
            Label1.Text = "Please select YOP in 10th."
            Label1.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If DropDownList4.SelectedIndex = -1 Then
            Label1.Text = "Please select YOP in 12th."
            Label1.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If IsDate(TextBox6.Text) = False Then
            Label1.Text = "Invalid Date."
            Label1.ForeColor = Drawing.Color.Red

            Exit Sub
        End If
        If Not IsNumeric(TextBox22.Text) Then
            Label1.Text = "Invalid  Marks."
            Label1.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If Not IsNumeric(TextBox27.Text) Then
            Label1.Text = "Invalid  Marks."
            Label1.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If CheckBox6.Checked = False Then
            Label1.Text = "Confirm and declare"
            Label1.ForeColor = Drawing.Color.Red
        End If
        SqlDataSource2.InsertParameters("colid").DefaultValue = Request.QueryString("colid").ToString
        SqlDataSource2.InsertParameters("course").DefaultValue = DropDownList2.SelectedValue.ToString
        SqlDataSource2.InsertParameters("candidatename").DefaultValue = TextBox1.Text
        SqlDataSource2.InsertParameters("Contact").DefaultValue = TextBox2.Text
        SqlDataSource2.InsertParameters("Email").DefaultValue = TextBox3.Text

        SqlDataSource2.InsertParameters("DOB").DefaultValue = TextBox6.Text
        SqlDataSource2.InsertParameters("Gender").DefaultValue = DropDownList1.SelectedValue.ToString ' RadComboBox1.SelectedValue.ToString ' TextBox29.Text
        SqlDataSource2.InsertParameters("Category").DefaultValue = DropDownList3.SelectedValue.ToString

        SqlDataSource2.InsertParameters("Address1").DefaultValue = TextBox4.Text
        SqlDataSource2.InsertParameters("Address2").DefaultValue = TextBox5.Text
        SqlDataSource2.InsertParameters("Nameofinstitute10").DefaultValue = TextBox19.Text
        SqlDataSource2.InsertParameters("Board10").DefaultValue = TextBox20.Text
        SqlDataSource2.InsertParameters("registrationnumber10").DefaultValue = TextBox21.Text
        SqlDataSource2.InsertParameters("totalmarks10").DefaultValue = Convert.ToDouble(TextBox22.Text)
        SqlDataSource2.InsertParameters("YOP10").DefaultValue = DropDownList5.SelectedItem.ToString
        SqlDataSource2.InsertParameters("Nameofinstitute12").DefaultValue = TextBox24.Text
        SqlDataSource2.InsertParameters("Board12").DefaultValue = TextBox25.Text
        SqlDataSource2.InsertParameters("registrationnumber12").DefaultValue = TextBox26.Text
        SqlDataSource2.InsertParameters("totalmarks12").DefaultValue = Convert.ToDouble(TextBox27.Text)
        SqlDataSource2.InsertParameters("YOP12").DefaultValue = DropDownList4.SelectedItem.ToString
        SqlDataSource2.InsertParameters("Fathername").DefaultValue = TextBox7.Text
        SqlDataSource2.InsertParameters("Fathercontact").DefaultValue = TextBox8.Text
        SqlDataSource2.InsertParameters("mothername").DefaultValue = TextBox9.Text
        SqlDataSource2.InsertParameters("mothercontact").DefaultValue = TextBox10.Text
        SqlDataSource2.InsertParameters("nationality").DefaultValue = TextBox11.Text
        SqlDataSource2.InsertParameters("religion").DefaultValue = TextBox12.Text
        SqlDataSource2.InsertParameters("placeofbirth").DefaultValue = TextBox13.Text
        SqlDataSource2.InsertParameters("mothertongue").DefaultValue = TextBox14.Text
        SqlDataSource2.InsertParameters("Bloodgroup").DefaultValue = TextBox15.Text
        SqlDataSource2.InsertParameters("Languagesknown").DefaultValue = TextBox16.Text
        SqlDataSource2.InsertParameters("medium").DefaultValue = TextBox17.Text
        SqlDataSource2.InsertParameters("aadhar").DefaultValue = TextBox18.Text
        SqlDataSource2.InsertParameters("declaration").DefaultValue = CheckBox6.Checked
        SqlDataSource2.Insert()
        Label1.Text = "Information submitted successfully."
        Label1.ForeColor = Drawing.Color.Green
        Response.Redirect("au_admissionform2018ty.aspx?colid=" & colid)

    End Sub

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.QueryString("colid").ToString)
        Catch ex As Exception

        End Try
        If Not Page.IsPostBack Then

            Dim ret1 As String = photoselect(colid)
            Dim array1 As String() = ret1.Split("~")
            Dim collegename As String = array1(0).ToString()
            Dim logo As String = array1(1).ToString()
            Literal1.Text = collegename.ToUpper.ToString

            Image1.ImageUrl = logo
        End If

    End Sub
    Protected Function photoselect(ByVal colid As Integer) As String
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString
        Dim path1 As String
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1

            cmd1.CommandText = "SELECT NameOfCollege,logo from collegedetails where Id=" & colid


            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read

                path1 = rdr1.GetValue(0).ToString & "~" & rdr1.GetValue(1).ToString

            Loop
            rdr1.Close()
            con1.Close()
        End Using

        Return path1
    End Function

End Class
