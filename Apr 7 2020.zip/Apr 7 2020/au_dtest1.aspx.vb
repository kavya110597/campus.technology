﻿
Partial Class au_dtest1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub
    Public Sub populate()
        ViewState("str1") = ""


        addtextbox(1, "Your city", "text")
        addtextbox(2, "Date of Birth", "date")
        addtextbox(3, "No of cars", "number")
        addtextbox(4, "Preferred location", "text")
        addtextbox(5, "Address", "text")


        addrb1(6, "Capital of India", "Delhi,Kolkata,Bangalore,Chennai")
        addrb1(7, "Garden City", "Delhi,Kolkata,Bangalore,Chennai")
        addrb1(8, "Financial capital", "Delhi,Kolkata,Bangalore,Chennai")



    End Sub
    Public Sub addtextbox(ByVal k As Integer, ByVal question1 As String, ByVal type As String)
        ViewState("str1") = ViewState("str1") & k.ToString & ","
        Dim l1 As New Literal
        l1.Text = "<b>" & question1 & "</b>" & "<br><br>"
        PlaceHolder1.Controls.Add(l1)
        Dim t1 As New TextBox
        t1.CssClass = "form-control"
        t1.Attributes.Add("required", "true")
        t1.Attributes.Add("type", type)
        t1.ID = k.ToString
        PlaceHolder1.Controls.Add(t1)
        PlaceHolder1.Controls.Add(New LiteralControl("<br><br>"))
    End Sub
    Public Sub addrb1(ByVal k As Integer, ByVal question1 As String, ByVal option1 As String)
        ViewState("str1") = ViewState("str1") & k.ToString & ","
        Dim l1 As New Literal
        l1.Text = "<b>" & question1 & "</b>" & "<br><br>"
        PlaceHolder1.Controls.Add(l1)
        Dim rb1 As New RadioButtonList
        rb1.ID = k.ToString
        Dim ar1() As String = option1.Split(",")
        For i = 0 To ar1.Length - 1
            rb1.Items.Add(New ListItem(ar1(i).ToString, ar1(i).ToString))

        Next
        rb1.CssClass = "form-control"
        rb1.Items(0).Selected = True
        'rb1.Attributes.Add("required", "true")

        PlaceHolder1.Controls.Add(rb1)
        Dim l2 As New Literal
        l2.Text = "<br><br>"
        PlaceHolder1.Controls.Add(l2)

    End Sub
    Public Sub getdata()
        Dim ar1() As String = ViewState("str1").split(",")
        Dim str1 As String
        Dim cs1 As New schoolclass1
        '  str1 = "Delete from surveyqresult where examid=" & examid & " and studid=" & studid
        'str1 = "Delete from surveyqresultcopy1 where examid=" & examid & " and studid=" & studid & " and type1='" & type1 & "' and month='" & Month() & "' and year='" & Year() & "' and  colid='" & colid & "' and teacherid=" & teacherid
        ' Literal2.Text = Literal2.Text & str1 & "<br>"
        'cs1.insertdata(str1)
        Dim chk1 As Boolean = True
        For i = 0 To ar1.Length - 2
            'MsgBox(ar1(i))
            Dim arq12() As String = ar1(i).ToString.Split("-")
            Dim qvalue12 As String
            qvalue12 = Request.Form("ctl00$ContentPlaceHolder1$" & ar1(i))
            'qvalue12 = Request.Form("RadioButtonList1") ctl00$ContentPlaceHolder1$TBseminarname
            'qvalue12 = Request.Form(ar1(i))
            'str1 = str1 & "," & ar1(i).ToString & "-" & qvalue12
            If qvalue12 <> "" Then
                'insertdata(ar1(i).ToString)
                Literal1.Text = Literal1.Text & "<br>" & ar1(i).ToString & " - " & qvalue12
                'str1 = "Insert into sexamresult(examid,studid,optionid) values('" & examid & "','" & studid & "','" & qvalue12 & "')"
                ' str1 = "Insert into surveyqresult(examid,studid,optionid) values('" & examid & "','-1','" & qvalue12 & "')"
                'str1 = "Insert into surveyqresultcopy1(examid,studid,optionid,type1,group1,month,year,teacherid,colid) values('" & examid & "','" & studid & "','" & qvalue12 & "',@payee,@category,'" & Month() & "','" & Year() & "','" & teacherid & "','" & colid & "')"
                '  str1 = "Insert into surveyqresult(examid,studid,optionid,type1,teacherid) values('" & examid & "','" & studid & "','" & qvalue12 & "',@payee,'" & teacherid & "')"
                ' Literal2.Text = Literal2.Text & str1 & "<br>"
                'cs1.insertdata(str1, type1, group1)

            End If
        Next
    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        getdata()
        populate()


    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        populate()

    End Sub
End Class
