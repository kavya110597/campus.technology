﻿
Partial Class au_api_code
    Inherits System.Web.UI.Page

End Class
