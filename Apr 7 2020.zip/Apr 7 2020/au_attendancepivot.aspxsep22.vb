﻿
Partial Class au_attendancepivot
    Inherits System.Web.UI.Page

End Class
