﻿Imports System.Data.SqlClient
Partial Class faculty_au_admissionform2018ty
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.QueryString("colid").ToString)
        Catch ex As Exception

        End Try
        If Not Page.IsPostBack Then

            Dim ret1 As String = photoselect(colid)
            Dim array1 As String() = ret1.Split("~")
            Dim collegename As String = array1(0).ToString()
            Dim logo As String = array1(1).ToString()
            Literal1.Text = collegename.ToUpper.ToString

            Image1.ImageUrl = logo
        End If

    End Sub
    Protected Function photoselect(ByVal colid As Integer) As String
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString
        Dim path1 As String
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1

            cmd1.CommandText = "SELECT NameOfCollege,logo from collegedetails where Id=" & colid


            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read

                path1 = rdr1.GetValue(0).ToString & "~" & rdr1.GetValue(1).ToString

            Loop
            rdr1.Close()
            con1.Close()
        End Using

        Return path1
    End Function
End Class
