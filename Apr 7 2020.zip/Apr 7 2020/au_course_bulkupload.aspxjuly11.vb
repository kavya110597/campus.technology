﻿Imports System.IO
Imports System.Data.OleDb
Imports DevExpress.XtraPrinting
Imports Telerik.Web.UI
Imports System.Data
Imports System.Data.SqlClient
Partial Class faculty_au_course_bulkupload
    Inherits System.Web.UI.Page

    Protected Sub ImageWord_Click(sender As Object, e As ImageClickEventArgs) Handles ImageWord.Click

        ASPxGridViewExporter1.GridViewID = "ASPxGridView6"

        ASPxGridViewExporter1.WriteRtfToResponse()

    End Sub
    Protected Sub ImageExcel_Click(sender As Object, e As ImageClickEventArgs) Handles ImageExcel.Click

        ASPxGridViewExporter1.GridViewID = "ASPxGridView6"

        ASPxGridViewExporter1.WriteXlsxToResponse(New XlsxExportOptionsEx With {.ExportType = DevExpress.Export.ExportType.WYSIWYG})
    End Sub
    Protected Sub ImagePDF_Click(sender As Object, e As ImageClickEventArgs) Handles ImagePDF.Click

        ASPxGridViewExporter1.GridViewID = "ASPxGridView6"

        Dim options As New DevExpress.XtraPrinting.PdfExportOptions

        options.Compressed = False
        ASPxGridViewExporter1.WritePdfToResponse(options)

    End Sub
    Protected Sub BstudExcel_Click(sender As Object, e As EventArgs) Handles BstudExcel.Click

        Label1.Text = ""
        'If RadComboBox1.SelectedIndex = -1 Then
        '    Label1.Text = "Select Branch"
        '    'Label1.ForeColor = Drawing.Color.Red
        '    Exit Sub
        'End If
        If RadComboBox2.SelectedIndex = -1 Then
            Label1.Text = "Select Department"
            'Label1.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If RadComboBox3.SelectedIndex = -1 Then
            Label1.Text = "Select Program"
            'Label1.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If FileUpload1.HasFile Then
            Dim file As HttpPostedFile = FileUpload1.PostedFile
            Dim filesize As Integer = file.ContentLength
            If filesize > 4194304 Then
                Label1.Text = "File exceeds the maximum size limit i.e. 4MB"
                ' Label1.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            'Dim extensionlist() As String = {".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".txt", ".rtf", ".bmp", ".jpeg", ".gif", ".tiff", ".png", ".pcx", ".emf", ".rle", ".dib", ".pdf"}
            Dim filename As String = Path.GetFileName(FileUpload1.FileName)
            Dim extension As String = Path.GetExtension(filename)

            'If extensionlist.Contains(extension) = False Then
            '    Page.ClientScript.RegisterStartupScript(Me.[GetType](), "Alert", "alert('Invalid file extension.Please upload .jpeg or .png or .jpg image');", True)

            '    Exit Sub
            'End If

            If extension <> ".xls" AndAlso extension <> ".xlsx" Then
                Label1.Text = "Invalid file extension.Please upload .xls or .xlsx file"
                'Label1.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim path1 As String = "employee/photos/" & filename
            Dim dir1 As String = Server.MapPath(".") & "\employee\files"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If
            Dim path2 As String = Server.MapPath(".") & "\employee\files\" & filename

            FileUpload1.SaveAs(path2)

            'Dim msg1 As New msgbox11

            Dim constr1 As String

            constr1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & path2 & ";Extended Properties=""Excel 12.0 Xml;HDR=YES"";"
            Using con1 As New OleDbConnection
                con1.ConnectionString = constr1
                con1.Open()
                Dim cmd1 As New OleDbCommand
                cmd1.Connection = con1
                cmd1.CommandText = "Select * from [Sheet1$]"
                Dim rdr1 As OleDbDataReader = cmd1.ExecuteReader

                Do While rdr1.Read

                    Try
                        SqlDataSource4.InsertParameters("colid").DefaultValue = Request.Cookies("colid").Value.ToString
                        ' SqlDataSource4.InsertParameters("branchid").DefaultValue = Convert.ToInt32(RadComboBox1.SelectedValue.ToString())
                        SqlDataSource4.InsertParameters("deptid").DefaultValue = Convert.ToInt32(RadComboBox2.SelectedValue.ToString())
                        SqlDataSource4.InsertParameters("programid").DefaultValue = Convert.ToInt32(RadComboBox3.SelectedValue.ToString())

                        SqlDataSource4.InsertParameters("coursename").DefaultValue = rdr1.GetValue(0).ToString
                        SqlDataSource4.InsertParameters("coursecode").DefaultValue = rdr1.GetValue(1).ToString
                        SqlDataSource4.InsertParameters("dateofintroduction").DefaultValue = Convert.ToDateTime(rdr1.GetValue(2).ToString)
                        SqlDataSource4.InsertParameters("CourseCredit").DefaultValue = rdr1.GetValue(3).ToString

                        SqlDataSource4.Insert()
                        ASPxGridView6.DataBind()
                    Catch ex As Exception
                        Label1.Text = "Invalid Data Entry."
                    'Label1.ForeColor = Drawing.Color.Red
                    Exit Sub
                    End Try

                Loop
                rdr1.Close()
                con1.Close()
            End Using

            Label1.Text = "Data updated successfully."
            'Label1.ForeColor = Drawing.Color.Green

            ASPxGridView6.DataBind()
        Else
            Label1.Text = "File is either not Selected or is Empty."
            'Label1.ForeColor = Drawing.Color.Red
            Exit Sub
        End If

    End Sub
End Class
