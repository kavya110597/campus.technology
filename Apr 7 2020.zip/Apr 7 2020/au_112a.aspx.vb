﻿Imports Telerik.Web.UI.ExportInfrastructure
Imports Telerik.Web.UI
Partial Class faculty_au_112a
    Inherits System.Web.UI.Page

    Protected Sub RadGrid1_InfrastructureExporting(sender As Object, e As Telerik.Web.UI.GridInfrastructureExportingEventArgs) Handles RadGrid1.InfrastructureExporting

        Dim exportStructure As ExportStructure = e.ExportStructure

        Dim table As Telerik.Web.UI.ExportInfrastructure.Table = exportStructure.Tables(0)

        table.ShiftRowsDown(1, 3)

        table.Cells("A1").Value = "1. Curricular Aspects (100)"
        table.Cells("A2").Value = "1.1 Curriculum Design and Development  (50)"
        table.Cells("A3").Value = "1.1.2 Percentage of Programmes where syllabus revision was carried out during the last five years (20)"

    End Sub
    Protected Sub RadButton1_Click(sender As Object, e As EventArgs) Handles RadButton1.Click
        Panel1.Visible = False
        Literal1.Text = ""
        If RadGrid1.Items.Count < 6 Then
            Literal1.Text = RadGrid1.Items.Count
            Literal3.Text = "High"
            Panel1.Visible = True

        Else
            'Literal1.Text = "Number of certificate courses: " & RadGrid1.Items.Count.ToString & ". No suggestions.<br>"
            Panel1.Visible = False

        End If
    End Sub
    Protected Sub ASPxButton1_Click(sender As Object, e As EventArgs) Handles ASPxButton1.Click
        Label1.Text = ""
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        Dim empid As Integer = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
        Dim str1 As String
        str1 = "Update au_accr_status set status='Completed',empid='" & empid & "' where colid='" & colid & "' and accr='NAAC' and questions='1.1.2' and type1='ACollege' and cr='1'"
        Dim cs1 As New schoolclass1
        cs1.insertdata(str1)
        Label1.Text = "Status is updated"
    End Sub
    Protected Sub ASPxButton2_Click(sender As Object, e As EventArgs) Handles ASPxButton2.Click
        Label1.Text = ""
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        Dim empid As Integer = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
        Dim str1 As String
        str1 = "Update au_accr_status set status='Pending',empid='" & empid & "' where colid='" & colid & "' and accr='NAAC' and questions='1.1.2' and type1='ACollege' and cr='1'"
        Dim cs1 As New schoolclass1
        cs1.insertdata(str1)
        Label1.Text = "Status is updated"
    End Sub
End Class