﻿Imports System.IO
Imports System.IO.Path

Partial Class au_ecampus_online_edit
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub
    Protected Sub ASPxButton1_Click(sender As Object, e As EventArgs) Handles ASPxButton1.Click
        If ASPxComboBox1.SelectedIndex = -1 OrElse ASPxComboBox2.SelectedIndex = -1 Then
            Literal1.Text = "Please select Program and Course."
            Exit Sub
        End If
        Dim collegename As String
        collegename = Request.Cookies("collegename").Value.ToString
        Dim prog As String = ASPxComboBox1.SelectedItem.Text.ToString
        Dim course As String = ASPxComboBox2.SelectedItem.Text.ToString
        Dim path1 As String
        path1 = "files/" & collegename & "/ecampus/" & prog & "/" & course & "/"
        Dim dir1 As String = Server.MapPath(".") & "\files\" & collegename & "\ecampus\" & prog & "\" & course & "\"
        If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
            My.Computer.FileSystem.CreateDirectory(dir1)
        End If
        'Dim path2 As String = Server.MapPath(".") & "\files\" & collegename & "\events\" & filename
        Dim path3 As String = "~/" & path1
        'If RadTextBox1.Text = "" Then
        '    Literal1.Text = "Please select filename"
        '    Exit Sub

        'End If
        'My.Computer.FileSystem.WriteAllText(dir1 & RadTextBox1.Text & ".html", ASPxHtmlEditor2.Html, False)
        Dim dir2 As String = "C:\inetpub\wwwroot\campus\erpnew\faculty" & "\files\" & collegename & "\ecampus\" & prog & "\" & course & "\" & ASPxComboBox3.Value.ToString
        My.Computer.FileSystem.WriteAllText(dir2, ASPxHtmlEditor2.Html, False)
        Literal1.Text = "File saved successfully." ' Location:" & dir1 & RadTextBox1.Text & ".html"
        ASPxHtmlEditor2.Html = ""
    End Sub
    Protected Sub ASPxButton2_Click(sender As Object, e As EventArgs) Handles ASPxButton2.Click
        Dim collegename As String
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        collegename = Request.Cookies("collegename").Value.ToString

        'collegename = Request.Cookies("collegename").Value.ToString
        Dim prog As String = ASPxComboBox1.SelectedItem.Text.ToString
        Dim course As String = ASPxComboBox2.SelectedItem.Text.ToString
        Dim path1 As String
        path1 = "files/" & collegename & "/ecampus/" & prog & "/" & course & "/"
        path1 = "files/" & collegename & "/ecampus/" & prog & "/" & course & "/"
        'Dim dir1 As String = Server.MapPath(".") & "\files\" & collegename & "\ecampus\" & prog & "\" & course & "\"
        Dim dir1 As String = "C:\inetpub\wwwroot\campus\erpnew\faculty" & "\files\" & collegename & "\ecampus\" & prog & "\" & course & "\"
        If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
            My.Computer.FileSystem.CreateDirectory(dir1)
        End If
        ASPxComboBox3.Items.Clear()

        Dim filepaths() As String = Directory.GetFiles(dir1)
        For Each file As String In filepaths
            Dim filename As String = Path.GetFileName(file)
            If filename.Contains("doc") OrElse filename.Contains("html") Then
                ASPxComboBox3.Items.Add(filename)
            End If

        Next
    End Sub
    Protected Sub ASPxButton3_Click(sender As Object, e As EventArgs) Handles ASPxButton3.Click
        Dim collegename As String
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        collegename = Request.Cookies("collegename").Value.ToString

        'collegename = Request.Cookies("collegename").Value.ToString
        Dim prog As String = ASPxComboBox1.SelectedItem.Text.ToString
        Dim course As String = ASPxComboBox2.SelectedItem.Text.ToString
        If ASPxComboBox3.SelectedIndex = -1 Then
            Exit Sub

        End If
        Dim dir1 As String = "C:\inetpub\wwwroot\campus\erpnew\faculty" & "\files\" & collegename & "\ecampus\" & prog & "\" & course & "\" & ASPxComboBox3.Value.ToString
        ASPxHtmlEditor2.Html = My.Computer.FileSystem.ReadAllText(dir1)

    End Sub
End Class
