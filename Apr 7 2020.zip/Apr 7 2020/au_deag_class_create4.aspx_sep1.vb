﻿Imports System
Imports System.Collections
Imports System.Collections.Specialized
Imports System.Globalization
Imports System.Web.UI
Imports Telerik.Web.UI
Imports Telerik.Web.UI.Scheduler.Views

Partial Class au_deag_class_create4
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub
    Protected Sub RadGrid1_RowDrop(sender As Object, e As GridDragDropEventArgs) Handles RadGrid1.RowDrop
        Dim item As GridDataItem = e.DraggedItems(0)
        Dim id As Integer = Convert.ToInt32(item("id").Text)
        Dim courseid As Integer = Convert.ToInt32(item("courseid").Text)
        Dim programid As Integer = Convert.ToInt32(item("progid").Text)
        Dim coursename As String = item("coursename").Text
        Dim batch As String = item("batch").Text
        Dim semester As String = item("semester").Text
        Dim section As String = item("section").Text
        Dim group1 As String = item("Group").Text
        Dim targetSlotIndex As String = TargetSlotHiddenField.Value
        If targetSlotIndex <> String.Empty Then
            HandleSchedulerDrop(id, courseid, targetSlotIndex, coursename, batch, semester, section, group1, id, programid)


            TargetSlotHiddenField.Value = String.Empty
        End If
        RadScheduler1.DataBind()

    End Sub
    Private Sub HandleSchedulerDrop(ByVal id As Integer, ByVal courseid As Integer, ByVal targetSlotIndex As String, ByVal coursename As String, ByVal batch As String, ByVal semester As String, ByVal section As String, ByVal group1 As String, ByVal classgid As Integer, ByVal programid As Integer)
        'RadScheduler1.Rebind()

        Dim slot As ISchedulerTimeSlot = RadScheduler1.GetTimeSlotFromIndex(targetSlotIndex)

        Dim duration As TimeSpan = TimeSpan.FromHours(1)
        If slot.Duration = TimeSpan.FromDays(1) Then
            duration = slot.Duration
        End If

        ScheduleAppointment(id, courseid, slot.Start, slot.Start.Add(duration), coursename, batch, semester, section, group1, classgid, programid)
        RadScheduler1.DataBind()
        Response.Redirect("au_deag_class_create4.aspx")
    End Sub
    Private Sub ScheduleAppointment(ByVal id As Integer, ByVal courseid As Integer, ByVal start As DateTime, ByVal [end] As DateTime, ByVal coursename As String, ByVal batch As String, ByVal semester As String, ByVal section As String, ByVal group1 As String, ByVal classgid As Integer, ByVal programid As Integer)
        Literal1.Text = id.ToString & "," & courseid.ToString & "," & start.ToString & "," & [end].ToString
        SqlDataSource3.InsertParameters("courseid").DefaultValue = courseid
        SqlDataSource3.InsertParameters("programid").DefaultValue = programid
        SqlDataSource3.InsertParameters("starttime").DefaultValue = start
        SqlDataSource3.InsertParameters("endtime").DefaultValue = [end]
        SqlDataSource3.InsertParameters("Subject").DefaultValue = coursename
        SqlDataSource3.InsertParameters("batchname").DefaultValue = batch
        SqlDataSource3.InsertParameters("semester").DefaultValue = semester
        SqlDataSource3.InsertParameters("section1").DefaultValue = section
        SqlDataSource3.InsertParameters("group1").DefaultValue = group1
        SqlDataSource3.InsertParameters("classgid").DefaultValue = classgid
        SqlDataSource3.Insert()
        RadScheduler1.DataBind()



        'Dim dataSource As IDataSource = SchedulerDataSource
        'Dim view As DataSourceView = dataSource.GetView("DefaultView")

        'Dim data As IOrderedDictionary = New OrderedDictionary()
        'data.Add("Subject", subject)
        'data.Add("Start", start)
        'data.Add("End", [end])

        'Dim keys As IDictionary = New OrderedDictionary()
        'keys.Add("AppointmentID", id)

        'view.Update(keys, data, New OrderedDictionary(), AddressOf OnDataSourceOperationComplete)
    End Sub
    Protected Sub RadScheduler1_AppointmentClick(sender As Object, e As SchedulerEventArgs) Handles RadScheduler1.AppointmentClick
        Response.Redirect("au_take_attendance.aspx?classid=" & e.Appointment.ID)
    End Sub
End Class
