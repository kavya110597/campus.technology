﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Data.OleDb
Imports System.Drawing
Partial Class adminlogin_student
    Inherits System.Web.UI.Page

    Protected Sub RowDataBound(ByVal sender As Object, ByVal e As GridViewRowEventArgs)
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes.Add("onmouseover", "MouseEvents(this, event)")
            e.Row.Attributes.Add("onmouseout", "MouseEvents(this, event)")

        End If
    End Sub
    Protected Sub notifimessage(ByVal mesg As String)
        Page.ClientScript.RegisterStartupScript(Me.[GetType](), "Alert", "alert(' " & mesg & " ');", True)
    End Sub
    Protected Sub upload_btn_Click(sender As Object, e As EventArgs) Handles upload_btn.Click
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)

        Catch ex As Exception
            Response.Redirect("admin_log.aspx")
        End Try


        If FileUpload2.HasFile Then
            Dim filename As String = Path.GetFileName(FileUpload2.FileName)
            Dim path1 As String = "placements/photos/" & filename
            Dim dir1 As String = Server.MapPath(".") & "\placements\files"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If
            Dim path2 As String = Server.MapPath(".") & "\placements\files\" & filename

            FileUpload2.SaveAs(path2)

            Dim msg1 As New msgbox11

            Dim constr1 As String
            constr1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & path2 & ";Extended Properties=""Excel 12.0 Xml;HDR=YES"";"
            Using con1 As New OleDbConnection
                con1.ConnectionString = constr1
                con1.Open()
                Dim cmd1 As New OleDbCommand
                cmd1.Connection = con1
                cmd1.CommandText = "Select * from [Sheet1$]"
                Dim rdr1 As OleDbDataReader = cmd1.ExecuteReader

                Do While rdr1.Read


                    'Try


                    Dim regno, course, coursetype, studentname, studenttype, gender, mobile, email, bloodgroup, status, fathername, fathermobile, fatheremail, fatherprofession, mothername, mothermobile, motheremail, addressp, addresst, addressc, category, batch, specialization, section As String
                    Dim dob As Date


                    course = rdr1.GetValue(Convert.ToInt32(course_dlist.SelectedValue.ToString)).ToString
                    coursetype = rdr1.GetValue(Convert.ToInt32(coursetype_dlist.SelectedValue.ToString)).ToString
                    studentname = rdr1.GetValue(Convert.ToInt32(studname_dlist.SelectedValue.ToString)).ToString
                    studenttype = rdr1.GetValue(Convert.ToInt32(studenttype_dlist.SelectedValue.ToString)).ToString
                    gender = rdr1.GetValue(Convert.ToInt32(gender_dlist.SelectedValue.ToString)).ToString
                    Try
                        dob = Convert.ToDateTime(rdr1.GetValue(Convert.ToInt32(dob_dlist.SelectedValue.ToString)).ToString)

                    Catch ex As Exception
                        dob = DateTime.Now
                    End Try
                    mobile = rdr1.GetValue(Convert.ToInt32(mobile_dlist.SelectedValue.ToString)).ToString
                    email = rdr1.GetValue(Convert.ToInt32(email_dlist.SelectedValue.ToString)).ToString
                    bloodgroup = rdr1.GetValue(Convert.ToInt32(bloodgroup_dlist.SelectedValue.ToString)).ToString
                    status = rdr1.GetValue(Convert.ToInt32(status_dlist.SelectedValue.ToString)).ToString
                    fathername = rdr1.GetValue(Convert.ToInt32(fname_dlist.SelectedValue.ToString)).ToString
                    fathermobile = rdr1.GetValue(Convert.ToInt32(fmobile_dlist.SelectedValue.ToString)).ToString
                    fatheremail = rdr1.GetValue(Convert.ToInt32(femail_dlist.SelectedValue.ToString)).ToString
                    fatherprofession = rdr1.GetValue(Convert.ToInt32(fprofession_dlist.SelectedValue.ToString)).ToString
                    mothername = rdr1.GetValue(Convert.ToInt32(mname_dlist.SelectedValue.ToString)).ToString
                    mothermobile = rdr1.GetValue(Convert.ToInt32(mmobile_dlist.SelectedValue.ToString)).ToString
                    motheremail = rdr1.GetValue(Convert.ToInt32(memail_dlist.SelectedValue.ToString)).ToString
                    addressp = rdr1.GetValue(Convert.ToInt32(addressp_dlist.SelectedValue.ToString)).ToString
                    addresst = rdr1.GetValue(Convert.ToInt32(addresst_dlist.SelectedValue.ToString)).ToString
                    addressc = rdr1.GetValue(Convert.ToInt32(addressc_dlist.SelectedValue.ToString)).ToString
                    category = rdr1.GetValue(Convert.ToInt32(category_dlist.SelectedValue.ToString)).ToString
                    batch = rdr1.GetValue(Convert.ToInt32(batch_dlist.SelectedValue.ToString)).ToString
                    specialization = rdr1.GetValue(Convert.ToInt32(specialization_dlist.SelectedValue.ToString)).ToString
                    section = rdr1.GetValue(Convert.ToInt32(section_dlist.SelectedValue.ToString)).ToString
                    regno = rdr1.GetValue(Convert.ToInt32(rgno_dlist.SelectedValue.ToString)).ToString

                    Dim strp2 As String = "Insert into placementstud1(colid,course,coursetype,name,studenttype,gender,dob,mob,email,bloodgroup,status,fathersname,fathersphno,femail,fprofession,mothersname,mothersphno,memail,address_permanent,address_temporary,address_correspondence,category,batch,specialization,section,regno) values(@colid,@course,@coursetype,@name,@studenttype,@gender,@dob,@mob,@email,@bloodgroup,@status,@fathersname,@fathersphno,@femail,@fprofession,@mothersname,@mothersphno,@memail,@address_permanent,@address_temporary,@address_correspondence,@category,@batch,@specialization,@section,@regno)"
                    insertdata(strp2, colid, course, coursetype, studentname, studenttype, gender, dob, mobile, email, bloodgroup, status, fathername, fathermobile, fatheremail, fatherprofession, mothername, mothermobile, motheremail, addressp, addresst, addressc, category, batch, specialization, section, regno)

                    'Catch ex As Exception
                    '    notifimessage("File Format is not correct.!!")
                    '    Exit Sub
                    'End Try

                Loop
                rdr1.Close()
                con1.Close()
            End Using


            GridView1.DataBind()
            notifimessage("Details uploaded successfully!!")
        Else

            notifimessage("File is neither selected or empty.!!")
            Exit Sub
        End If
    End Sub



    Public Sub insertdata(ByVal str1 As String, ByVal colid As Integer, ByVal course As String, ByVal coursetype As String, ByVal name As String, ByVal studenttype As String, ByVal gender As String, ByVal dob As Date, ByVal mob As String, ByVal email As String, ByVal bloodgroup As String, ByVal status As String, ByVal fathersname As String, ByVal fathersphno As String, ByVal femail As String, ByVal fprofession As String, ByVal mothersname As String, ByVal mothersphno As String, ByVal memail As String, ByVal address_permanent As String, ByVal address_temporary As String, ByVal address_correspondence As String, ByVal category As String, ByVal batch As String, ByVal specialization As String, ByVal section As String, ByVal regno As String)
        Dim id1 As Integer = -1
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = str1
            cmd1.Parameters.AddWithValue("@colid", colid).DbType = DbType.Int32
            cmd1.Parameters.AddWithValue("@course", course).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@coursetype", coursetype).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@name", name).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@studenttype", studenttype).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@gender", gender).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@dob", dob).DbType = DbType.Date
            cmd1.Parameters.AddWithValue("@mob", mob).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@email", email).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@bloodgroup", bloodgroup).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@status", status).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@fathersname", fathersname).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@fathersphno", fathersphno).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@femail", femail).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@fprofession", fprofession).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@mothersname", mothersname).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@mothersphno", mothersphno).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@memail", memail).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@address_permanent", address_permanent).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@address_temporary", address_temporary).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@address_correspondence", address_correspondence).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@category", category).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@batch", batch).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@specialization", specialization).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@section", section).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@regno", regno).DbType = DbType.String
            cmd1.ExecuteNonQuery()

            con1.Close()

        End Using


    End Sub

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Page.MaintainScrollPositionOnPostBack = True
        Dim cookie1 As HttpCookie = Request.Cookies("colid")
        If cookie1 Is Nothing Then
            Response.Redirect("admin_log.aspx")
        Else
            'MsgBox(cookie1.Value)

        End If
    End Sub
    Protected Sub GridView1_RowDeleted(sender As Object, e As GridViewDeletedEventArgs) Handles GridView1.RowDeleted
        If e.Exception IsNot Nothing Then
            If e.AffectedRows = 0 Then
                notifimessage("An exception occurred deleting the contact. ' &  'Please verify your values and try again.")

            Else
                notifimessage("An exception occurred deleting the contact. ' & 'Please verify the values in the recently updated item.")

            End If

            e.ExceptionHandled = True
        Else
            notifimessage("Content Deleted.")

        End If

    End Sub

    Protected Sub GridView1_RowUpdated(sender As Object, e As GridViewUpdatedEventArgs) Handles GridView1.RowUpdated
        If e.Exception IsNot Nothing Then
            If e.AffectedRows = 0 Then
                e.KeepInEditMode = True
                notifimessage("An exception occurred updating the contact. ' &  'Please verify your values and try again.")

            Else
                notifimessage("An exception occurred updating the contact. ' & 'Please verify the values in the recently updated item.")

            End If

            e.ExceptionHandled = True
        Else
            notifimessage("Content Updated.")

        End If
    End Sub
    Protected Sub export_btn_Click(sender As Object, e As EventArgs) Handles export_btn.Click
        If GridView1.Rows.Count = 0 Then
            notifimessage("There is no data to export.")
            Exit Sub
        Else
            ExportToExcel()
        End If

    End Sub
    Public Sub ExportToExcel()
        Response.Clear()
        Response.Buffer = True
        Response.AddHeader("content-disposition", "attachment;filename=MyCustomReport.xls")
        Response.Charset = ""
        Response.ContentType = "application/vnd.ms-excel"
        Using sw As New StringWriter()
            Dim hw As New HtmlTextWriter(sw)

            'To Export all pages
            GridView1.AllowPaging = False
            Me.BindGrid()

            GridView1.HeaderRow.BackColor = Color.White
            For Each cell As TableCell In GridView1.HeaderRow.Cells
                cell.BackColor = GridView1.HeaderStyle.BackColor
            Next
            For Each row As GridViewRow In GridView1.Rows
                row.BackColor = Color.White
                For Each cell As TableCell In row.Cells
                    If row.RowIndex Mod 2 = 0 Then
                        cell.BackColor = GridView1.AlternatingRowStyle.BackColor
                    Else
                        cell.BackColor = GridView1.RowStyle.BackColor
                    End If
                    cell.CssClass = "textmode"
                Next
            Next

            GridView1.RenderControl(hw)
            'style to format numbers to string
            Dim style As String = "<style> .textmode { } </style>"
            Response.Write(style)
            Response.Output.Write(sw.ToString())
            Response.Flush()
            Response.[End]()
        End Using
    End Sub

    Public Overrides Sub VerifyRenderingInServerForm(control As Control)
        ' Verifies that the control is rendered
    End Sub
    Private Sub BindGrid()

        Dim str As String = "SELECT placementstud1.Id, placementstud1.name, placementstud1.mob, placementstud1.email, placementstud1.course, placementstud1.gender, placementstud1.dob, placementstud1.fathersname, placementstud1.fathersphno, placementstud1.mothersname, placementstud1.mothersphno, placementstud1.bloodgroup, placementstud1.coursetype, placementstud1.address_permanent, placementstud1.address_temporary, placementstud1.address_correspondence, placementstud1.status, placementstud1.fprofession, placementstud1.femail, placementstud1.memail, placementstud1.studenttype, placementstud1.category, placementstud1.batch, placementstud1.specialization, placementstud1.section, nba_programs.programs, placementstud1.regno FROM placementstud1 INNER JOIN nba_programs ON placementstud1.programid = nba_programs.Id WHERE (placementstud1.colid = @colid) ORDER BY placementstud1.name"
        SqlDataSource1.SelectCommand = str
        GridView1.DataBind()


    End Sub
    Protected Sub delete_btn_Click(sender As Object, e As EventArgs) Handles delete_btn.Click
        If GridView1.Rows.Count = 0 Then
            notifimessage("There is no data to delete.")
            Exit Sub
        Else
            For Each gr As GridViewRow In GridView1.Rows
                Dim chk1 As CheckBox
                chk1 = CType(gr.FindControl("CheckBox1"), CheckBox)
                If chk1 IsNot Nothing AndAlso chk1.Checked Then
                    Dim estudid As Integer = Convert.ToInt32(GridView1.DataKeys(gr.RowIndex).Value)

                    Dim str1 As String

                    str1 = "Delete from placementstud1 where id=" & estudid
                    deletedata(str1)
                    'insertdata(str1, colid, empid, branch, guestlecture, details, organizedby, startdate, type, deliverymethod)

                End If
            Next


            GridView1.DataBind()
            'DropDownList1.SelectedIndex = 0

            notifimessage("Content Deleted.")
        End If
    End Sub
    Public Sub deletedata(ByVal str As String)
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = str
            cmd1.ExecuteNonQuery()
            con1.Close()

        End Using
    End Sub
End Class
