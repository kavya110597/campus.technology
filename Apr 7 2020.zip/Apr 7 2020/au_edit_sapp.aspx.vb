﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Net.Mail
Imports System.Net


Partial Class au_edit_sapp
    Inherits System.Web.UI.Page

    Protected Sub btnUpload_Click(sender As Object, e As EventArgs)
        If FileUpload1.HasFile Then
            'FileUpload1.SaveAs(MapPath("~/students/" + FileUpload1.FileName))
            'Dim filename As String = Path.GetFileName(FileUpload1.FileName)
            'Dim path1 As String = "~/students/" + FileUpload1.FileName
            'Dim str1 As String = "Insert into ajaxfileupload(filename,filelink) Values(@filename,@filelink)"
            'insertdata(str1, filename, path1)


            Dim filename As String
            Dim path1 As String
            Dim collegename As String = Request.Cookies("collegename").Value.ToString
            If FileUpload1.HasFile Then
                filename = Path.GetFileName(FileUpload1.FileName)
                path1 = "files/" & collegename & "/students/" & filename
                Dim dir1 As String = Server.MapPath(".") & "\files\" & collegename & "\students\"
                If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                    My.Computer.FileSystem.CreateDirectory(dir1)
                End If
                Dim path2 As String = Server.MapPath(".") & "\files\" & collegename & "\students\" & filename

                FileUpload1.SaveAs(path2)

                Dim colid, studid As Integer
                colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
                studid = Convert.ToInt32(Request.QueryString("id").ToString)
                Dim str1 As String = "Insert into au_stud_file(colid,studid,filename,filelink,status,type1,description) Values('" & colid & "','" & studid & "',@filename,@filelink,'Uploaded','" & DropDownList1.SelectedValue.ToString & "',@description)"
                insertdata(str1, filename, path1, TextBox8.Text)
                Gridviewfile.DataBind()

            End If





        End If
    End Sub

    Protected Sub insertdata(ByVal str1 As String, ByVal filename As String, ByVal path1 As String, ByVal description As String)

        Using con1 As New SqlConnection
            con1.ConnectionString = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1

            cmd1.CommandText = str1
            cmd1.Parameters.AddWithValue("@filename", filename).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@filelink", path1).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@description", description).DbType = DbType.String
            cmd1.ExecuteNonQuery()

            con1.Close()
        End Using

    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Label1.Text = ""
        Dim email As String
        Using con1 As New SqlConnection
            con1.ConnectionString = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            Dim studid As Integer = Convert.ToInt32(Request.QueryString("id").ToString)
            cmd1.CommandText = "Select email from AU_students where id=" & studid
            Dim rdr1 As SqlDataReader
            rdr1 = cmd1.ExecuteReader
            Do While rdr1.Read
                email = rdr1.GetValue(0).ToString
            Loop
            rdr1.Close()

            con1.Close()
        End Using
        If email = "" Or email.Contains("@") = False Then
            Label1.Text = "Invalid email address specified. Please update the correct email address." & email
            Exit Sub
        End If
        Try

            sendmailto1(email)

        Catch ex As Exception
            Label1.Text = "Message send failure. Error code: " & ex.Message.ToString
        End Try
    End Sub

    Public Sub sendmailto1(ByVal email As String)
        'TextBox1.Text = Server.UrlDecode(Request.QueryString("Email").ToString())
        Using mm As New MailMessage("e-accreditation@epaathsala.com", email)
            mm.Subject = TextBox9.Text
            mm.Bcc.Add("suman@epaathsala.com")
            Dim str1 As String
            str1 = "This email was sent using epaathsala server. Epaathsala does not assume any resposibility regarding the content, correctness or and advice noted in this email, and any consequences arising out of such content or advice."
            mm.Body = TextBox37.Text & vbCrLf & vbCrLf & str1


            ' mm.Body = TextBox3.Text
            'If FileUpload1.HasFile Then
            '    Dim FileName As String = Path.GetFileName(FileUpload1.PostedFile.FileName)
            '    mm.Attachments.Add(New Attachment(FileUpload1.PostedFile.InputStream, FileName))
            'End If
            'mm.Attachments.Add(New Attachment(Server.MapPath(".") & "\proposal - DL.pdf"))
            For Each gr As GridViewRow In Gridviewfile.Rows
                Dim lnk1 As HyperLink
                lnk1 = CType(gr.FindControl("HyperLink1"), HyperLink)
                Dim chk1 As CheckBox
                chk1 = CType(gr.FindControl("CheckBox17"), CheckBox)

                Dim file1 As String = Server.MapPath(".") & "\" & lnk1.NavigateUrl.Replace("/", "\")


                If chk1.Checked Then
                    mm.Attachments.Add(New Attachment(file1))
                End If


            Next


            mm.IsBodyHtml = False
            Dim smtp As New SmtpClient()
            smtp.Host = "smtp.gmail.com"
            smtp.EnableSsl = True
            'Dim NetworkCred As New NetworkCredential("nandy2k2@gmail.com", "Sanchi4me@dec")
            Dim NetworkCred As New NetworkCredential("e-accreditation@epaathsala.com", "Epaathsala123")
            smtp.UseDefaultCredentials = True
            smtp.Credentials = NetworkCred
            smtp.Port = 587
            smtp.Send(mm)
            'ClientScript.RegisterStartupScript(Me.GetType, "alert", "alert('Email sent.');", True)
            'notifimessage("Email sent.")
            'Literal2.Text = Literal2.Text & "Mail sent to:" & email & "<br>"
            Label1.Text = "Mail sent to " & email
        End Using
    End Sub
End Class
