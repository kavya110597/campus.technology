﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Data.OleDb
Imports System.Drawing
Partial Class au_clg_projects
    Inherits System.Web.UI.Page
    Protected Sub add_project_Click(sender As Object, e As EventArgs) Handles add_project.Click
        msg.Text = ""
        Labelpro.Text = ""
        If Title_tb.Text = "" OrElse duration_tb.Text = "" OrElse grants_tb.Text = "" OrElse grantr_tb.Text = "" OrElse funding_tb.Text = "" Then
            msg.Text = "Please enter all details."
            msg.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If status_rcb.SelectedItem Is Nothing OrElse [String].IsNullOrWhiteSpace(status_rcb.SelectedItem.Text) Then
            msg.Text = "Please select status."
            msg.ForeColor = Drawing.Color.Red
            Exit Sub
        End If


        Dim grants, grantr As Double
        If FileUpload1.HasFile Then
            Dim file As HttpPostedFile = FileUpload1.PostedFile
            Dim filesize As Integer = file.ContentLength
            If filesize > 1000000 Then
                msg.Text = "File exceeds the maximum size limit i.e. 1MB"
                msg.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim extensionlist() As String = {".doc", ".docx", ".jpeg", ".gif", ".png", ".pdf", ".jpg"}
            Dim filename As String = Path.GetFileName(FileUpload1.FileName)
            Dim extension As String = Path.GetExtension(filename)

            If extensionlist.Contains(extension) = False Then
                msg.Text = "Invalid file extension.Please upload .doc or .pdf or .jpeg or .png or .jpg or .gif"
                msg.ForeColor = Drawing.Color.Red
                Exit Sub
            End If


            Dim path1 As String = "students/photos/" & filename
            Dim dir1 As String = Server.MapPath(".") & "\students\photos"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If
            Dim path2 As String = Server.MapPath(".") & "\students\photos\" & filename
            FileUpload1.SaveAs(path2)


            Try
                grants = Convert.ToDouble(grants_tb.Text)
                grantr = Convert.ToDouble(grantr_tb.Text)
            Catch ex As Exception
                msg.Text = "Invalid grant."
                msg.ForeColor = Drawing.Color.Red
                Exit Sub
            End Try

            SqlDataSource2.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
            SqlDataSource2.InsertParameters("title").DefaultValue = Title_tb.Text
            SqlDataSource2.InsertParameters("duration").DefaultValue = duration_tb.Text
            SqlDataSource2.InsertParameters("grantsanctioned").DefaultValue = grants
            SqlDataSource2.InsertParameters("grantreceived").DefaultValue = grantr
            SqlDataSource2.InsertParameters("fundingagency").DefaultValue = funding_tb.Text
            SqlDataSource2.InsertParameters("status").DefaultValue = status_rcb.SelectedValue.ToString()
            SqlDataSource2.InsertParameters("certificate").DefaultValue = path1
            SqlDataSource2.Insert()
            msg.Text = "Details Added."
            msg.ForeColor = Drawing.Color.Green
            GridView1.DataBind()

        Else
            Try
                grants = Convert.ToDouble(grants_tb.Text)
                grantr = Convert.ToDouble(grantr_tb.Text)
            Catch ex As Exception
                msg.Text = "Invalid grant."
                msg.ForeColor = Drawing.Color.Red
                Exit Sub
            End Try

            SqlDataSource2.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
            SqlDataSource2.InsertParameters("title").DefaultValue = Title_tb.Text
            SqlDataSource2.InsertParameters("duration").DefaultValue = duration_tb.Text
            SqlDataSource2.InsertParameters("grantsanctioned").DefaultValue = grants
            SqlDataSource2.InsertParameters("grantreceived").DefaultValue = grantr
            SqlDataSource2.InsertParameters("fundingagency").DefaultValue = funding_tb.Text
            SqlDataSource2.InsertParameters("status").DefaultValue = status_rcb.SelectedValue.ToString()
            SqlDataSource2.Insert()
            msg.Text = "Details Added."
            msg.ForeColor = Drawing.Color.Green
            GridView1.DataBind()
        End If
    End Sub
    Private Sub GridView1_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView1.RowCommand
        Labelpro.Text = ""
        msg.Text = ""
        If e.CommandName = "save" Then
            Dim rowid As Integer = Convert.ToInt32(e.CommandArgument.ToString)
            Dim lbl1 As Label = CType(GridView1.Rows(rowid).FindControl("Labelid2pro"), Label)
            Dim fileid As Integer = Convert.ToInt32(lbl1.Text.ToString)
            Dim FileUploadsave As FileUpload
            FileUploadsave = CType(GridView1.Rows(rowid).FindControl("FileUploadcertipro"), FileUpload)
            Dim filename As String = ""
            Dim path1 As String = ""

            If FileUploadsave.HasFile Then
                Dim file As HttpPostedFile = FileUploadsave.PostedFile
                Dim filesize As Integer = file.ContentLength
                If filesize > 1000000 Then
                    Labelpro.Text = "File exceeds the maximum size limit i.e. 1MB"
                    Labelpro.ForeColor = Drawing.Color.Red
                    Exit Sub
                End If
                Dim extensionlist() As String = {".doc", ".docx", ".jpeg", ".gif", ".png", ".pdf", ".jpg"}
                filename = Path.GetFileName(FileUploadsave.FileName)
                Dim extension As String = Path.GetExtension(filename)

                If extensionlist.Contains(extension) = False Then
                    Labelpro.Text = "Invalid file extension.Please upload .doc or .pdf or .jpeg or .png or .jpg or .gif"
                    Labelpro.ForeColor = Drawing.Color.Red
                    Exit Sub
                End If
                path1 = "students/photos/" & filename
                Dim dir1 As String = Server.MapPath(".") & "\students\photos\"
                If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                    My.Computer.FileSystem.CreateDirectory(dir1)
                End If
                Dim path2 As String = Server.MapPath(".") & "\students\photos\" & filename

                FileUploadsave.SaveAs(path2)


            End If
            Dim str1 As String
            str1 = "Update au_clg_projects set certificate=@path1 where Id=@id"
            updatedata(str1, path1, fileid)
            Labelpro.Text = "File Uploaded."
            Labelpro.ForeColor = Drawing.Color.Green
            GridView1.DataBind()

        End If
    End Sub
    Public Sub updatedata(ByVal str As String, ByVal path1 As String, ByVal rowid As Integer)
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = str

            cmd1.Parameters.AddWithValue("@id", rowid).DbType = DbType.Int32
            cmd1.Parameters.AddWithValue("@path1", path1).DbType = DbType.String
            cmd1.ExecuteNonQuery()
            con1.Close()

        End Using
    End Sub
End Class
