﻿Imports DevExpress.Data
Imports DevExpress.Web
Imports DevExpress.XtraPrinting
Partial Class au_agents
    Inherits System.Web.UI.Page

    'Protected Sub ASPxGridView1_ToolbarItemClick(ByVal source As Object, ByVal e As DevExpress.Web.Data.ASPxGridViewToolbarItemClickEventArgs) Handles ASPxGridView1.ToolbarItemClick
    '    ASPxGridViewExporter1.GridViewID = "ASPxGridView1"
    '    Select Case e.Item.Name
    '        Case "ExportToPDF"
    '            'ASPxGridViewExporter1.WritePdfToResponse()
    '            Dim options As New DevExpress.XtraPrinting.PdfExportOptions
    '            options.Compressed = False
    '            ASPxGridViewExporter1.WritePdfToResponse(options)
    '        Case "ExportToXLS"
    '            ASPxGridViewExporter1.WriteXlsToResponse()
    '        Case "ExportToXLSX"
    '            'ASPxGridViewExporter1.WriteXlsxToResponse()
    '            ASPxGridViewExporter1.WriteXlsxToResponse(New XlsxExportOptionsEx With {.ExportType = DevExpress.Export.ExportType.WYSIWYG})
    '        Case Else
    '    End Select
    'End Sub

    Protected Sub Grid_ToolbarItemClick(ByVal source As Object, ByVal e As ASPxGridToolbarItemClickEventArgs) Handles ASPxGridView1.ToolbarItemClick
        ASPxGridViewExporter1.GridViewID = "ASPxGridView1"
        Select Case e.Item.Name
            Case "ExportToPDF"
                'ASPxGridViewExporter1.WritePdfToResponse()
                Dim options As New DevExpress.XtraPrinting.PdfExportOptions
                options.Compressed = False
                ASPxGridViewExporter1.WritePdfToResponse(options)
            Case "ExportToXLS"
                ASPxGridViewExporter1.WriteXlsToResponse()
            Case "ExportToXLSX"
                'ASPxGridViewExporter1.WriteXlsxToResponse()
                ASPxGridViewExporter1.WriteXlsxToResponse(New XlsxExportOptionsEx With {.ExportType = DevExpress.Export.ExportType.WYSIWYG})
            Case Else
        End Select
    End Sub
End Class
