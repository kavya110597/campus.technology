﻿
Partial Class au_admform_link_1
    Inherits System.Web.UI.Page


    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim colid As Integer = Convert.ToInt32(Request.Cookies("colid").Value.ToString)

        If DropDownList1.SelectedValue.Contains("2") Then
            Literal1.Text = "http://campus.technology/erpnew/faculty/au_admform1.aspx?colid=" & colid & "&utm_source=" & DropDownList2.SelectedValue.ToString
        Else
            Literal1.Text = "http://campus.technology/erpnew/faculty/au_admform_pre.aspx?colid=" & colid & "&utm_source=" & DropDownList2.SelectedValue.ToString

        End If
    End Sub
End Class
