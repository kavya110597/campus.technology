﻿
Partial Class faculty_au_bulk_assign_leave
    Inherits System.Web.UI.Page

    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try

        If RadComboBox1.SelectedIndex = -1 Then

            Label1.Text = "Please select departmnet"
            Label1.ForeColor = Drawing.Color.Red
            Exit Sub
        End If

        If ASPxComboBox2.SelectedIndex = -1 Then
            Label1.Text = "Please select type of leave"
            Label1.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If TextBox8.Text = "" Then
            Label1.Text = "Please enter the leave balance"
            Label1.ForeColor = Drawing.Color.Red
            Exit Sub
        End If


        Dim fieldValues As List(Of Object) = ASPxGridView1.GetSelectedFieldValues(New String() {"Id"})
        Dim cs1 As New schoolclass1
        If ASPxGridView1.Selection.Count = 0 Then
            Dim script As String = "window.onload = function(){ alert('"
            script += "There were no employees Selected. \nYou need to select atleast one employee "
            'script += "using the first check."
            script += "')};"
            ClientScript.RegisterStartupScript(Me.[GetType](), "FailMessage", script, True)
        Else

            Dim i As Integer = 0
            For Each item As Object In fieldValues
                SqlDataSource5.InsertParameters("colid").DefaultValue = Request.Cookies("colid").Value.ToString
                SqlDataSource5.InsertParameters("empid").DefaultValue = Convert.ToInt32(item)
                SqlDataSource5.InsertParameters("leavetype").DefaultValue = ASPxComboBox2.SelectedItem.ToString
                SqlDataSource5.InsertParameters("LeaveBalance").DefaultValue = Convert.ToDouble(TextBox8.Text)

                SqlDataSource5.Insert()

                i = i + 1
            Next

            Label1.Text = "Leave assigned."
            Label1.ForeColor = Drawing.Color.Green
            ASPxGridView2.DataBind()
        End If

    End Sub
End Class
