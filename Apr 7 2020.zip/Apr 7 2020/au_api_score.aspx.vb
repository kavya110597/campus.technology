﻿
Partial Class au_api_score
    Inherits System.Web.UI.Page

End Class
