﻿
Partial Class au_academic
    Inherits System.Web.UI.Page

End Class
