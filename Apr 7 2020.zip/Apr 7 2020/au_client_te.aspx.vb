﻿Imports DevExpress.Web
Imports System.Data
Imports System.Data.SqlClient
Imports DevExpress.XtraPrinting
Partial Class au_client_te
    Inherits System.Web.UI.Page
    Protected Sub ImageExcel_Click(sender As Object, e As ImageClickEventArgs) Handles ImageExcel.Click

        ASPxGridViewExporter1.GridViewID = "ASPxGridView1"

        ASPxGridViewExporter1.WriteXlsxToResponse(New XlsxExportOptionsEx With {.ExportType = DevExpress.Export.ExportType.WYSIWYG})
    End Sub
    Protected Sub ASPxGridView1_CellEditorInitialize(sender As Object, e As DevExpress.Web.ASPxGridViewEditorEventArgs) Handles ASPxGridView1.CellEditorInitialize
        If (Not ASPxGridView1.IsEditing) OrElse e.Column.FieldName <> "milestoneid" Then
            Return
        End If
        If e.KeyValue Is DBNull.Value OrElse e.KeyValue Is Nothing Then
            Return
        End If
        Dim val As Object = ASPxGridView1.GetRowValuesByKeyValue(e.KeyValue, "clientid")
        If val Is DBNull.Value Then
            Return
        End If
        'Dim country As String = CStr(val)
        Dim clientid As Integer = Convert.ToInt32(CStr(val))

        Dim combo As ASPxComboBox = TryCast(e.Editor, ASPxComboBox)
        FillCityCombo(combo, clientid)

        AddHandler combo.Callback, AddressOf cmbCity_OnCallback
    End Sub
    Protected Sub FillCityCombo(ByVal cmb As ASPxComboBox, ByVal clientid As Integer)



        cmb.Items.Clear()
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "Select id,milestone from au_milestone where clientid=" & clientid
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                cmb.Items.Add(rdr1.GetValue(1).ToString, Convert.ToInt32(rdr1.GetValue(0).ToString))
            Loop
            rdr1.Close()
            con1.Close()
        End Using






    End Sub
    Private Sub cmbCity_OnCallback(ByVal source As Object, ByVal e As CallbackEventArgsBase)
        FillCityCombo(TryCast(source, ASPxComboBox), Convert.ToInt32(e.Parameter.ToString))
    End Sub
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            'ASPxGridView1.StartEdit(3)
        End If
    End Sub
    Protected Sub RadButton1_Click(sender As Object, e As EventArgs) Handles RadButton1.Click
        SqlDataSource1.InsertParameters("milestoneid").DefaultValue = Convert.ToInt32(RadComboBox2.SelectedValue.ToString)
        SqlDataSource1.InsertParameters("clientid").DefaultValue = Convert.ToInt32(RadComboBox1.SelectedValue.ToString)
        SqlDataSource1.InsertParameters("description").DefaultValue = RadTextBox1.Text
        SqlDataSource1.InsertParameters("dateofwork").DefaultValue = RadDatePicker1.SelectedDate
        SqlDataSource1.InsertParameters("hours").DefaultValue = Convert.ToDouble(RadNumericTextBox2.Text)
        SqlDataSource1.InsertParameters("expenses").DefaultValue = Convert.ToDouble(RadNumericTextBox1.Text)
        SqlDataSource1.Insert()
        ASPxGridView1.DataBind()




    End Sub
End Class
