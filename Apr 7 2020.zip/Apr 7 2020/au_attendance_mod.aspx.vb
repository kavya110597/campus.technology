﻿
Partial Class au_attendance_mod
    Inherits System.Web.UI.Page

End Class
