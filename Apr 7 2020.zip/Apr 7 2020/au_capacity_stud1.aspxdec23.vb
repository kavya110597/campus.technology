﻿
Partial Class au_capacity_stud1
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click



        Dim fieldValues As List(Of Object) = ASPxGridView2.GetSelectedFieldValues(New String() {"Id"})
        Dim i As Integer = 0
        For Each item As Object In fieldValues
            SqlDataSource1.InsertParameters("schemeid").DefaultValue = Convert.ToInt32(RadComboBox3.SelectedValue.ToString)
            SqlDataSource1.InsertParameters("studid").DefaultValue = Convert.ToInt32(item)
            SqlDataSource1.InsertParameters("StartDate").DefaultValue = Convert.ToDateTime(RadDatePicker1.SelectedDate)
            SqlDataSource1.InsertParameters("EndDate").DefaultValue = Convert.ToDateTime(RadDatePicker2.SelectedDate)
            SqlDataSource1.InsertParameters("YearImplemented").DefaultValue = RadComboBox5.SelectedValue.ToString
            SqlDataSource1.InsertParameters("Status").DefaultValue = RadComboBox4.SelectedValue.ToString

            SqlDataSource1.Insert()

            ASPxGridView1.DataBind()

        Next
    End Sub
End Class
