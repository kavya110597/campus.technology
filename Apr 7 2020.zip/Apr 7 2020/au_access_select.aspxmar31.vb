﻿
Partial Class au_access_select
    Inherits System.Web.UI.Page

    Dim group1 As String

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim cooki16 As New HttpCookie("group1")
        cooki16.Value = "tasks"
        cooki16.Expires = DateTime.Now.AddMinutes(180)
        Response.Cookies.Add(cooki16)
        Response.Redirect("au_task_assignment2.aspx")

    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim cooki16 As New HttpCookie("group1")
        cooki16.Value = ViewState("group1").ToString
        cooki16.Expires = DateTime.Now.AddMinutes(180)
        Response.Cookies.Add(cooki16)
        Dim group12 As String = ViewState("group1").ToString
        If group12 = "" Then
            Response.Redirect("au_dashboard_t1.aspx")
        Else
            Response.Redirect("au_dashboard_fac1.aspx")
        End If

    End Sub
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            group1 = Request.Cookies("group1").Value.ToString
            ViewState("group1") = group1.ToString
            Dim cooki1 As New HttpCookie("group1")
            cooki1.Value = ""
            cooki1.Expires = DateTime.Now.AddMinutes(-300)
            Response.Cookies.Add(cooki1)
        End If
    End Sub
End Class
