﻿
Partial Class faculty_au_c_d
    Inherits System.Web.UI.Page

End Class
