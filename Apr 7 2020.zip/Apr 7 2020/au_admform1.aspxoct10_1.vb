﻿
Partial Class au_admform1
    Inherits System.Web.UI.Page



    Dim studid As Integer
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Label1.Text = ""
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.QueryString("colid").ToString)

        Catch ex As Exception
            Exit Sub
        End Try

        If IsNumeric(TextBox39.Text) = False Then
            TextBox39.Text = "0"
        End If
        If IsDate(TextBox5.Text) = False Then
            TextBox5.Text = "01/01/1990"
        End If

        'If DropDownList1.SelectedIndex = -1 Then
        '    Label1.Text = "Please select program."
        '    Exit Sub
        'End If
        SqlDataSource2.InsertParameters("colid").DefaultValue = Request.QueryString("colid").ToString
        Dim t1 As Boolean = CheckBox1.Checked
        SqlDataSource2.InsertParameters("email").DefaultValue = TextBox32.Text
        SqlDataSource2.InsertParameters("programid").DefaultValue = Convert.ToInt32(DropDownList1.SelectedValue.ToString())
        SqlDataSource2.InsertParameters("gender").DefaultValue = DropDownList4.SelectedValue.ToString()
        SqlDataSource2.InsertParameters("xiiyear").DefaultValue = TextBox7.Text
        SqlDataSource2.InsertParameters("workex").DefaultValue = TextBox34.Text
        SqlDataSource2.InsertParameters("extension").DefaultValue = TextBox35.Text
        SqlDataSource2.InsertParameters("login").DefaultValue = TextBox10.Text ' TextBox29.Text
        SqlDataSource2.InsertParameters("batch").DefaultValue = "2019-20" ' DropDownList20.SelectedValue.ToString ' RadComboBox1.SelectedValue.ToString ' TextBox29.Text
        SqlDataSource2.InsertParameters("password").DefaultValue = TextBox30.Text
        SqlDataSource2.InsertParameters("regno").DefaultValue = TextBox6.Text
        SqlDataSource2.InsertParameters("dob").DefaultValue = TextBox5.Text
        SqlDataSource2.InsertParameters("Language").DefaultValue = DropDownList6.SelectedValue.ToString()
        SqlDataSource2.InsertParameters("physicallychallenged").DefaultValue = DropDownList16.SelectedValue.ToString()
        SqlDataSource2.InsertParameters("Status1").DefaultValue = DropDownList14.SelectedValue.ToString()
        SqlDataSource2.InsertParameters("phone").DefaultValue = TextBox10.Text
        SqlDataSource2.InsertParameters("status").DefaultValue = "Applied" ' DropDownList15.SelectedValue.ToString()
        SqlDataSource2.InsertParameters("firstname").DefaultValue = TextBox2.Text
        SqlDataSource2.InsertParameters("familyname").DefaultValue = TextBox3.Text
        SqlDataSource2.InsertParameters("previoussurname").DefaultValue = TextBox4.Text
        SqlDataSource2.InsertParameters("building").DefaultValue = TextBox13.Text
        SqlDataSource2.InsertParameters("flat").DefaultValue = TextBox14.Text
        SqlDataSource2.InsertParameters("streetnumber").DefaultValue = TextBox16.Text
        SqlDataSource2.InsertParameters("streetname").DefaultValue = TextBox17.Text
        SqlDataSource2.InsertParameters("suburb").DefaultValue = TextBox18.Text
        SqlDataSource2.InsertParameters("state").DefaultValue = TextBox19.Text
        SqlDataSource2.InsertParameters("postalcode").DefaultValue = TextBox20.Text
        SqlDataSource2.InsertParameters("country").DefaultValue = DropDownList8.SelectedValue.ToString()
        SqlDataSource2.InsertParameters("pbuilding").DefaultValue = TextBox21.Text
        SqlDataSource2.InsertParameters("pflat").DefaultValue = TextBox22.Text
        SqlDataSource2.InsertParameters("pstreetnumber").DefaultValue = TextBox23.Text
        SqlDataSource2.InsertParameters("pstreetname").DefaultValue = TextBox24.Text
        SqlDataSource2.InsertParameters("psuburb").DefaultValue = TextBox25.Text
        SqlDataSource2.InsertParameters("pstate").DefaultValue = TextBox26.Text
        SqlDataSource2.InsertParameters("ppostalcode").DefaultValue = TextBox27.Text
        SqlDataSource2.InsertParameters("workphone").DefaultValue = TextBox11.Text
        SqlDataSource2.InsertParameters("alternateemail").DefaultValue = TextBox15.Text
        'SqlDataSource2.InsertParameters("languagespoken").DefaultValue = DropDownList12.SelectedValue.ToString()
        'SqlDataSource2.InsertParameters("abboriginal").DefaultValue = CheckBox3.Checked
        'SqlDataSource2.InsertParameters("torrestrait").DefaultValue = CheckBox4.Checked
        SqlDataSource2.InsertParameters("disbilitytype").DefaultValue = DropDownList13.SelectedValue.ToString()
        SqlDataSource2.InsertParameters("highestschoollevel").DefaultValue = DropDownList5.SelectedValue.ToString()
        SqlDataSource2.InsertParameters("previousqualification").DefaultValue = DropDownList10.SelectedValue.ToString()
        SqlDataSource2.InsertParameters("employmenttype").DefaultValue = DropDownList11.SelectedValue.ToString()
        SqlDataSource2.InsertParameters("studeyreason").DefaultValue = DropDownList9.SelectedValue.ToString()
        SqlDataSource2.InsertParameters("title").DefaultValue = DropDownList18.SelectedValue.ToString ' TextBox1.Text

        SqlDataSource2.InsertParameters("passport").DefaultValue = TextBox31.Text
        SqlDataSource2.InsertParameters("residenttype").DefaultValue = DropDownList13.SelectedValue.ToString()
        SqlDataSource2.InsertParameters("visadetails").DefaultValue = TextBox33.Text
        SqlDataSource2.InsertParameters("visaexpiry").DefaultValue = TextBox36.Text
        'SqlDataSource2.InsertParameters("nseb").DefaultValue = CheckBox2.Checked
        SqlDataSource2.InsertParameters("commonwealth").DefaultValue = DropDownList17.SelectedValue.ToString()
        SqlDataSource2.InsertParameters("emergencycontact").DefaultValue = TextBox28.Text
        SqlDataSource2.InsertParameters("emergencynumber").DefaultValue = TextBox32.Text
        SqlDataSource2.InsertParameters("languagenative").DefaultValue = TextBox37.Text

        SqlDataSource2.InsertParameters("emergencytype").DefaultValue = RadioButtonList1.SelectedItem.Text
        'SqlDataSource2.InsertParameters("abboriginal").DefaultValue = CheckBox3.Checked
        'SqlDataSource2.InsertParameters("Torrestrait").DefaultValue = CheckBox4.Checked
        SqlDataSource2.InsertParameters("differentlyabled").DefaultValue = CheckBox6.Checked
        SqlDataSource2.InsertParameters("differentlyabledlist").DefaultValue = DropDownList16.SelectedValue.ToString
        SqlDataSource2.InsertParameters("specialassistance").DefaultValue = CheckBox7.Checked
        SqlDataSource2.InsertParameters("dassessed").DefaultValue = CheckBox8.Checked
        SqlDataSource2.InsertParameters("dpension").DefaultValue = CheckBox9.Checked
        SqlDataSource2.InsertParameters("dspouse").DefaultValue = CheckBox10.Checked
        SqlDataSource2.InsertParameters("dadvice").DefaultValue = CheckBox11.Checked
        SqlDataSource2.InsertParameters("homestay").DefaultValue = CheckBox13.Checked
        SqlDataSource2.InsertParameters("airportpickup").DefaultValue = CheckBox14.Checked
        SqlDataSource2.InsertParameters("u18gexists").DefaultValue = CheckBox15.Checked
        SqlDataSource2.InsertParameters("u18gnominate").DefaultValue = CheckBox16.Checked
        SqlDataSource2.InsertParameters("accomodationrequired").DefaultValue = DropDownList2.SelectedValue.ToString()
        SqlDataSource2.InsertParameters("source").DefaultValue = "Webform" ' DropDownList3.SelectedValue.ToString()
        SqlDataSource2.InsertParameters("paymentplan").DefaultValue = RadioButtonList4.SelectedValue.ToString
        SqlDataSource2.InsertParameters("category").DefaultValue = RadComboBox1.SelectedValue.ToString
        SqlDataSource2.InsertParameters("agentid").DefaultValue = -1 ' Convert.ToInt32(DropDownList19.SelectedValue.ToString)
        SqlDataSource2.InsertParameters("extracurricular").DefaultValue = RadAutoCompleteBox1.Text
        SqlDataSource2.InsertParameters("fathersname").DefaultValue = TextBox1.Text
        SqlDataSource2.InsertParameters("fathersphno").DefaultValue = TextBox29.Text
        SqlDataSource2.InsertParameters("mothersname").DefaultValue = TextBox37.Text
        SqlDataSource2.InsertParameters("mothersphno").DefaultValue = TextBox38.Text
        SqlDataSource2.InsertParameters("aggrmarks").DefaultValue = Convert.ToDouble(TextBox39.Text)

        SqlDataSource2.Insert()
        'GridView3.DataBind()
        Label1.Text = "Data updated successfully."

        Dim cooki16 As New HttpCookie("studid")
        cooki16.Value = studid.ToString
        cooki16.Expires = DateTime.Now.AddMinutes(180)
        Response.Cookies.Add(cooki16)


        Dim cooki6 As New HttpCookie("colid")
        cooki6.Value = colid.ToString
        cooki6.Expires = DateTime.Now.AddMinutes(180)
        Response.Cookies.Add(cooki6)

        Dim cooki1 As New HttpCookie("name")
        cooki1.Value = TextBox2.Text & " " & TextBox3.Text
        cooki1.Expires = DateTime.Now.AddMinutes(180)
        Response.Cookies.Add(cooki1)

        'Response.Redirect("au_stud_addedu.aspx")
        Response.Redirect("au_adm_step2.aspx")

    End Sub
    'Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
    '    GridView3.DataBind()

    'End Sub



    Protected Sub CheckBox6_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox6.CheckedChanged
        If CheckBox6.Checked Then
            Panel1.Visible = True
        Else
            Panel1.Visible = False

        End If
    End Sub



    Protected Sub CheckBox5_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox5.CheckedChanged
        If CheckBox5.Checked Then
            panelhy.Visible = True

        Else
            Panel2.Visible = True
        End If
    End Sub


    Protected Sub SqlDataSource2_Selecting(sender As Object, e As SqlDataSourceSelectingEventArgs) Handles SqlDataSource2.Selecting

    End Sub

    Private Sub SqlDataSource2_Inserted(sender As Object, e As SqlDataSourceStatusEventArgs) Handles SqlDataSource2.Inserted
        studid = Convert.ToInt32(e.Command.Parameters("@studid").Value.ToString)

    End Sub
End Class
