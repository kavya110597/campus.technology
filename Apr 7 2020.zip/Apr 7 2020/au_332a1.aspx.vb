﻿
Imports Telerik.Web.UI.ExportInfrastructure
Imports Telerik.Web.UI
Imports System.Data
Imports System.Data.SqlClient
Partial Class faculty_au_332a1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try

        If Not Page.IsPostBack Then

            Dim collegename As String
            Dim facultyid As String

            collegename = Request.Cookies("collegename").Value.ToString.Replace(" ", "")
            facultyid = Request.Cookies("nemployeeid").Value.ToString
            Dim type As String

            type = "IPR"
            'HyperLink3.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink1.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink1.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

        End If
    End Sub

    Protected Sub RadGrid1_InfrastructureExporting(sender As Object, e As Telerik.Web.UI.GridInfrastructureExportingEventArgs) Handles RadGrid1.InfrastructureExporting

        Dim exportStructure As ExportStructure = e.ExportStructure

        Dim table As Telerik.Web.UI.ExportInfrastructure.Table = exportStructure.Tables(0)

        table.ShiftRowsDown(1, 1)

        table.Cells("A1").Value = "3.3.2 Number of workshops/seminars conducted on Intellectual Property Rights (IPR) and Industry-Academia Innovative practices during the last five years (06)"
        ' table.Cells("A2").Value = "3.1.3 Average number of research projects per teacher funded by government and non-government agencies during the last five years  (For UG Colleges weightage of this metric will be 7)    (4)"
        'table.Cells("A3").Value = "2.1.1 Average percentage of students from other States and Countries during the last five years (10)"

    End Sub
    Protected Sub RadButton1_Click(sender As Object, e As EventArgs) Handles RadButton1.Click
        Literal1.Text = ""

        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try

        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString

        Dim tp As Double = 0
        Dim tf As Double = 1
        Dim score1 As Double = 0

        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "Select count(*) from activity_project where colid=" & colid
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                tp = Convert.ToDouble(rdr1.GetValue(0).ToString)
            Loop
            rdr1.Close()
            cmd1.CommandText = "Select count(*) from designation where colid=" & colid
            rdr1 = cmd1.ExecuteReader
            Do While rdr1.Read
                tf = Convert.ToDouble(rdr1.GetValue(0).ToString)
            Loop
            rdr1.Close()
            con1.Close()
        End Using
        Try
            score1 = tp / tf

        Catch ex As Exception

        End Try

        Literal1.Text = "<h4>Indicative score</h4><br><br>"
        Literal1.Text = Literal1.Text & "Indicative score as per manual for this question is " & score1.ToString


    End Sub
    Public Function getinterpretation(ByVal d1 As Double) As String
        Dim str1 As String = String.Empty
        If d1 <= 50 Then
            str1 = "Low Percentage. Current value " & Math.Round(d1, 2).ToString & "<br>"
        ElseIf d1 > 50 AndAlso d1 <= 70 Then
            str1 = "Medium Percentage. Current value " & Math.Round(d1, 2).ToString & "<br>"
        Else
            str1 = "Good Percentage. Current value " & Math.Round(d1, 2).ToString & "<br>"
        End If

        Return str1

    End Function
    Protected Sub ASPxButton1_Click(sender As Object, e As EventArgs) Handles ASPxButton1.Click
        Label1.Text = ""
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        Dim empid As Integer = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
        Dim str1 As String
        str1 = "Update au_accr_status set status='Completed',empid='" & empid & "' where colid='" & colid & "' and accr='NAAC' and questions='3.3.2' and type1='ACollege' and cr='3'"
        Dim c1 As Integer = update1(str1)
        If c1 = 0 Then
            str1 = "Insert into au_accr_status(status,empid,colid,accr,questions,type1,cr) values('Completed','" & empid & "','" & colid & "','NAAC','3.3.2','ACollege','3')"
            c1 = update1(str1)
        End If
        Label1.Text = "Status is updated"
    End Sub
    Protected Sub ASPxButton2_Click(sender As Object, e As EventArgs) Handles ASPxButton2.Click
        Label1.Text = ""
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        Dim empid As Integer = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
        Dim str1 As String
        str1 = "Update au_accr_status set status='Pending',empid='" & empid & "' where colid='" & colid & "' and accr='NAAC' and questions='3.3.2' and type1='ACollege' and cr='3'"
        Dim c1 As Integer = update1(str1)
        If c1 = 0 Then
            str1 = "Insert into au_accr_status(status,empid,colid,accr,questions,type1,cr) values('Pending','" & empid & "','" & colid & "','NAAC','3.3.2','ACollege','3')"
            c1 = update1(str1)
        End If
        Label1.Text = "Status is updated"
    End Sub
    Public Function update1(ByVal str1 As String) As Integer
        Dim c1 As Integer = 0
        Dim constr1 As String

        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = str1
            c1 = cmd1.ExecuteNonQuery

            con1.Close()
        End Using
        Return c1

    End Function
    Protected Sub RadButton2_Click(sender As Object, e As EventArgs) Handles RadButton2.Click
        RadGrid1.DataBind()

    End Sub
End Class
