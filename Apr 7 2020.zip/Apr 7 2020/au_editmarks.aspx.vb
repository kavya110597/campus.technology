﻿
Partial Class au_editmarks
    Inherits System.Web.UI.Page

End Class
