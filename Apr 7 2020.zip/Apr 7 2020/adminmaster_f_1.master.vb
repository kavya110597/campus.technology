﻿
Partial Class adminmaster_f_1
    Inherits System.Web.UI.MasterPage
End Class

