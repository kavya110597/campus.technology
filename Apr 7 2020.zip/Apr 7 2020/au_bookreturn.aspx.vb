﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class au_bookreturn
    Inherits System.Web.UI.Page
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim colid, bookid As Integer
        Dim cookie1 As HttpCookie = Request.Cookies("colid")
        If cookie1 Is Nothing Then
            Response.Redirect("facultylogin.aspx")
        Else
            colid = Convert.ToInt32(cookie1.Value.ToString)
        End If
        Dim amt1 As Double
        Try
            amt1 = Convert.ToDouble(Tb_amount.Text)
        Catch ex As Exception

        End Try
        Dim overdue As Double = 0

        If student_rcb.SelectedItem Is Nothing OrElse student_rcb.SelectedIndex = -1 Then
            Label1.Text = "Please select Student"
            Label1.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If Tb_return.Text = "" Then
            Label1.Text = "Enter Date"
            Label1.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If IsDate(Tb_return.Text) = False Then
            Label1.Text = "Invalid Date"
            Label1.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        'Dim borrowdate As Date = Convert.ToDateTime(Tb_borrow.Text)
        Dim date1 As Date = Convert.ToDateTime(Tb_return.Text)
        Dim studentid As Integer = Convert.ToInt32(student_rcb.SelectedValue.ToString)
        Dim fieldValues As List(Of Object) = ASPxGridView1.GetSelectedFieldValues(New String() {"Id", "OverDue"})

        If fieldValues.Count = 0 Then
            Label1.Text = "Please select atleast one data"
            Label1.ForeColor = Drawing.Color.Red
            Exit Sub
            Return
        Else
            For Each item As Object() In fieldValues
                Dim str1 As String
                bookid = Convert.ToInt32(item(0).ToString())
                overdue = Convert.ToDouble(item(1).ToString())
                If overdue < 0 Then
                    overdue = 0
                End If
                Dim todaydate As Date = DateTime.Now
                Dim penalty1 As Double = Convert.ToDouble(item(1).ToString()) * amt1
                str1 = "update lib2issue set Returndate=@todaydate,Penalty=@panelty1, Overdue=@overdue,date1=@date1, Status='Closed' where id=@bookid"
                'Dim cs1 As New schoolclass1
                insertdata(str1, todaydate, penalty1, overdue, date1, bookid)
            Next
            ASPxGridView1.DataBind()
            Label1.Text = "Book Returned"
            Label1.ForeColor = Drawing.Color.Green
        End If

    End Sub
    Public Sub insertdata(ByVal str1 As String, ByVal todaydate As Date, ByVal panelty1 As Double, ByVal overdue As Double, ByVal date1 As Date, ByVal bookid As Integer)
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = str1
            cmd1.Parameters.AddWithValue("@todaydate", todaydate).DbType = DbType.Date
            cmd1.Parameters.AddWithValue("@panelty1", panelty1).DbType = DbType.Double

            cmd1.Parameters.AddWithValue("@overdue", overdue).DbType = DbType.Double
            cmd1.Parameters.AddWithValue("@date1", date1).DbType = DbType.Date
            cmd1.Parameters.AddWithValue("@bookid", bookid).DbType = DbType.Int32

            cmd1.ExecuteNonQuery()
            con1.Close()
        End Using
    End Sub
End Class
