﻿
Partial Class au_attendancesheet_1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub
    Protected Sub ImageWord_Click(sender As Object, e As ImageClickEventArgs) Handles ImageWord.Click
        ASPxPivotGridExporter1.ASPxPivotGridID = "ASPxPivotGrid1"
        ASPxPivotGridExporter1.ExportRtfToResponse("PivotExport.rtf")

    End Sub
    Protected Sub ImageExcel_Click(sender As Object, e As ImageClickEventArgs) Handles ImageExcel.Click
        ASPxPivotGridExporter1.ASPxPivotGridID = "ASPxPivotGrid1"
        ASPxPivotGridExporter1.ExportCsvToResponse("PivotExport.csv")

    End Sub
    Protected Sub ImagePDF_Click(sender As Object, e As ImageClickEventArgs) Handles ImagePDF.Click
        ASPxPivotGridExporter1.ASPxPivotGridID = "ASPxPivotGrid1"
        ASPxPivotGridExporter1.ExportPdfToResponse("PivotExport.pdf")

    End Sub
End Class
