﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Partial Class au_exam_questions1
    Inherits System.Web.UI.Page
    Protected Sub RadButton1_Click(sender As Object, e As EventArgs) Handles RadButton1.Click
        Dim empid As Integer
        Try
            empid = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        Dim mcqid As Integer
        If RadComboBox3.SelectedIndex = -1 Then
            Page.ClientScript.RegisterStartupScript(Me.[GetType](), "Alert", "alert('Please select Exam');", True)
            Exit Sub
        End If
        mcqid = Convert.ToInt32(RadComboBox3.SelectedValue.ToString)
        If FileUpload1.HasFile Then
            Dim file As HttpPostedFile = FileUpload1.PostedFile
            Dim filesize As Integer = file.ContentLength
            If filesize > 4194304 Then
                Page.ClientScript.RegisterStartupScript(Me.[GetType](), "Alert", "alert('File exceeds the maximum size limit i.e. 4MB');", True)

                Exit Sub
            End If

            Dim filename As String = Path.GetFileName(FileUpload1.FileName)
            Dim extension As String = Path.GetExtension(filename)

            If extension <> ".pdf" Then
                Page.ClientScript.RegisterStartupScript(Me.[GetType](), "Alert", "alert('Invalid file extension.Please upload pdf document');", True)

                Exit Sub
            End If

            Dim newid As String = Guid.NewGuid().ToString()

            Dim newfilename As String = empid & "_" & mcqid & "_" & newid & "_" & filename
            Dim path1 As String = "employee/files/" & newfilename
            Dim dir1 As String = Server.MapPath(".") & "\employee\files"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If

            Dim fileLocation As String = String.Format("{0}\{1}\{2}", Server.MapPath("."), "employee\files", newfilename)

            Try
                FileUpload1.SaveAs(fileLocation)
                Dim str1 As String

                str1 = "Update au_questions set pdffile=@payee where examid=" & mcqid
                Dim cs1 As New schoolclass1
                cs1.insertdata(str1, path1)
                Literal1.Text = "File uploaded successfully."
                ASPxGridView2.DataBind()
            Catch ex As Exception
                Literal1.Text = "Error. " & ex.Message.ToString

            End Try

        Else
            Page.ClientScript.RegisterStartupScript(Me.[GetType](), "Alert", "alert('Please select file');", True)
            Exit Sub
        End If
    End Sub
End Class
