﻿
Partial Class faculty_au_batch
    Inherits System.Web.UI.Page
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim principalid As String = Request.Cookies("principalid").Value.ToString
        If principalid = -1 Then
            Response.Redirect("au_notauthorised.aspx")
        End If
    End Sub
End Class
