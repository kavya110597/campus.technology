﻿
Partial Class au_assessmarks_studwise
    Inherits System.Web.UI.Page

End Class
