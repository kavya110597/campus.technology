﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Data.OleDb
Imports System.Drawing
Partial Class au_actpublication
    Inherits System.Web.UI.Page
    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        LPub.Text = ""
        If TBtitle.Text = "" OrElse TBpublicationname.Text = "" OrElse TBpublisher.Text = "" OrElse TBisbn.Text = "" OrElse TBcoauthor.Text = "" OrElse TBpeer.Text = "" OrElse TByop.Text = "" Then
            LPub.Text = "Please enter all details."
            LPub.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If DLmainauthor.SelectedValue.ToString = "-1" Then
            LPub.Text = "Please select main Auther Status."
            LPub.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If DLlevel1.SelectedValue.ToString = "-1" Then

            LPub.Text = "Please select ISBN Status."
            LPub.ForeColor = Drawing.Color.Red
            Exit Sub
        End If

        If FileUploadpub.HasFile Then
            Dim file As HttpPostedFile = FileUploadpub.PostedFile
            Dim filesize As Integer = file.ContentLength
            If filesize > 1000000 Then
                LPub.Text = "File exceeds the maximum size limit i.e. 1MB"
                LPub.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim extensionlist() As String = {".doc", ".docx", ".jpeg", ".gif", ".png", ".pdf", ".jpg"}
            Dim filename As String = Path.GetFileName(FileUploadpub.FileName)
            Dim extension As String = Path.GetExtension(filename)

            If extensionlist.Contains(extension) = False Then
                LPub.Text = "Invalid file extension.Please upload .doc or .pdf or .jpeg or .png or .jpg or .gif"
                LPub.ForeColor = Drawing.Color.Red
                Exit Sub
            End If


            Dim path1 As String = "students/photos/" & filename
            Dim dir1 As String = Server.MapPath(".") & "\students\photos"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If
            Dim path2 As String = Server.MapPath(".") & "\students\photos\" & filename
            FileUploadpub.SaveAs(path2)
            SqlDataSource15.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
            SqlDataSource15.InsertParameters("empid").DefaultValue = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)

            SqlDataSource15.InsertParameters("title").DefaultValue = TBtitle.Text
            SqlDataSource15.InsertParameters("publicationname").DefaultValue = TBpublicationname.Text
            SqlDataSource15.InsertParameters("publisher").DefaultValue = TBpublisher.Text
            SqlDataSource15.InsertParameters("isbn").DefaultValue = TBisbn.Text
            SqlDataSource15.InsertParameters("coauthor").DefaultValue = TBcoauthor.Text
            SqlDataSource15.InsertParameters("peer").DefaultValue = TBpeer.Text
            SqlDataSource15.InsertParameters("mainauthor").DefaultValue = DLmainauthor.SelectedValue.ToString()
            SqlDataSource15.InsertParameters("level1").DefaultValue = DLlevel1.SelectedValue.ToString()
            SqlDataSource15.InsertParameters("type").DefaultValue = DLtype.SelectedValue.ToString()
            SqlDataSource15.InsertParameters("yop").DefaultValue = TByop.Text
            SqlDataSource15.InsertParameters("status").DefaultValue = "Applied"
            SqlDataSource15.InsertParameters("certificate").DefaultValue = path1
            SqlDataSource15.Insert()
            LPub.Text = "Publication Added."
            LPub.ForeColor = Drawing.Color.Green
            GridView1.DataBind()

        Else

            SqlDataSource15.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
            SqlDataSource15.InsertParameters("empid").DefaultValue = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)

            SqlDataSource15.InsertParameters("title").DefaultValue = TBtitle.Text
            SqlDataSource15.InsertParameters("publicationname").DefaultValue = TBpublicationname.Text
            SqlDataSource15.InsertParameters("publisher").DefaultValue = TBpublisher.Text
            SqlDataSource15.InsertParameters("isbn").DefaultValue = TBisbn.Text
            SqlDataSource15.InsertParameters("coauthor").DefaultValue = TBcoauthor.Text
            SqlDataSource15.InsertParameters("peer").DefaultValue = TBpeer.Text
            SqlDataSource15.InsertParameters("mainauthor").DefaultValue = DLmainauthor.SelectedValue.ToString()
            SqlDataSource15.InsertParameters("level1").DefaultValue = DLlevel1.SelectedValue.ToString()
            SqlDataSource15.InsertParameters("type").DefaultValue = DLtype.SelectedValue.ToString()
            SqlDataSource15.InsertParameters("yop").DefaultValue = TByop.Text
            SqlDataSource15.InsertParameters("status").DefaultValue = "Applied"


            SqlDataSource15.Insert()
            LPub.Text = "Publication Added."
            LPub.ForeColor = Drawing.Color.Green
            GridView1.DataBind()
        End If
    End Sub
    Private Sub GridView1_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView1.RowCommand
        Labelpub.Text = ""
        LPub.Text = ""
        If e.CommandName = "save" Then
            Dim rowid As Integer = Convert.ToInt32(e.CommandArgument.ToString)
            Dim lbl1 As Label = CType(GridView1.Rows(rowid).FindControl("Labelid2pub"), Label)
            Dim fileid As Integer = Convert.ToInt32(lbl1.Text.ToString)
            Dim FileUploadsave As FileUpload
            FileUploadsave = CType(GridView1.Rows(rowid).FindControl("FileUploadcertipub"), FileUpload)
            Dim filename As String = ""
            Dim path1 As String = ""

            If FileUploadsave.HasFile Then
                Dim file As HttpPostedFile = FileUploadsave.PostedFile
                Dim filesize As Integer = file.ContentLength
                If filesize > 1000000 Then
                    Labelpub.Text = "File exceeds the maximum size limit i.e. 1MB"
                    Labelpub.ForeColor = Drawing.Color.Red
                    Exit Sub
                End If
                Dim extensionlist() As String = {".doc", ".docx", ".jpeg", ".gif", ".png", ".pdf", ".jpg"}
                filename = Path.GetFileName(FileUploadsave.FileName)
                Dim extension As String = Path.GetExtension(filename)

                If extensionlist.Contains(extension) = False Then
                    Labelpub.Text = "Invalid file extension.Please upload .doc or .pdf or .jpeg or .png or .jpg or .gif"
                    Labelpub.ForeColor = Drawing.Color.Red
                    Exit Sub
                End If
                path1 = "students/photos/" & filename
                Dim dir1 As String = Server.MapPath(".") & "\students\photos\"
                If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                    My.Computer.FileSystem.CreateDirectory(dir1)
                End If
                Dim path2 As String = Server.MapPath(".") & "\students\photos\" & filename

                FileUploadsave.SaveAs(path2)


            End If
            Dim str1 As String
            str1 = "Update activity_pub set certificate=@path1 where Id=@id"
            updatedata(str1, path1, fileid)
            Labelpub.Text = "File Uploaded."
            Labelpub.ForeColor = Drawing.Color.Green
            GridView1.DataBind()

        End If
    End Sub
    Protected Sub BPubExcel_Click(sender As Object, e As EventArgs) Handles BPubExcel.Click
        LPub.Text = ""
        If FileUpload2.HasFile Then
            Dim file As HttpPostedFile = FileUpload2.PostedFile
            Dim filesize As Integer = file.ContentLength
            If filesize > 4194304 Then
                LPub.Text = "File exceeds the maximum size limit i.e. 4MB"
                LPub.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim filename As String = Path.GetFileName(FileUpload2.FileName)
            Dim extension As String = Path.GetExtension(filename)



            If extension <> ".xls" AndAlso extension <> ".xlsx" Then
                LPub.Text = "Invalid file extension.Please upload .xls or .xlsx file"
                LPub.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim path1 As String = "employee/photos/" & filename
            Dim dir1 As String = Server.MapPath(".") & "\employee\files"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If
            Dim path2 As String = Server.MapPath(".") & "\employee\files\" & filename

            FileUpload2.SaveAs(path2)


            Dim constr1 As String

            constr1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & path2 & ";Extended Properties=""Excel 12.0 Xml;HDR=YES"";"
            Using con1 As New OleDbConnection
                con1.ConnectionString = constr1
                con1.Open()
                Dim cmd1 As New OleDbCommand
                cmd1.Connection = con1
                cmd1.CommandText = "Select * from [Sheet1$]"
                Dim rdr1 As OleDbDataReader = cmd1.ExecuteReader

                Do While rdr1.Read

                    SqlDataSource15.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
                    SqlDataSource15.InsertParameters("empid").DefaultValue = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)

                    SqlDataSource15.InsertParameters("title").DefaultValue = rdr1.GetValue(0).ToString
                    SqlDataSource15.InsertParameters("publicationname").DefaultValue = rdr1.GetValue(1).ToString
                    SqlDataSource15.InsertParameters("publisher").DefaultValue = rdr1.GetValue(2).ToString
                    SqlDataSource15.InsertParameters("isbn").DefaultValue = rdr1.GetValue(3).ToString
                    SqlDataSource15.InsertParameters("coauthor").DefaultValue = rdr1.GetValue(4).ToString
                    SqlDataSource15.InsertParameters("peer").DefaultValue = rdr1.GetValue(5).ToString
                    SqlDataSource15.InsertParameters("mainauthor").DefaultValue = rdr1.GetValue(6).ToString
                    SqlDataSource15.InsertParameters("level1").DefaultValue = rdr1.GetValue(7).ToString
                    SqlDataSource15.InsertParameters("type").DefaultValue = rdr1.GetValue(8).ToString
                    SqlDataSource15.InsertParameters("yop").DefaultValue = rdr1.GetValue(9).ToString
                    SqlDataSource15.InsertParameters("status").DefaultValue = "Applied"

                    SqlDataSource15.Insert()
                    GridView1.DataBind()


                Loop
                rdr1.Close()
                con1.Close()
            End Using

            LPub.Text = "Publication(s) Added."
            LPub.ForeColor = Drawing.Color.Green
            GridView1.DataBind()
        Else
            LPub.Text = "File is either not Selected or is Empty."
            LPub.ForeColor = Drawing.Color.Red
            Exit Sub
        End If

    End Sub
    Public Sub updatedata(ByVal str As String, ByVal path1 As String, ByVal rowid As Integer)
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = str

            cmd1.Parameters.AddWithValue("@id", rowid).DbType = DbType.Int32
            cmd1.Parameters.AddWithValue("@path1", path1).DbType = DbType.String
            cmd1.ExecuteNonQuery()
            con1.Close()

        End Using
    End Sub
End Class
