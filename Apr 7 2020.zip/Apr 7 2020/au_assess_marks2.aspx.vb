﻿Imports System
Imports Telerik.Web.UI
Imports DevExpress.Web
Imports System.Data
Imports System.Data.SqlClient
Imports DevExpress.XtraPrinting
Imports System.Drawing.Color

Partial Class au_assess_marks2
    Inherits System.Web.UI.Page

    Protected Sub ImageExcel_Click(sender As Object, e As ImageClickEventArgs) Handles ImageExcel.Click

        ASPxGridViewExporter1.GridViewID = "ASPxGridView2"

        ASPxGridViewExporter1.WriteXlsxToResponse(New XlsxExportOptionsEx With {.ExportType = DevExpress.Export.ExportType.WYSIWYG})
    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Literal1.Text = ""
        Dim colid, empid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
            empid = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try

        Dim classgid As Integer
        Try
            classgid = Convert.ToInt32(RadComboBox1.SelectedValue.ToString)
        Catch ex As Exception
            Label1.Text = "Please Select Class"
            Label1.ForeColor = Red
            Exit Sub
        End Try

        If RadComboBox2.SelectedIndex = -1 Then
            Label1.Text = "Please select semester."
            Label1.ForeColor = Red
            Exit Sub
        End If

        Dim semester As String = RadComboBox2.SelectedValue.ToString


        If TextBox1.Text = "" Then
            Label1.Text = "Please Enter Threshold Marks"
            Label1.ForeColor = Red
            Exit Sub
        End If
        Dim threshold As Double = Convert.ToDouble(TextBox1.Text)
        Dim T1, T2, T3, T4, T5 As Double
        Dim status1 As String
        If ASPxGridView1.Selection.Count = 0 Then
            Dim script As String = "window.onload = function(){ alert('"
            script += "There were no Students Selected. \nYou need to select atleast one student "
            'script += "using the first check."
            script += "')};"
            ClientScript.RegisterStartupScript(Me.[GetType](), "FailMessage", script, True)
        Else
            For i As Integer = 0 To ASPxGridView1.VisibleRowCount - 1
                'Here I need to identify if the row I am iterating through is selected or not 
                If ASPxGridView1.Selection.IsRowSelected(i) Then
                    'exa = New ExchangeAccounts()
                    Dim id As Integer = Convert.ToInt32(ASPxGridView1.GetRowValues(i, ASPxGridView1.KeyFieldName))
                    ' If exa.GetRecord(id, Cn) Then
                    Dim cb As ASPxTextBox = TryCast(ASPxGridView1.FindRowCellTemplateControl(i, TryCast(ASPxGridView1.Columns("LowerBound"), GridViewDataColumn), "ASPxTextBox1"), ASPxTextBox)
                    Dim cb1 As ASPxTextBox = TryCast(ASPxGridView1.FindRowCellTemplateControl(i, TryCast(ASPxGridView1.Columns("LowerBound1"), GridViewDataColumn), "ASPxTextBox2"), ASPxTextBox)
                    Dim cb2 As ASPxTextBox = TryCast(ASPxGridView1.FindRowCellTemplateControl(i, TryCast(ASPxGridView1.Columns("LowerBound2"), GridViewDataColumn), "ASPxTextBox3"), ASPxTextBox)
                    Dim cb3 As ASPxTextBox = TryCast(ASPxGridView1.FindRowCellTemplateControl(i, TryCast(ASPxGridView1.Columns("LowerBound3"), GridViewDataColumn), "ASPxTextBox4"), ASPxTextBox)
                    Dim cb4 As ASPxTextBox = TryCast(ASPxGridView1.FindRowCellTemplateControl(i, TryCast(ASPxGridView1.Columns("LowerBound4"), GridViewDataColumn), "ASPxTextBox5"), ASPxTextBox)
                    'Dim cb5 As ASPxTextBox = TryCast(ASPxGridView1.FindRowCellTemplateControl(i, TryCast(ASPxGridView1.Columns("LowerBound5"), GridViewDataColumn), "ASPxTextBox6"), ASPxTextBox)
                    Dim cb6 As ASPxTextBox = TryCast(ASPxGridView1.FindRowCellTemplateControl(i, TryCast(ASPxGridView1.Columns("LowerBound6"), GridViewDataColumn), "ASPxTextBox7"), ASPxTextBox)

                    'Leader?
                    'If cb.Text = "" OrElse cb1.Text = "" OrElse cb2.Text = "" OrElse cb3.Text = "" OrElse cb4.Text = "" OrElse cb6.Text = "" Then
                    '    Label1.Text = "Please Enter T1/T2/T3/T4/T5/Grade/Status"
                    '    Label1.ForeColor = Red
                    '    Exit Sub
                    'End If
                    T1 = Convert.ToDouble(cb.Text)
                    T2 = Convert.ToDouble(cb1.Text)
                    T3 = Convert.ToDouble(cb2.Text)
                    T4 = Convert.ToDouble(cb3.Text)
                    T5 = Convert.ToDouble(cb4.Text)
                    'grade1 = Convert.ToString(cb5.Text)
                    'status1 = Convert.ToString(cb6.Text)
                    status1 = "Completed with all requirements"
                    'If ia1 > 10.0 Then
                    '    Label1.Text = "IA 1 marks cannot be greater than 10"
                    '    Label1.ForeColor = Red
                    '    Exit Sub
                    'End If
                    'If ia2 > 10.0 Then
                    '    Label1.Text = "IA 2 marks cannot be greater than 10"
                    '    Label1.ForeColor = Red
                    '    Exit Sub
                    'End If
                    'If attendance > 5.0 Then
                    '    Label1.Text = "Attendance cannot be greater than 5"
                    '    Label1.ForeColor = Red
                    '    Exit Sub
                    'End If
                    'If other > 5.0 Then
                    '    Label1.Text = "Other marks cannot be greater than 5"
                    '    Label1.ForeColor = Red
                    '    Exit Sub
                    'End If
                    Dim top1 As Double
                    Dim top2 As Double
                    If T1 >= T2 AndAlso T1 >= T3 Then
                        top1 = T1
                        If T2 >= T3 Then
                            top2 = T2
                        Else
                            top2 = T3
                        End If
                    ElseIf T2 >= T1 AndAlso T2 >= T3 Then
                        top1 = T2
                        If T1 >= T3 Then
                            top2 = T1
                        Else
                            top2 = T3
                        End If
                    ElseIf T3 >= T1 AndAlso T3 >= T2 Then
                        top1 = T3
                        If T1 >= T2 Then
                            top2 = T1
                        Else
                            top2 = T2
                        End If

                    End If

                    Dim bt As Double = top1 + top2


                    Dim total As Double ' = T1 + T2 + T3 + T4 + T5
                    total = top1 + top2 + T4 + T5
                    Dim gp As Double
                    Dim lg As String = String.Empty
                    Dim total1 As Double = Math.Ceiling(total)

                    Dim programid As Integer = getprogramid(classgid)

                    Dim constr1 As String
                    constr1 = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString
                    Dim a As Boolean = False
                    Dim em As String = ""
                    Using con1 As New SqlConnection
                        con1.ConnectionString = constr1
                        con1.Open()
                        Dim cmd1 As New SqlCommand
                        cmd1.Connection = con1
                        cmd1.CommandText = "select gradepoint,grade from au_cbcs_cons where minmarks <" & total & " and maxmarks > " & total & " and programid=" & programid
                        cmd1.CommandText = "select gradepoint,grade,status from au_cbcs_cons where minmarks <" & total & " and maxmarks > " & total & " and programid=" & programid
                        cmd1.CommandText = "select gradepoint,grade,status from au_cbcs_cons where minmarks <=" & total1 & " and maxmarks >= " & total1 & " and programid=" & programid

                        Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
                        Do While rdr1.Read
                            gp = Convert.ToDouble(rdr1.GetValue(0).ToString)
                            lg = rdr1.GetValue(1).ToString
                            status1 = rdr1.GetValue(2).ToString

                        Loop
                        rdr1.Close()
                        con1.Close()
                    End Using





                    'If total < 35 Then
                    '    gp = 0
                    '    lg = "F"
                    '    status1 = "Fail"
                    'ElseIf total > 34 AndAlso total < 40 Then
                    '    gp = 4
                    '    lg = "P"
                    'ElseIf total > 39 AndAlso total < 50 Then
                    '    gp = 5
                    '    lg = "C"
                    'ElseIf total > 49 AndAlso total < 55 Then
                    '    gp = 6
                    '    lg = "B"
                    'ElseIf total > 54 AndAlso total < 70 Then
                    '    gp = 7
                    '    lg = "B+"
                    'ElseIf total > 69 AndAlso total < 80 Then
                    '    gp = 8
                    '    lg = "A"
                    'ElseIf total > 79 AndAlso total < 90 Then
                    '    gp = 9
                    '    lg = "A+"
                    'ElseIf total > 89 AndAlso total < 101 Then
                    '    gp = 10
                    '    lg = "O"
                    'End If

                    Dim coursecredit As Double = getcoursecredit(classgid)
                    Dim cgpa As Double

                    cgpa = gp * coursecredit



                    If total < threshold Then
                        Literal1.Text += id.ToString & ","
                    Else
                        If checkstud(id, classgid, colid, empid) = True Then
                            deletedata(id, classgid, colid, empid)
                            SqlDataSource5.InsertParameters("colid").DefaultValue = colid
                            SqlDataSource5.InsertParameters("studid").DefaultValue = id
                            SqlDataSource5.InsertParameters("empid").DefaultValue = empid
                            SqlDataSource5.InsertParameters("classgid").DefaultValue = classgid
                            SqlDataSource5.InsertParameters("t1").DefaultValue = T1
                            SqlDataSource5.InsertParameters("t2").DefaultValue = T2
                            SqlDataSource5.InsertParameters("t3").DefaultValue = T3
                            SqlDataSource5.InsertParameters("t4").DefaultValue = T4
                            SqlDataSource5.InsertParameters("t5").DefaultValue = T5
                            SqlDataSource5.InsertParameters("grade").DefaultValue = lg
                            SqlDataSource5.InsertParameters("status").DefaultValue = status1
                            SqlDataSource5.InsertParameters("gradepoints").DefaultValue = gp
                            SqlDataSource5.InsertParameters("bestoftwo").DefaultValue = bt
                            SqlDataSource5.InsertParameters("total").DefaultValue = total
                            SqlDataSource5.InsertParameters("cgpa").DefaultValue = cgpa
                            SqlDataSource5.InsertParameters("coursecredit").DefaultValue = coursecredit
                            SqlDataSource5.InsertParameters("semester").DefaultValue = semester

                            SqlDataSource5.Insert()
                        Else
                            SqlDataSource5.InsertParameters("colid").DefaultValue = colid
                            SqlDataSource5.InsertParameters("studid").DefaultValue = id
                            SqlDataSource5.InsertParameters("empid").DefaultValue = empid
                            SqlDataSource5.InsertParameters("classgid").DefaultValue = classgid
                            SqlDataSource5.InsertParameters("t1").DefaultValue = T1
                            SqlDataSource5.InsertParameters("t2").DefaultValue = T2
                            SqlDataSource5.InsertParameters("t3").DefaultValue = T3
                            SqlDataSource5.InsertParameters("t4").DefaultValue = T4
                            SqlDataSource5.InsertParameters("t5").DefaultValue = T5
                            SqlDataSource5.InsertParameters("grade").DefaultValue = lg
                            SqlDataSource5.InsertParameters("status").DefaultValue = status1
                            SqlDataSource5.InsertParameters("gradepoints").DefaultValue = gp
                            SqlDataSource5.InsertParameters("bestoftwo").DefaultValue = bt
                            SqlDataSource5.InsertParameters("total").DefaultValue = total
                            SqlDataSource5.InsertParameters("cgpa").DefaultValue = cgpa
                            SqlDataSource5.InsertParameters("coursecredit").DefaultValue = coursecredit
                            SqlDataSource5.InsertParameters("semester").DefaultValue = semester

                            SqlDataSource5.Insert()
                        End If

                    End If

                    ASPxGridView2.DataBind()
                    Label1.Text = "Marks updated."
                    Label1.ForeColor = Green
                    If Literal1.Text = "" Then
                    Else
                        Label2.Text = "Data for students with following ids are not updated :"
                        Literal1.Text = Literal1.Text.TrimStart(",")
                    End If

                    'End If
                End If
            Next
        End If
    End Sub
    Public Function checkstud(ByVal studid As Integer, ByVal classgid As Integer, ByVal colid As Integer, ByVal empid As Integer) As Boolean
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString
        Dim a As Boolean = False
        Dim em As String = ""
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "Select studid from au_assess_marks where studid=@studid AND classgid=@classgid AND colid=@colid AND empid=@empid"
            cmd1.Parameters.AddWithValue("@studid", studid)
            cmd1.Parameters.AddWithValue("@classgid", classgid)
            cmd1.Parameters.AddWithValue("@colid", colid)
            cmd1.Parameters.AddWithValue("@empid", empid)
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                em = rdr1.GetValue(0).ToString

            Loop
            rdr1.Close()
            con1.Close()
        End Using
        If em.Length > 0 Then
            a = True
        End If
        Return a

    End Function
    Public Function getcoursecredit(ByVal classgid As Integer) As Integer
        Dim cc As Double = 1
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString
        Dim a As Boolean = False
        Dim em As String = ""
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "select nba_course.coursecredit from " &
"nba_course inner join au_assign_fac on au_assign_fac.courseid=nba_course.id " &
"where au_assign_fac.id=" & classgid

            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                cc = Convert.ToDouble(rdr1.GetValue(0).ToString)

            Loop
            rdr1.Close()
            con1.Close()
        End Using

        Return cc
    End Function

    Public Function getprogramid(ByVal classgid As Integer) As Integer
        Dim cc As Double = 1
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString
        Dim a As Boolean = False
        Dim em As String = ""
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "select progid From au_assign_fac where id=" & classgid

            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                cc = Convert.ToDouble(rdr1.GetValue(0).ToString)

            Loop
            rdr1.Close()
            con1.Close()
        End Using

        Return cc
    End Function

    Public Sub deletedata(ByVal studid As Integer, ByVal classgid As Integer, ByVal colid As Integer, ByVal empid As Integer)
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString

        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "Delete from au_assess_marks where studid=@studid AND classgid=@classgid AND colid=@colid AND empid=@empid"
            cmd1.Parameters.AddWithValue("@studid", studid)
            cmd1.Parameters.AddWithValue("@classgid", classgid)
            cmd1.Parameters.AddWithValue("@colid", colid)
            cmd1.Parameters.AddWithValue("@empid", empid)
            cmd1.ExecuteNonQuery()
            con1.Close()

        End Using

    End Sub
End Class
