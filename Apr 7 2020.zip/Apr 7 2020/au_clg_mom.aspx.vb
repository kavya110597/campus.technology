﻿Imports DevExpress.Web.ASPxGridView
Imports DevExpress.Web
Imports System.Data
Imports System.Data.SqlClient
Imports DevExpress.XtraGrid.Views.Base
Imports System.Globalization
Partial Class au_clg_mom
    Inherits System.Web.UI.Page
    Protected Sub ASPxGridView2_BeforePerformDataSelect(sender As Object, e As EventArgs)
        Dim dxgv1 As ASPxGridView = CType(sender, ASPxGridView)
        Dim lid As Integer = Convert.ToInt32(dxgv1.GetMasterRowKeyValue)

        Session("momid") = lid
    End Sub

    Protected Sub ASPxGridView1_CustomUnboundColumnData(ByVal sender As Object, ByVal e As DevExpress.Web.ASPxGridViewColumnDataEventArgs)
        If e.Column.FieldName = "UnboundTime" Then
            e.Value = Date.MinValue.Add(CType(e.GetListSourceFieldValue("Time"), TimeSpan))
        End If
    End Sub
    Protected Sub ASPxGridView1_RowInserting(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataInsertingEventArgs)
        Dim _date As Date = CDate(e.NewValues("UnboundTime"))
        e.NewValues("Time") = _date.TimeOfDay
    End Sub

    Protected Sub ASPxGridView1_RowUpdating(ByVal sender As Object, ByVal e As DevExpress.Web.Data.ASPxDataUpdatingEventArgs)
        Dim _date As Date = CDate(e.NewValues("UnboundTime"))
        e.NewValues("Time") = _date.TimeOfDay
    End Sub
End Class
