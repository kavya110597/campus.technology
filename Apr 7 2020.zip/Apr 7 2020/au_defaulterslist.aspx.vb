﻿
Partial Class au_defaulterslist
    Inherits System.Web.UI.Page

End Class
