﻿
Partial Class au_class_taken
    Inherits System.Web.UI.Page

End Class
