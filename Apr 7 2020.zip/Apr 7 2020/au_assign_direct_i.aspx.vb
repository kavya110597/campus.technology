﻿
Partial Class au_assign_direct_i
    Inherits System.Web.UI.Page

End Class
