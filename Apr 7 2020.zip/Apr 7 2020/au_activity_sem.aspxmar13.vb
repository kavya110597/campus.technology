﻿
Partial Class au_activity_sem
    Inherits System.Web.UI.Page

End Class
