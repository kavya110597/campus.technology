﻿
Partial Class au_attendanceallreport
    Inherits System.Web.UI.Page

End Class
