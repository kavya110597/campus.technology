﻿Imports System.IO
Imports System.Data.OleDb
Imports System.Data
Imports System.Data.SqlClient

Partial Class au_bos_minutes_up
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Literal1.Text = ""



        If FileUpload1.HasFile Then
            Dim file As HttpPostedFile = FileUpload1.PostedFile
            Dim filesize As Integer = file.ContentLength
            If filesize > 4194304 Then
                Label1.Text = "File exceeds the maximum size limit i.e. 4MB"
                ' Label1.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            'Dim extensionlist() As String = {".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".txt", ".rtf", ".bmp", ".jpeg", ".gif", ".tiff", ".png", ".pcx", ".emf", ".rle", ".dib", ".pdf"}
            Dim filename As String = System.Guid.NewGuid.ToString & "-" & Path.GetFileName(FileUpload1.FileName)
            Dim extension As String = Path.GetExtension(filename)

            'If extensionlist.Contains(extension) = False Then
            '    Page.ClientScript.RegisterStartupScript(Me.[GetType](), "Alert", "alert('Invalid file extension.Please upload .jpeg or .png or .jpg image');", True)

            '    Exit Sub
            'End If

            If extension <> ".xls" AndAlso extension <> ".xlsx" Then
                Label1.Text = "Invalid file extension.Please upload .xls or .xlsx file"
                'Label1.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim path1 As String = "employee/photos/" & filename
            Dim dir1 As String = Server.MapPath(".") & "\employee\files"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If
            Dim path2 As String = Server.MapPath(".") & "\employee\files\" & filename

            FileUpload1.SaveAs(path2)

            'Dim msg1 As New msgbox11

            Dim constr1 As String

            constr1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & path2 & ";Extended Properties=""Excel 12.0 Xml;HDR=YES"";"
            Using con1 As New OleDbConnection
                con1.ConnectionString = constr1
                con1.Open()
                Dim cmd1 As New OleDbCommand
                cmd1.Connection = con1
                cmd1.CommandText = "Select * from [Sheet1$]"
                Dim rdr1 As OleDbDataReader = cmd1.ExecuteReader

                Do While rdr1.Read



                    Try

                        SqlDataSource1.InsertParameters("AcademicYear").DefaultValue = rdr1.GetValue(0).ToString
                        SqlDataSource1.InsertParameters("CourseType").DefaultValue = rdr1.GetValue(1).ToString
                        SqlDataSource1.InsertParameters("ProgramName").DefaultValue = rdr1.GetValue(2).ToString
                        SqlDataSource1.InsertParameters("CourseName").DefaultValue = rdr1.GetValue(3).ToString
                        SqlDataSource1.InsertParameters("Department").DefaultValue = rdr1.GetValue(4).ToString
                        SqlDataSource1.InsertParameters("ChangeType").DefaultValue = rdr1.GetValue(5).ToString





                        SqlDataSource1.Insert()



                    Catch ex As Exception
                        Label1.Text = "Invalid Data Entry. Please check one or more data is in wrong format"
                        'Label1.ForeColor = Drawing.Color.Red
                        Exit Sub
                    End Try

                Loop
                rdr1.Close()
                con1.Close()
            End Using

            Label1.Text = "Data updated successfully."

        End If



    End Sub
End Class
