﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class au_att_bulk_multiple
    Inherits System.Web.UI.Page


    Protected Sub ASPxButton1_Click(sender As Object, e As EventArgs) Handles ASPxButton1.Click
        Literal1.Text = ""
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        If ASPxComboBox3.SelectedIndex = -1 OrElse ASPxComboBox4.SelectedIndex = -1 Then
            Exit Sub
        End If
        Dim sdate1 As DateTime
        Dim sdate2 As DateTime
        Try
            sdate1 = Convert.ToDateTime(ASPxDateEdit1.Date)
            sdate2 = Convert.ToDateTime(ASPxDateEdit2.Date)
        Catch ex As Exception
            Exit Sub
        End Try
        Dim status As String = ASPxComboBox4.Value.ToString
        Dim st1 As Integer = 0
        If status = "Present" Then
            st1 = 1
        End If

        Dim empid As Integer = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
        Dim str1 As String
        '        str1 = "update nba_attendance set attendancestatus=" & st1 & ", status='" & status & "' where classid in " &
        '"(select id from au_periods where colid=" & colid & " and starttime>= '" & sdate1 & "' and endtime <= '" & sdate2 & "') " &
        '"and colid=" & colid & " and studid=" & studid
        '        str1 = "update nba_attendance set attendancestatus=" & st1 & ", status='" & status & "',category='Other',editedbyempid='" & empid & "',comments=@payee where classid in " &
        '"(select id from au_periods where colid=" & colid & " and starttime>= '" & sdate1 & "' and endtime <= '" & sdate2 & "') " &
        '"and colid=" & colid & " and studid=" & studid

        Dim i As Integer = 0
        Dim fieldValues As List(Of Object) = ASPxGridView1.GetSelectedFieldValues(New String() {"id"})
        For Each item As Object In fieldValues
            Dim studid As Integer = Convert.ToInt32(item)
            str1 = "update nba_attendance set attendancestatus=" & st1 & ", status='" & status & "',category='" & RadComboBox3.SelectedValue.ToString & "'',editedbyempid='" & empid & "',comments=@payee where classid in " &
"(select id from au_periods where colid=" & colid & " and starttime>= '" & sdate1 & "' and endtime <= '" & sdate2 & "') " &
"and colid=" & colid & " and studid=" & studid
            i = i + 1

            Literal1.Text = insertdata(str1, ASPxTextBox1.Text).ToString & " records changed"
        Next
        If i > 0 Then
            Literal1.Text = i.ToString & " records changed."
        End If

    End Sub
    Public Function insertdata(ByVal str1 As String, ByVal payee As String)
        Dim aff As Integer = 0
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString

        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = str1
            cmd1.Parameters.AddWithValue("@payee", payee).DbType = DbType.String
            'cmd1.ExecuteNonQuery()
            aff = cmd1.ExecuteScalar
            con1.Close()

        End Using
        Return aff

    End Function

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub
End Class
