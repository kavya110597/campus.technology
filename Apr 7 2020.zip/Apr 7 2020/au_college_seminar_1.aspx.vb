﻿
Partial Class au_college_seminar_1
    Inherits System.Web.UI.Page

End Class
