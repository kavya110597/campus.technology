﻿
Partial Class au_cr7_report
    Inherits System.Web.UI.Page

End Class
