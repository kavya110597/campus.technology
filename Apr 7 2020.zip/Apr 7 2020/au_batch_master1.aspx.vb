﻿
Partial Class au_batch_master1
    Inherits System.Web.UI.Page

End Class
