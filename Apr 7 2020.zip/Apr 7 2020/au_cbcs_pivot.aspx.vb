﻿
Partial Class au_cbcs_pivot
    Inherits System.Web.UI.Page

End Class
