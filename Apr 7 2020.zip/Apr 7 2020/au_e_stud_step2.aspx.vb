﻿
Partial Class au_e_stud_step2
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Response.Redirect("https://campus.technology/erpnew/studentportal/au_studentlogin.aspx")
    End Sub
End Class
