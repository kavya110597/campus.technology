﻿
Partial Class au_capacity_remedial
    Inherits System.Web.UI.Page

End Class
