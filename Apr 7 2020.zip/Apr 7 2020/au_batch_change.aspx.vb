﻿
Partial Class au_batch_change
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Literal1.Text = ""

        If TextBox1.Text = "" OrElse RadComboBox1.SelectedIndex = -1 OrElse RadComboBox2.SelectedIndex = -1 Then
            Literal1.Text = "All fields are required."
            Exit Sub
        End If
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        Dim programid As Integer
        programid = Convert.ToInt32(RadComboBox1.SelectedValue.ToString)
        Dim str1 As String
        str1 = "Update au_students set batch=@payee where batch='" & RadComboBox2.SelectedValue.ToString & "' and colid=" & colid
        str1 = "Update au_students set batch=@payee where programid='" & programid & "' and batch='" & RadComboBox2.SelectedValue.ToString & "' and colid=" & colid



        Dim cs1 As New schoolclass1
        cs1.insertdata(str1, TextBox1.Text)
        str1 = "Update au_batch_master set batch=@payee where programid='" & programid & "' and batch='" & RadComboBox2.SelectedValue.ToString & "' and colid=" & colid
        cs1.insertdata(str1, TextBox1.Text)

        Literal1.Text = "Batch updated."


    End Sub
End Class
