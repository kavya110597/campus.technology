﻿Imports System.IO
Imports System.Data.OleDb
Imports DevExpress.XtraPrinting
Imports Telerik.Web.UI
Imports System.Data
Imports System.Data.SqlClient
Partial Class au_exam_test1
    Inherits System.Web.UI.Page


    Dim ht1 As Hashtable

    Protected Sub RadButton2_Click(sender As Object, e As EventArgs) Handles RadButton2.Click

        ht1 = New Hashtable
        Literal1.Text = ""

        If FileUpload1.HasFile Then
            Dim file As HttpPostedFile = FileUpload1.PostedFile
            Dim filesize As Integer = file.ContentLength

            'Dim extensionlist() As String = {".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".txt", ".rtf", ".bmp", ".jpeg", ".gif", ".tiff", ".png", ".pcx", ".emf", ".rle", ".dib", ".pdf"}
            Dim filename As String = System.Guid.NewGuid.ToString & "-" & Path.GetFileName(FileUpload1.FileName)
            Dim extension As String = Path.GetExtension(filename)

            'If extensionlist.Contains(extension) = False Then
            '    Page.ClientScript.RegisterStartupScript(Me.[GetType](), "Alert", "alert('Invalid file extension.Please upload .jpeg or .png or .jpg image');", True)

            '    Exit Sub
            'End If

            If extension <> ".xls" AndAlso extension <> ".xlsx" Then
                Label1.Text = "Invalid file extension.Please upload .xls or .xlsx file"
                'Label1.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim path1 As String = "employee/photos/" & filename
            Dim dir1 As String = Server.MapPath(".") & "\employee\files"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If
            Dim path2 As String = Server.MapPath(".") & "\employee\files\" & filename

            FileUpload1.SaveAs(path2)

            'Dim msg1 As New msgbox11

            Dim constr1 As String

            Dim st1 As Integer = Convert.ToInt32(RadTextBox3.Text)
            Dim c1 As Integer = 0
            Dim start1 As Double = Convert.ToDouble(RadTextBox1.Text)
            Dim end1 As Double = Convert.ToDouble(RadTextBox2.Text)
            Dim k As Integer
            Dim subject As String = ""
            Dim l As Double = start1
            ListBox1.Items.Clear()
            ListBox2.Items.Clear()




            constr1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & path2 & ";Extended Properties=""Excel 12.0 Xml;HDR=YES"";"
            Using con1 As New OleDbConnection
                con1.ConnectionString = constr1
                con1.Open()
                Dim cmd1 As New OleDbCommand
                cmd1.Connection = con1
                cmd1.CommandText = "Select * from [Sheet1$]"
                'cmd1.CommandText = "Select * from [TAB$]"
                Dim rdr1 As OleDbDataReader = cmd1.ExecuteReader

                Do While rdr1.Read
                    Literal1.Text = Literal1.Text & "<br>" & rdr1.FieldCount & "<br>"
                    For l = 0 To rdr1.FieldCount - 1
                        Literal1.Text = Literal1.Text & rdr1.GetValue(l).ToString & ","
                    Next

                    If c1 = st1 Then
                        subject = rdr1.GetValue(start1).ToString
                    End If

                    ListBox2.Items.Add(subject)

                    If c1 = st1 + 1 Then
                        Dim j As Double = start1
                        For k = start1 To end1
                            'ht1.Add(k, rdr1.GetValue(j).ToString)
                            ht1.Add(k, rdr1.GetValue(k).ToString)
                            ListBox1.Items.Add(rdr1.GetValue(k).ToString)
                        Next




                    End If

                    If c1 >= st1 + 2 Then
                        SqlDataSource4.InsertParameters("regno").DefaultValue = rdr1.GetValue(2).ToString

                        SqlDataSource4.InsertParameters("name").DefaultValue = rdr1.GetValue(4).ToString
                        SqlDataSource4.InsertParameters("subject").DefaultValue = subject
                        Dim j As Double = 0
                        For k = start1 To end1
                            Dim item1 As String = k.ToString
                            'SqlDataSource4.InsertParameters("component").DefaultValue = ht1.Item(k).ToString
                            SqlDataSource4.InsertParameters("component").DefaultValue = ListBox1.Items(j).ToString

                            'SqlDataSource4.InsertParameters("marks").DefaultValue = Convert.ToDouble(rdr1.GetValue(k).ToString)
                            SqlDataSource4.InsertParameters("value1").DefaultValue = rdr1.GetValue(k).ToString
                            SqlDataSource4.Insert()
                            j = j + 1


                        Next



                    End If


                    c1 = c1 + 1


                Loop
                rdr1.Close()
                con1.Close()
            End Using

            Label1.Text = "Data updated successfully."
            'Label1.ForeColor = Drawing.Color.Green

            'RadGrid1.DataBind()
            ASPxGridView1.DataBind()


        Else
            Label1.Text = "File is either not Selected or is Empty."

            Exit Sub
        End If
    End Sub
    Protected Sub RadButton3_Click(sender As Object, e As EventArgs) Handles RadButton3.Click
        Dim str1 As String
        str1 = "Delete from au_tr_test"
        Dim cs1 As New schoolclass1
        cs1.insertdata(str1)
        ASPxGridView1.DataBind()


    End Sub
    Protected Sub RadButton4_Click(sender As Object, e As EventArgs) Handles RadButton4.Click
        If FileUpload1.HasFile Then
            Dim file As HttpPostedFile = FileUpload1.PostedFile
            Dim filesize As Integer = file.ContentLength

            'Dim extensionlist() As String = {".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".txt", ".rtf", ".bmp", ".jpeg", ".gif", ".tiff", ".png", ".pcx", ".emf", ".rle", ".dib", ".pdf"}
            Dim filename As String = System.Guid.NewGuid.ToString & "-" & Path.GetFileName(FileUpload1.FileName)
            Dim extension As String = Path.GetExtension(filename)


            'If extension <> ".xls" AndAlso extension <> ".xlsx" Then
            '    Label1.Text = "Invalid file extension.Please upload .xls or .xlsx file"
            '    'Label1.ForeColor = Drawing.Color.Red
            '    Exit Sub
            'End If
            Dim path1 As String = "employee/photos/" & filename
            Dim dir1 As String = Server.MapPath(".") & "\employee\files"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If
            Dim path2 As String = Server.MapPath(".") & "\employee\files\" & filename

            FileUpload1.SaveAs(path2)

            'Dim msg1 As New msgbox11

            Dim constr1 As String

            Dim st1 As Integer = Convert.ToInt32(RadTextBox3.Text)
            Dim c1 As Integer = 0
            Dim start1 As Double = Convert.ToDouble(RadTextBox1.Text)
            Dim end1 As Double = Convert.ToDouble(RadTextBox2.Text)
            Dim k As Integer
            Dim subject As String = ""
            Dim l As Double = start1
            ListBox1.Items.Clear()
            ListBox2.Items.Clear()



            Dim reader As StreamReader = My.Computer.FileSystem.OpenTextFileReader(path2)
            Dim a As String
            c1 = 1

            Do
                a = reader.ReadLine
                Try
                    a = a.Replace("\r\n", "").Replace("\n", "").Replace(vbCrLf, "")
                Catch ex As Exception

                End Try
                Literal1.Text = Literal1.Text & "Line " & c1.ToString & "<br>" & a & "<br>"
                Try
                    Dim ar1() As String = a.Split(",")
                    If c1 = 1 Then
                        subject = ar1(start1)
                        ListBox2.Items.Add(subject)
                    End If
                    If c1 = 2 Then
                        For k = start1 To end1
                            ListBox1.Items.Add(ar1(k).ToString)
                        Next
                    End If
                    If c1 >= 4 Then
                        SqlDataSource4.InsertParameters("regno").DefaultValue = ar1(1).ToString
                        SqlDataSource4.InsertParameters("name").DefaultValue = ar1(3).ToString
                        SqlDataSource4.InsertParameters("subject").DefaultValue = subject
                        Dim j As Integer = 0
                        For k = start1 To end1

                            SqlDataSource4.InsertParameters("component").DefaultValue = ListBox1.Items(j).ToString
                            SqlDataSource4.InsertParameters("value1").DefaultValue = ar1(k).ToString
                            SqlDataSource4.Insert()
                            j = j + 1


                        Next


                    End If
                Catch ex As Exception

                End Try

                c1 = c1 + 1



            Loop Until a Is Nothing

            reader.Close()




            Label1.Text = "Data updated successfully."
            'Label1.ForeColor = Drawing.Color.Green

            'RadGrid1.DataBind()
            ASPxGridView1.DataBind()


        Else
            Label1.Text = "File is either not Selected or is Empty."

            Exit Sub
        End If
    End Sub
End Class
