﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class au_attendance_dynamic1
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim courseid, programid, classid As Integer
        Dim batchname, semester As String
        If RadComboBox1.SelectedIndex = -1 Then
        Else
            Try
                classid = Convert.ToInt32(Request.QueryString("classid").ToString)

            Catch ex As Exception
                Response.Redirect("au_class_1.aspx")
            End Try
            Try
                courseid = Convert.ToInt32(RadComboBox1.SelectedValue.ToString)
            Catch ex As Exception
                Exit Sub
            End Try
            Dim constr1 As String
            constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
            Using con1 As New SqlConnection
                con1.ConnectionString = constr1
                con1.Open()
                Dim cmd1 As New SqlCommand
                cmd1.Connection = con1
                cmd1.CommandText = "Select programid,batchname,semester From au_batch1 where courseid=" & courseid & " and admcurrent1='Y'"
                Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
                Do While rdr1.Read
                    Try
                        programid = Convert.ToInt32(rdr1.GetValue(0).ToString)
                        batchname = rdr1.GetValue(1).ToString
                        semester = rdr1.GetValue(2).ToString

                    Catch ex As Exception

                    End Try
                Loop
                rdr1.Close()
                con1.Close()
            End Using
            Dim cooki16 As New HttpCookie("courseid")
            cooki16.Value = courseid.ToString
            cooki16.Expires = DateTime.Now.AddMinutes(30)
            Dim cooki17 As New HttpCookie("programid")
            cooki17.Value = programid.ToString
            cooki17.Expires = DateTime.Now.AddMinutes(30)
            Dim cooki18 As New HttpCookie("batchname")
            cooki18.Value = batchname.ToString
            cooki18.Expires = DateTime.Now.AddMinutes(30)
            Dim cooki19 As New HttpCookie("semester")
            cooki19.Value = semester.ToString
            cooki19.Expires = DateTime.Now.AddMinutes(30)
            Dim cooki20 As New HttpCookie("classid")
            cooki20.Value = classid.ToString
            cooki20.Expires = DateTime.Now.AddMinutes(30)
            Response.Cookies.Add(cooki16)
            Response.Cookies.Add(cooki17)
            Response.Cookies.Add(cooki18)
            Response.Cookies.Add(cooki19)
            Response.Cookies.Add(cooki20)
            Response.Redirect("au_attendance_s2.aspx")

        End If
    End Sub
End Class
