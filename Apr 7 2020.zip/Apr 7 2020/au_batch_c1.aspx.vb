﻿Imports Telerik.Web.UI

Partial Class au_batch_c1
    Inherits System.Web.UI.Page

    Protected Sub RadTreeView1_NodeDrop(sender As Object, e As Telerik.Web.UI.RadTreeNodeDragDropEventArgs) Handles RadTreeView1.NodeDrop
        Dim msg1 As String = String.Empty
        For Each tr As RadTreeNode In e.DraggedNodes
            'Literal1.Text = Literal1.Text & tr.Text & "," & tr.Value & " dragged to" & e.DestDragNode.Text & "," & e.DestDragNode.Value & "<br>"

            Dim str1 As String
            If e.HtmlElementID = Image1.ClientID Then
                str1 = "Update nba_course set pcourseid=NULL where id=" & Convert.ToInt32(tr.Value.ToString)
                msg1 = "Ungroup operation successful."
            Else
                str1 = "Update nba_course set pcourseid=" & Convert.ToInt32(e.DestDragNode.Value.ToString) & " where id=" & Convert.ToInt32(tr.Value.ToString)
                msg1 = "Course grouping completed."
            End If

            Dim cs1 As New schoolclass1
            Try
                cs1.insertdata(str1)
            Catch ex As Exception

            End Try

            Literal1.Text = Literal1.Text & e.HtmlElementID & "<br>"
        Next
        'RadToolTip1.Text = msg1

        RadTreeView1.DataBind()
        RadToolTip1.Show()


    End Sub
End Class
