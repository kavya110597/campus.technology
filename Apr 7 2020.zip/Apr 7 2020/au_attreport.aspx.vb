﻿
Partial Class au_attreport
    Inherits System.Web.UI.Page

End Class
