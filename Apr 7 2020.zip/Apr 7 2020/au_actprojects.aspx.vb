﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Data.OleDb
Imports System.Drawing
Partial Class au_actprojects
    Inherits System.Web.UI.Page
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        LSeminar.Text = ""
        If TBseminarname.Text = "" OrElse TBstartdate1.Text = "" OrElse TBenddate1.Text = "" OrElse TBvenue.Text = "" OrElse TBsponser.Text = "" OrElse TBgrant.Text = "" Then
            LSeminar.Text = "Please enter all details."
            LSeminar.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If IsDate(TBstartdate1.Text) = False OrElse IsDate(TBenddate1.Text) = False Then
            LSeminar.Text = "Invalid Date."
            LSeminar.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        Dim startdate As Date = Convert.ToDateTime(TBstartdate1.Text)
        Dim enddate As Date = Convert.ToDateTime(TBenddate1.Text)
        If Format(startdate, "MM/DD/YYYY") > Format(enddate, "MM/DD/YYYY") Then
            LSeminar.Text = "Invalid Date."
            LSeminar.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        Dim grant1 As Double
        Try
            grant1 = Convert.ToDouble(TBgrant.Text)
        Catch ex As Exception
            LSeminar.Text = "Invalid Grant."
            LSeminar.ForeColor = Drawing.Color.Red
            Exit Sub
        End Try
        Dim facultyid As Integer = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
        If FileUploadsem.HasFile Then
            Dim file As HttpPostedFile = FileUploadsem.PostedFile
            Dim filesize As Integer = file.ContentLength
            If filesize > 1000000 Then
                LSeminar.Text = "File exceeds the maximum size limit i.e. 1MB"
                LSeminar.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim extensionlist() As String = {".doc", ".docx", ".jpeg", ".gif", ".png", ".pdf", ".jpg"}
            Dim filename As String = Path.GetFileName(FileUploadsem.FileName)
            Dim extension As String = Path.GetExtension(filename)

            If extensionlist.Contains(extension) = False Then
                LSeminar.Text = "Invalid file extension.Please upload .doc or .pdf or .jpeg or .png or .jpg or .gif"
                LSeminar.ForeColor = Drawing.Color.Red
                Exit Sub
            End If

            Dim newid As String = Guid.NewGuid().ToString()

            Dim newfilename As String = facultyid & "_" & newid & "_" & filename
            Dim path1 As String = "employee/files/" & newfilename
            Dim dir1 As String = Server.MapPath(".") & "\employee\files"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If
            Dim fileLocation As String = String.Format("{0}\{1}\{2}", Server.MapPath("."), "employee\files", newfilename)

            'Dim path2 As String = Server.MapPath(".") & "\students\photos\" & filename
            FileUploadsem.SaveAs(fileLocation)
            SqlDataSource13.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
            SqlDataSource13.InsertParameters("empid").DefaultValue = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
            SqlDataSource13.InsertParameters("projectname").DefaultValue = TBseminarname.Text
            SqlDataSource13.InsertParameters("startdate").DefaultValue = Convert.ToDateTime(TBstartdate1.Text)
            SqlDataSource13.InsertParameters("enddate").DefaultValue = Convert.ToDateTime(TBenddate1.Text)
            SqlDataSource13.InsertParameters("level1").DefaultValue = DLlevel.SelectedValue.ToString()
            SqlDataSource13.InsertParameters("status").DefaultValue = DLstatus.SelectedValue.ToString()
            SqlDataSource13.InsertParameters("patent").DefaultValue = TBvenue.Text
            SqlDataSource13.InsertParameters("agency").DefaultValue = TBsponser.Text
            SqlDataSource13.InsertParameters("grant1").DefaultValue = grant1
            SqlDataSource13.InsertParameters("type").DefaultValue = DLtype1.SelectedValue.ToString()
            SqlDataSource13.InsertParameters("fundingtype").DefaultValue = DLfund.SelectedValue.ToString()
            SqlDataSource13.InsertParameters("certificate").DefaultValue = path1
            SqlDataSource13.Insert()
            LSeminar.Text = "Project Added."
            LSeminar.ForeColor = Drawing.Color.Green
            GridView2.DataBind()

        Else


            SqlDataSource13.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
            SqlDataSource13.InsertParameters("empid").DefaultValue = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
            SqlDataSource13.InsertParameters("projectname").DefaultValue = TBseminarname.Text
            SqlDataSource13.InsertParameters("startdate").DefaultValue = Convert.ToDateTime(TBstartdate1.Text)
            SqlDataSource13.InsertParameters("enddate").DefaultValue = Convert.ToDateTime(TBenddate1.Text)
            SqlDataSource13.InsertParameters("level1").DefaultValue = DLlevel.SelectedValue.ToString()
            SqlDataSource13.InsertParameters("status").DefaultValue = DLstatus.SelectedValue.ToString()
            SqlDataSource13.InsertParameters("patent").DefaultValue = TBvenue.Text
            SqlDataSource13.InsertParameters("agency").DefaultValue = TBsponser.Text
            SqlDataSource13.InsertParameters("grant1").DefaultValue = grant1
            SqlDataSource13.InsertParameters("type").DefaultValue = DLtype1.SelectedValue.ToString()
            SqlDataSource13.InsertParameters("fundingtype").DefaultValue = DLfund.SelectedValue.ToString()
            SqlDataSource13.Insert()
            LSeminar.Text = "Project Added."
            LSeminar.ForeColor = Drawing.Color.Green
            GridView2.DataBind()
        End If
    End Sub
    Private Sub GridView2_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView2.RowCommand
        Labelsem.Text = ""
        LSeminar.Text = ""
        Dim facultyid As Integer = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)

        If e.CommandName = "save" Then
            Dim rowid As Integer = Convert.ToInt32(e.CommandArgument.ToString)
            Dim lbl1 As Label = CType(GridView2.Rows(rowid).FindControl("Labelid2sem"), Label)
            Dim fileid As Integer = Convert.ToInt32(lbl1.Text.ToString)
            Dim FileUploadsave As FileUpload
            FileUploadsave = CType(GridView2.Rows(rowid).FindControl("FileUploadcertisem"), FileUpload)
            Dim filename As String = ""
            Dim path1 As String = ""

            If FileUploadsave.HasFile Then
                Dim file As HttpPostedFile = FileUploadsave.PostedFile
                Dim filesize As Integer = file.ContentLength
                If filesize > 1000000 Then
                    Labelsem.Text = "File exceeds the maximum size limit i.e. 1MB"
                    Labelsem.ForeColor = Drawing.Color.Red
                    Exit Sub
                End If
                Dim extensionlist() As String = {".doc", ".docx", ".jpeg", ".gif", ".png", ".pdf", ".jpg"}
                filename = Path.GetFileName(FileUploadsave.FileName)
                Dim extension As String = Path.GetExtension(filename)

                If extensionlist.Contains(extension) = False Then
                    Labelsem.Text = "Invalid file extension.Please upload .doc or .pdf or .jpeg or .png or .jpg or .gif"
                    Labelsem.ForeColor = Drawing.Color.Red
                    Exit Sub
                End If
                Dim newid As String = Guid.NewGuid().ToString()

                Dim newfilename As String = facultyid & "_" & newid & "_" & filename
                path1 = "employee/files/" & newfilename
                Dim dir1 As String = Server.MapPath(".") & "\employee\files\"
                If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                    My.Computer.FileSystem.CreateDirectory(dir1)
                End If
                'Dim path2 As String = Server.MapPath(".") & "\students\photos\" & filename
                Dim fileLocation As String = String.Format("{0}\{1}\{2}", Server.MapPath("."), "employee\files", newfilename)

                FileUploadsave.SaveAs(fileLocation)


            End If
            Dim str1 As String
            str1 = "Update activity_project set certificate=@path1 where Id=@id"
            updatedata(str1, path1, fileid)
            Labelsem.Text = "File Uploaded."
            Labelsem.ForeColor = Drawing.Color.Green
            GridView2.DataBind()

        End If
    End Sub
    Protected Sub BSemExcel_Click(sender As Object, e As EventArgs) Handles BSemExcel.Click
        LSeminar.Text = ""
        If FileUpload1.HasFile Then
            Dim file As HttpPostedFile = FileUpload1.PostedFile
            Dim filesize As Integer = file.ContentLength
            If filesize > 4194304 Then
                LSeminar.Text = "File exceeds the maximum size limit i.e. 4MB"
                LSeminar.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim filename As String = Path.GetFileName(FileUpload1.FileName)
            Dim extension As String = Path.GetExtension(filename)

            If extension <> ".xls" AndAlso extension <> ".xlsx" Then
                LSeminar.Text = "Invalid file extension.Please upload .xls or .xlsx file"
                LSeminar.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim path1 As String = "employee/photos/" & filename
            Dim dir1 As String = Server.MapPath(".") & "\employee\files"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If
            Dim path2 As String = Server.MapPath(".") & "\employee\files\" & filename

            FileUpload1.SaveAs(path2)


            Dim constr1 As String

            constr1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & path2 & ";Extended Properties=""Excel 12.0 Xml;HDR=YES"";"
            Using con1 As New OleDbConnection
                con1.ConnectionString = constr1
                con1.Open()
                Dim cmd1 As New OleDbCommand
                cmd1.Connection = con1
                cmd1.CommandText = "Select * from [Sheet1$]"
                Dim rdr1 As OleDbDataReader = cmd1.ExecuteReader

                Do While rdr1.Read


                    Dim startdate As Date
                    Try
                        startdate = Convert.ToDateTime(rdr1.GetValue(1).ToString)

                    Catch ex As Exception
                        LSeminar.Text = "Invalid Start Date."
                        LSeminar.ForeColor = Drawing.Color.Red
                        Exit Sub
                    End Try
                    Dim enddate As Date
                    Try
                        enddate = Convert.ToDateTime(rdr1.GetValue(2).ToString)

                    Catch ex As Exception
                        LSeminar.Text = "Invalid End Date."
                        LSeminar.ForeColor = Drawing.Color.Red
                        Exit Sub
                    End Try
                    If (DateAndTime.Year(startdate)) < 1950 OrElse (DateAndTime.Year(enddate)) > 2020 Then
                        LSeminar.Text = "Invalid Date Range."
                        LSeminar.ForeColor = Drawing.Color.Red
                        Exit Sub
                    End If



                    SqlDataSource13.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
                    SqlDataSource13.InsertParameters("empid").DefaultValue = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
                    SqlDataSource13.InsertParameters("projectname").DefaultValue = rdr1.GetValue(0).ToString
                    SqlDataSource13.InsertParameters("startdate").DefaultValue = startdate
                    SqlDataSource13.InsertParameters("enddate").DefaultValue = enddate
                    SqlDataSource13.InsertParameters("level1").DefaultValue = rdr1.GetValue(3).ToString
                    SqlDataSource13.InsertParameters("patent").DefaultValue = rdr1.GetValue(4).ToString
                    SqlDataSource13.InsertParameters("agency").DefaultValue = rdr1.GetValue(5).ToString
                    SqlDataSource13.InsertParameters("grant1").DefaultValue = rdr1.GetValue(6).ToString
                    SqlDataSource13.InsertParameters("type").DefaultValue = rdr1.GetValue(7).ToString
                    SqlDataSource13.InsertParameters("status").DefaultValue = rdr1.GetValue(8).ToString
                    SqlDataSource13.InsertParameters("fundingtype").DefaultValue = rdr1.GetValue(9).ToString
                    SqlDataSource13.Insert()

                    GridView2.DataBind()


                Loop
                rdr1.Close()
                con1.Close()
            End Using

            LSeminar.Text = "Project(s) Added."
            LSeminar.ForeColor = Drawing.Color.Green
            GridView2.DataBind()
        Else
            LSeminar.Text = "File is either not Selected or is Empty."
            LSeminar.ForeColor = Drawing.Color.Red
            Exit Sub
        End If

    End Sub
    Public Sub updatedata(ByVal str As String, ByVal path1 As String, ByVal rowid As Integer)
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = str

            cmd1.Parameters.AddWithValue("@id", rowid).DbType = DbType.Int32
            cmd1.Parameters.AddWithValue("@path1", path1).DbType = DbType.String
            cmd1.ExecuteNonQuery()
            con1.Close()

        End Using
    End Sub
End Class
