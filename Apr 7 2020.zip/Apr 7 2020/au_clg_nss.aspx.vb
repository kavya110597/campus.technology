﻿
Partial Class au_clg_nss
    Inherits System.Web.UI.Page

End Class
