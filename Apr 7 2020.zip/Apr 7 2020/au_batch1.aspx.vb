﻿
Partial Class faculty_au_batch1
    Inherits System.Web.UI.Page



    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim facstring As String = HiddenField1.Value.ToString.Replace("undefined", "")
        If facstring = "" Then
            Label1.Text = "Please select Courses."
            Label1.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If TextBox1.Text = "" Then
            Label1.Text = "Please enter Batch Name."
            Label1.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If TextBox2.Text = "" Then
            Label1.Text = "Please enter Semester Name."
            Label1.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        Label1.Text = Mid(facstring, 1, facstring.Length - 1)

        Dim ar1() As String = Mid(facstring, 1, facstring.Length - 1).Split("-")


        For i = 0 To ar1.Length - 1


            Dim courseid As Integer = Convert.ToInt32(ar1(i).ToString)
            SqlDataSource5.InsertParameters("Batchname").DefaultValue = Textbox1.text
            SqlDataSource5.InsertParameters("Semester").DefaultValue = Textbox2.text
            SqlDataSource5.InsertParameters("courseid").DefaultValue = courseid
            SqlDataSource5.Insert()


        Next
        Label1.Text = "Batch assigned."
        Label1.ForeColor = Drawing.Color.Green
        ' RadGrid2.DataBind()

    End Sub
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim principalid As String = Request.Cookies("principalid").Value.ToString
        If principalid = -1 Then
            Response.Redirect("au_notauthorised.aspx")
        End If
    End Sub
End Class
