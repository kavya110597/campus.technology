﻿
Partial Class au_dashboard1
    Inherits System.Web.UI.Page

End Class
