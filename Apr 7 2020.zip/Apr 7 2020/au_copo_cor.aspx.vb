﻿
Partial Class au_copo_cor
    Inherits System.Web.UI.Page

End Class
