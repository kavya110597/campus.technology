﻿Imports System.IO
Imports System.Data.OleDb
Imports DevExpress.XtraPrinting
Imports DevExpress.XtraCharts
Imports DevExpress.XtraCharts.Native
Imports DevExpress.XtraPrintingLinks
Imports Telerik.Web.UI
Imports System.Data
Imports System.Data.SqlClient
Partial Class au_approvalfacreport
    Inherits System.Web.UI.Page

    Protected Sub ImageExcel_Click(sender As Object, e As ImageClickEventArgs) Handles ImageExcel.Click


        Dim ps As New PrintingSystemBase()

        Dim link1 As New PrintableComponentLinkBase(ps)
        link1.Component = ASPxGridViewExporter1

        Dim link2 As New PrintableComponentLinkBase(ps)
        link2.Component = ASPxGridViewExporter2

        Dim link3 As New PrintableComponentLinkBase(ps)
        link3.Component = ASPxGridViewExporter3

        Dim link4 As New PrintableComponentLinkBase(ps)
        link4.Component = ASPxGridViewExporter4

        Dim link5 As New PrintableComponentLinkBase(ps)
        link5.Component = ASPxGridViewExporter5

        Dim compositeLink As New CompositeLinkBase(ps)
        compositeLink.Links.AddRange(New Object() {link1, link2, link3, link4, link5})

        compositeLink.CreatePageForEachLink()

        Using stream As New MemoryStream()
            Dim options As New XlsxExportOptions()
            options.ExportMode = XlsxExportMode.SingleFilePageByPage
            compositeLink.PrintingSystemBase.ExportToXlsx(stream, options)
            Response.Clear()
            Response.Buffer = False
            Response.AppendHeader("Content-Type", "application/xlsx")
            Response.AppendHeader("Content-Transfer-Encoding", "binary")
            Response.AppendHeader("Content-Disposition", "attachment; filename=ApprovedActivities.xlsx")
            Response.BinaryWrite(stream.ToArray())
            Response.End()
        End Using
        ps.Dispose()
    End Sub

End Class
