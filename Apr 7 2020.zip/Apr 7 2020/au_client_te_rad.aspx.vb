﻿Imports System.Data
Imports System.Data.SqlClient
Imports Telerik.Web
Imports Telerik.Web.UI

Partial Class au_client_te_rad
    Inherits System.Web.UI.Page

    Protected Sub RadGrid1_ItemCreated(sender As Object, e As Telerik.Web.UI.GridItemEventArgs) Handles RadGrid1.ItemCreated
        Try
            Dim eitem As GridEditableItem = CType(e.Item, GridEditableItem)
            If eitem IsNot Nothing AndAlso e.Item.IsInEditMode Then
                Dim ddl1 As RadComboBox = CType(eitem.FindControl("RadComboBox3"), RadComboBox)
                ddl1.AutoPostBack = True
                AddHandler ddl1.SelectedIndexChanged, AddressOf ddl1_SelectedIndexChanged



            End If
        Catch ex As Exception

        End Try

    End Sub
    Public Sub ddl1_SelectedIndexChanged(ByVal sender As Object, ByVal e As EventArgs)
        Dim ddl2 As RadComboBox = CType(sender, RadComboBox)
        Dim item As GridEditFormItem = CType(ddl2.NamingContainer, GridEditFormItem)
        Dim ddl4 As RadComboBox = CType(item.FindControl("RadComboBox4"), RadComboBox)
        ddl4.Items.Clear()
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "Select id,milestone from au_milestone where clientid=" & ClientID
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                ddl4.Items.Add(New RadComboBoxItem(rdr1.GetValue(1).ToString, Convert.ToInt32(rdr1.GetValue(0).ToString)))
                'ddl4.Items.Add(rdr1.GetValue(1).ToString, Convert.ToInt32(rdr1.GetValue(0).ToString))
            Loop
            rdr1.Close()
            con1.Close()
        End Using
    End Sub

End Class
