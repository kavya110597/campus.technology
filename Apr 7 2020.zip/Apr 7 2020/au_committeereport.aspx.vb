﻿Imports DevExpress.Web.ASPxGridView
Imports DevExpress.Web
Imports System.Data
Imports System.Data.SqlClient
Imports DevExpress.XtraGrid.Views.Base
Imports System.Globalization
Imports DevExpress.XtraPrinting
Partial Class au_committeereport
    Inherits System.Web.UI.Page
    Protected Sub ASPxGridView2_BeforePerformDataSelect(sender As Object, e As EventArgs)
        Dim dxgv1 As ASPxGridView = CType(sender, ASPxGridView)
        Dim lid As Integer = Convert.ToInt32(dxgv1.GetMasterRowKeyValue)

        Session("committeeid") = lid
    End Sub
    Protected Sub ImageWord_Click(sender As Object, e As ImageClickEventArgs) Handles ImageWord.Click

        ASPxGridViewExporter1.GridViewID = "ASPxGridView1"

        ASPxGridViewExporter1.WriteRtfToResponse()

    End Sub
    Protected Sub ImageExcel_Click(sender As Object, e As ImageClickEventArgs) Handles ImageExcel.Click

        ASPxGridViewExporter1.GridViewID = "ASPxGridView1"

        ASPxGridViewExporter1.WriteXlsxToResponse(New XlsxExportOptionsEx With {.ExportType = DevExpress.Export.ExportType.WYSIWYG})
    End Sub
    Protected Sub ImagePDF_Click(sender As Object, e As ImageClickEventArgs) Handles ImagePDF.Click

        ASPxGridViewExporter1.GridViewID = "ASPxGridView1"

        Dim options As New DevExpress.XtraPrinting.PdfExportOptions

        options.Compressed = False
        ASPxGridViewExporter1.WritePdfToResponse(options)

    End Sub
End Class
