﻿
Partial Class au_batch_view
    Inherits System.Web.UI.Page

End Class
