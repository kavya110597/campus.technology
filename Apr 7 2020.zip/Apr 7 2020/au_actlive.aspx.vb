﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Data.OleDb
Imports System.Drawing
Partial Class au_actlive
    Inherits System.Web.UI.Page
    Protected Sub Button9_Click(sender As Object, e As EventArgs) Handles Button9.Click
        LLive.Text = ""
        Labellive.Text = ""
        If TextBox12.Text = "" OrElse TextBox13.Text = "" OrElse TBstartdate6.Text = "" Then
            LLive.Text = "Please enter all details."
            LLive.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If IsDate(TBstartdate6.Text) = False Then
            LLive.Text = "Invalid Date."
            LLive.ForeColor = Drawing.Color.Red
            Exit Sub
        End If

        If FileUploadlive.HasFile Then
            Dim file As HttpPostedFile = FileUploadlive.PostedFile
            Dim filesize As Integer = file.ContentLength
            If filesize > 1000000 Then
                LLive.Text = "File exceeds the maximum size limit i.e. 1MB"
                LLive.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim extensionlist() As String = {".doc", ".docx", ".jpeg", ".gif", ".png", ".pdf", ".jpg"}
            Dim filename As String = Path.GetFileName(FileUploadlive.FileName)
            Dim extension As String = Path.GetExtension(filename)

            If extensionlist.Contains(extension) = False Then
                LLive.Text = "Invalid file extension.Please upload .doc or .pdf or .jpeg or .png or .jpg or .gif"
                LLive.ForeColor = Drawing.Color.Red
                Exit Sub
            End If


            Dim path1 As String = "students/photos/" & filename
            Dim dir1 As String = Server.MapPath(".") & "\students\photos"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If
            Dim path2 As String = Server.MapPath(".") & "\students\photos\" & filename
            FileUploadlive.SaveAs(path2)
            SqlDataSource6.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
            SqlDataSource6.InsertParameters("empid").DefaultValue = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)

            SqlDataSource6.InsertParameters("methodname").DefaultValue = TextBox12.Text
            SqlDataSource6.InsertParameters("po").DefaultValue = TextBox13.Text
            SqlDataSource6.InsertParameters("startdate").DefaultValue = Convert.ToDateTime(TBstartdate6.Text)
            SqlDataSource6.InsertParameters("type").DefaultValue = DropDownList13.SelectedValue.ToString()
            SqlDataSource6.InsertParameters("deliverymethod").DefaultValue = DropDownList14.SelectedValue.ToString()
            SqlDataSource6.InsertParameters("certificate").DefaultValue = path1
            SqlDataSource6.Insert()
            LLive.Text = "Live Project Details Added."
            LLive.ForeColor = Drawing.Color.Green
            GridView7.DataBind()

        Else
            SqlDataSource6.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
            SqlDataSource6.InsertParameters("empid").DefaultValue = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)

            SqlDataSource6.InsertParameters("methodname").DefaultValue = TextBox12.Text
            SqlDataSource6.InsertParameters("po").DefaultValue = TextBox13.Text
            SqlDataSource6.InsertParameters("startdate").DefaultValue = Convert.ToDateTime(TBstartdate6.Text)
            SqlDataSource6.InsertParameters("type").DefaultValue = DropDownList13.SelectedValue.ToString()
            SqlDataSource6.InsertParameters("deliverymethod").DefaultValue = DropDownList14.SelectedValue.ToString()
            SqlDataSource6.Insert()
            LLive.Text = "Live Project Details Added."
            LLive.ForeColor = Drawing.Color.Green
            GridView7.DataBind()
        End If
    End Sub
    Private Sub GridView7_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView7.RowCommand
        Labellive.Text = ""
        If e.CommandName = "save" Then
            Dim rowid As Integer = Convert.ToInt32(e.CommandArgument.ToString)
            Dim lbl1 As Label = CType(GridView7.Rows(rowid).FindControl("Labelid2live"), Label)
            Dim fileid As Integer = Convert.ToInt32(lbl1.Text.ToString)
            Dim FileUploadsave As FileUpload
            FileUploadsave = CType(GridView7.Rows(rowid).FindControl("FileUploadcertilive"), FileUpload)
            Dim filename As String = ""
            Dim path1 As String = ""

            If FileUploadsave.HasFile Then
                Dim file As HttpPostedFile = FileUploadsave.PostedFile
                Dim filesize As Integer = file.ContentLength
                If filesize > 1000000 Then
                    Labellive.Text = "File exceeds the maximum size limit i.e. 1MB"
                    Labellive.ForeColor = Drawing.Color.Red
                    Exit Sub
                End If
                Dim extensionlist() As String = {".doc", ".docx", ".jpeg", ".gif", ".png", ".pdf", ".jpg"}
                filename = Path.GetFileName(FileUploadsave.FileName)
                Dim extension As String = Path.GetExtension(filename)

                If extensionlist.Contains(extension) = False Then
                    Labellive.Text = "Invalid file extension.Please upload .doc or .pdf or .jpeg or .png or .jpg or .gif"
                    Labellive.ForeColor = Drawing.Color.Red
                    Exit Sub
                End If
                path1 = "students/photos/" & filename
                Dim dir1 As String = Server.MapPath(".") & "\students\photos\"
                If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                    My.Computer.FileSystem.CreateDirectory(dir1)
                End If
                Dim path2 As String = Server.MapPath(".") & "\students\photos\" & filename

                FileUploadsave.SaveAs(path2)


            End If
            Dim str1 As String
            str1 = "Update activity_live set certificate=@path1 where Id=@id"
            updatedata(str1, path1, fileid)
            Labellive.Text = "File Uploaded."
            Labellive.ForeColor = Drawing.Color.Green
            GridView7.DataBind()

        End If
    End Sub
    Protected Sub BLiveExcel_Click(sender As Object, e As EventArgs) Handles BLiveExcel.Click
        LLive.Text = ""
        Labellive.Text = ""
        If FileUpload7.HasFile Then
            Dim file As HttpPostedFile = FileUpload7.PostedFile
            Dim filesize As Integer = file.ContentLength
            If filesize > 4194304 Then
                LLive.Text = "File exceeds the maximum size limit i.e. 4MB"
                LLive.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim filename As String = Path.GetFileName(FileUpload7.FileName)
            Dim extension As String = Path.GetExtension(filename)



            If extension <> ".xls" AndAlso extension <> ".xlsx" Then
                LLive.Text = "Invalid file extension.Please upload .xls or .xlsx file"
                LLive.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim path1 As String = "employee/photos/" & filename
            Dim dir1 As String = Server.MapPath(".") & "\employee\files"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If
            Dim path2 As String = Server.MapPath(".") & "\employee\files\" & filename

            FileUpload7.SaveAs(path2)



            Dim constr1 As String

            constr1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & path2 & ";Extended Properties=""Excel 12.0 Xml;HDR=YES"";"
            Using con1 As New OleDbConnection
                con1.ConnectionString = constr1
                con1.Open()
                Dim cmd1 As New OleDbCommand
                cmd1.Connection = con1
                cmd1.CommandText = "Select * from [Sheet1$]"
                Dim rdr1 As OleDbDataReader = cmd1.ExecuteReader

                Do While rdr1.Read


                    Dim startdate As Date
                    Try
                        startdate = Convert.ToDateTime(rdr1.GetValue(1).ToString)

                    Catch ex As Exception
                        LLive.Text = "Invalid Date."
                        LLive.ForeColor = Drawing.Color.Red
                        Exit Sub
                    End Try
                    SqlDataSource6.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
                    SqlDataSource6.InsertParameters("empid").DefaultValue = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)

                    SqlDataSource6.InsertParameters("methodname").DefaultValue = rdr1.GetValue(0).ToString
                    SqlDataSource6.InsertParameters("po").DefaultValue = rdr1.GetValue(2).ToString
                    SqlDataSource6.InsertParameters("startdate").DefaultValue = startdate
                    SqlDataSource6.InsertParameters("type").DefaultValue = rdr1.GetValue(3).ToString
                    SqlDataSource6.Insert()


                    GridView7.DataBind()



                Loop
                rdr1.Close()
                con1.Close()
            End Using

            LLive.Text = "Live Project Details Added."
            LLive.ForeColor = Drawing.Color.Green
            GridView7.DataBind()
        Else
            LLive.Text = "File is either not Selected or is Empty."
            LLive.ForeColor = Drawing.Color.Red
            Exit Sub
        End If

    End Sub
    Public Sub updatedata(ByVal str As String, ByVal path1 As String, ByVal rowid As Integer)
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = str

            cmd1.Parameters.AddWithValue("@id", rowid).DbType = DbType.Int32
            cmd1.Parameters.AddWithValue("@path1", path1).DbType = DbType.String
            cmd1.ExecuteNonQuery()
            con1.Close()

        End Using
    End Sub

End Class
