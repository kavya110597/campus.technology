﻿Imports System.IO
Imports System.Data.OleDb
Imports DevExpress.XtraPrinting
Imports Telerik.Web.UI
Imports System.Data
Imports System.Data.SqlClient
Imports System.Drawing.Color
Imports DevExpress.Web
Partial Class au_add_nonteachingstaff
    Inherits System.Web.UI.Page

    Protected Sub Button2t_Click(sender As Object, e As EventArgs) Handles Button2t.Click
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        If NameofDesignator.Text = "" OrElse Qualification.Text = "" OrElse Designation.Text = "" OrElse DOB.Text = "" Then
            Label2.Text = "Please Enter all details"
            Label2.ForeColor = System.Drawing.Color.Red
            Exit Sub
        End If
        If IsDate(DOB.Text) = False Then
            Label2.Text = "Invalid Date"
            Label2.ForeColor = System.Drawing.Color.Red
            Exit Sub
        End If
        Dim D As Date
        Try
            D = Convert.ToDateTime(DOB.Text)
        Catch ex As Exception
            Label2.Text = "Invalid Date"
            Label2.ForeColor = System.Drawing.Color.Red
            Exit Sub
        End Try

        SqlDataSource9.InsertParameters("colid").DefaultValue = colid
        SqlDataSource9.InsertParameters("Name").DefaultValue = NameofDesignator.Text
        SqlDataSource9.InsertParameters("EducationalQualifications").DefaultValue = Qualification.Text
        SqlDataSource9.InsertParameters("Gender").DefaultValue = Gender.SelectedValue.ToString
        SqlDataSource9.InsertParameters("Category").DefaultValue = Category.SelectedValue.ToString
        SqlDataSource9.InsertParameters("Designation").DefaultValue = Designation.Text
        SqlDataSource9.InsertParameters("DOB").DefaultValue = D
        SqlDataSource9.Insert()




        ASPxGridView1.DataBind()

        Label2.Text = "Staff is added."
        Label2.ForeColor = System.Drawing.Color.Green
    End Sub

    Protected Sub BFacExcel_Click(sender As Object, e As EventArgs) Handles BFacExcel.Click
        Label2.Text = ""
        Label3.Text = ""

        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try

        If FileUpload1.HasFile Then
            Dim file As HttpPostedFile = FileUpload1.PostedFile
            Dim filesize As Integer = file.ContentLength
            If filesize > 4194304 Then
                Label2.Text = "File exceeds the maximum size limit i.e. 4MB"
                Label2.ForeColor = Red
                Exit Sub
            End If
            Dim filename As String = Path.GetFileName(FileUpload1.FileName)
            Dim extension As String = Path.GetExtension(filename)

            If extension <> ".xls" AndAlso extension <> ".xlsx" Then
                Label2.Text = "Invalid file extension.Please upload .xls or .xlsx file"
                Label2.ForeColor = Red
                Exit Sub
            End If
            Dim path1 As String = "employee/photos/" & filename
            Dim dir1 As String = Server.MapPath(".") & "\employee\files"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If
            Dim path2 As String = Server.MapPath(".") & "\employee\files\" & filename

            FileUpload1.SaveAs(path2)


            Dim constr1 As String

            constr1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & path2 & ";Extended Properties=""Excel 12.0 Xml;HDR=YES"";"
            Using con1 As New OleDbConnection
                con1.ConnectionString = constr1
                con1.Open()
                Dim cmd1 As New OleDbCommand
                cmd1.Connection = con1
                cmd1.CommandText = "Select * from [Sheet1$]"
                Dim rdr1 As OleDbDataReader = cmd1.ExecuteReader

                Do While rdr1.Read


                    Dim dob1 As Date
                    Try
                        dob1 = Convert.ToDateTime(rdr1.GetValue(2).ToString)

                    Catch ex As Exception
                        Label2.Text = "Invalid Date."
                        Label2.ForeColor = Red
                        Exit Sub
                    End Try


                    SqlDataSource9.InsertParameters("colid").DefaultValue = colid
                    SqlDataSource9.InsertParameters("NameOfDesignator").DefaultValue = rdr1.GetValue(0).ToString
                    SqlDataSource9.InsertParameters("EducationalQualifications").DefaultValue = rdr1.GetValue(5).ToString
                    SqlDataSource9.InsertParameters("Gender").DefaultValue = rdr1.GetValue(3).ToString
                    SqlDataSource9.InsertParameters("Category").DefaultValue = rdr1.GetValue(4).ToString
                    SqlDataSource9.InsertParameters("Designation").DefaultValue = rdr1.GetValue(1).ToString
                    SqlDataSource9.InsertParameters("DOB").DefaultValue = dob1
                    SqlDataSource9.Insert()



                    ASPxGridView1.DataBind()


                Loop
                rdr1.Close()
                con1.Close()
            End Using

            Label2.Text = "Staff Added."
            Label2.ForeColor = Green
            ASPxGridView1.DataBind()
        Else
            Label2.Text = "File is either not Selected or is Empty."
            Label2.ForeColor = Red
            Exit Sub
        End If

    End Sub





    Protected Sub ImageWord_Click(sender As Object, e As ImageClickEventArgs) Handles ImageWord.Click

        ASPxGridViewExporter1.GridViewID = "ASPxGridView1"

        ASPxGridViewExporter1.WriteRtfToResponse()

    End Sub
    Protected Sub ImageExcel_Click(sender As Object, e As ImageClickEventArgs) Handles ImageExcel.Click

        ASPxGridViewExporter1.GridViewID = "ASPxGridView1"

        ASPxGridViewExporter1.WriteXlsxToResponse(New XlsxExportOptionsEx With {.ExportType = DevExpress.Export.ExportType.WYSIWYG})
    End Sub
    Protected Sub ImagePDF_Click(sender As Object, e As ImageClickEventArgs) Handles ImagePDF.Click

        ASPxGridViewExporter1.GridViewID = "ASPxGridView1"

        Dim options As New DevExpress.XtraPrinting.PdfExportOptions

        options.Compressed = False
        ASPxGridViewExporter1.WritePdfToResponse(options)

    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim colid As Integer
        Dim cookie1 As HttpCookie = Request.Cookies("colid")
        If cookie1 Is Nothing Then
            Response.Redirect("facultylogin.aspx")
        Else
            colid = Convert.ToInt32(cookie1.Value.ToString)
        End If

        Dim fieldValues As List(Of Object) = ASPxGridView1.GetSelectedFieldValues(New String() {"Id"})

        If fieldValues.Count = 0 Then
            Label4.Text = "Please select atleast one data"
            Label4.ForeColor = Red
            Exit Sub
            Return
        Else
            For Each item As Object In fieldValues
                Dim str1 As String
                str1 = "Delete from nonteachingstaff where colid=" & colid & "and Id=" & item
                Dim cs1 As New schoolclass1
                cs1.insertdata(str1)

            Next
            ASPxGridView1.DataBind()
            Label4.Text = "Deleted Successfully."
            Label4.ForeColor = Green
        End If

    End Sub
End Class

