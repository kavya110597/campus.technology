﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class au_admform_pre
    Inherits System.Web.UI.Page

    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Literal1.Text = ""
        If DropDownList1.SelectedIndex = -1 OrElse TextBox1.Text = "" Then
            Literal1.Text = "Please select Previous Stream and enter percentage marks."
            Exit Sub
        End If
        Dim previd As Integer = Convert.ToInt32(DropDownList1.SelectedValue.ToString)
        Dim marks As Double = Convert.ToDouble(TextBox1.Text)
        Dim str1 As String
        Dim colid As Integer
        Dim utm_source As String

        Try
            colid = Convert.ToInt32(Request.QueryString("colid").ToString)
        Catch ex As Exception
            Literal1.Text = "Invalid page."
            Exit Sub
        End Try
        Try
            utm_source = Request.QueryString("utm_source").ToString
        Catch ex As Exception
            Literal1.Text = "Invalid page."
            Exit Sub
        End Try
        str1 = "Select ProgramID from au_adm_prev_prog where PrevStreamID=" & previd & " and colid=" & colid & " and MinMarks<" & marks
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Dim i As Integer = 0
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = str1
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                i = i + 1
            Loop
            rdr1.Close()
            con1.Close()
        End Using
        If i = 0 Then

            Literal1.Text = "No admission option is available for you. Please check with the admission team."
            Exit Sub

        End If
        Dim cooki1 As New HttpCookie("colid")
        cooki1.Value = colid.ToString
        cooki1.Expires = DateTime.Now.AddMinutes(180)

        Dim cooki2 As New HttpCookie("previd")
        cooki2.Value = previd.ToString
        cooki2.Expires = DateTime.Now.AddMinutes(180)
        Dim cooki3 As New HttpCookie("marks")
        cooki3.Value = marks.ToString
        cooki3.Expires = DateTime.Now.AddMinutes(180)

        Response.Cookies.Add(cooki1)
        Response.Cookies.Add(cooki2)
        Response.Cookies.Add(cooki3)

        Response.Redirect("au_admform_2.aspx?colid=" & colid & "&utm_source=" & utm_source)
    End Sub
End Class
