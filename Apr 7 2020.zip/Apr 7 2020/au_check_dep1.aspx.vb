﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class au_check_dep1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim depname As String
        Try
            depname = Request.QueryString("depname").ToString.Replace("%20", " ")

        Catch ex As Exception
            Response.Redirect("au_dashboard_t1.aspx")
        End Try
        Dim progid As Integer = checkprogid(depname)
        Response.Redirect("au_faculty_all_depwise.aspx?depid=" & progid)
    End Sub
    Public Function checkprogid(ByVal progname As String) As Integer
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Dim colid As Integer
        Dim progid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Values.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "Select id from depall1 where colid=" & colid & " and depname='" & progname & "'"
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                progid = Convert.ToInt32(rdr1.GetValue(0).ToString)
            Loop

            rdr1.Close()
            con1.Close()
        End Using
        Return progid

    End Function
End Class
