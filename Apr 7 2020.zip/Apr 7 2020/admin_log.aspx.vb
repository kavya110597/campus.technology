﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class admin_log
    Inherits System.Web.UI.Page
    Protected Sub login_Click(sender As Object, e As EventArgs) Handles login.Click

        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Dim colid As Integer
        colid = -1
        Dim nuserid As Integer = -1
        Dim nemployeeid As Integer = -1
        Dim name1 As String = ""
        Dim upic As String = ""
        Dim logo As String = ""
        Dim toptext As String = ""
        Dim principalid As Integer = -1

        Using con1 As New SqlConnection
            con1.ConnectionString = ConfigurationManager.ConnectionStrings("constr1").ConnectionString 'constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "Select id,colid,employeeid,Name,upic,principalid from tableusers where login1=@login1 and Password=@password"
            cmd1.Parameters.AddWithValue("@login1", login_text.Text).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@password", pw_text.Text).DbType = DbType.String
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                colid = Convert.ToInt32(rdr1.GetValue(1).ToString)
                nuserid = Convert.ToInt32(rdr1.GetValue(0).ToString)
                Try
                    nemployeeid = Convert.ToInt32(rdr1.GetValue(2).ToString)
                Catch ex As Exception

                End Try
                name1 = rdr1.GetValue(3).ToString
                Try
                    upic = rdr1.GetValue(4).ToString
                Catch ex As Exception

                End Try
                Try
                    principalid = rdr1.GetValue(5).ToString
                Catch ex As Exception

                End Try

            Loop
            rdr1.Close()
            con1.Close()
        End Using
        If principalid <> -1 Then
            Label1.Text = "Invalid username and password."
            Exit Sub
        End If
        If colid = -1 Then
            Label1.Text = "Invalid username and password."
            Exit Sub
        Else
            Dim pagename As String = "all"
            Dim roleid As Integer = -1
            Using con1 As New SqlConnection
                con1.ConnectionString = ConfigurationManager.ConnectionStrings("constr1").ConnectionString 'constr1
                con1.Open()
                Dim cmd1 As New SqlCommand
                cmd1.Connection = con1
                cmd1.CommandText = "Select page1 from tablepage where userid=" & nuserid
                cmd1.CommandText = "SELECT DISTINCT tablecrolesp.page FROM tablecrolesp INNER JOIN tablecrolesu ON tablecrolesp.roleid = tablecrolesu.roleid WHERE (tablecrolesu.userid = " & nuserid & ")"
                cmd1.CommandText = "SELECT DISTINCT tablecrolesp.page,tablecrolesu.roleid FROM tablecrolesp INNER JOIN tablecrolesu ON tablecrolesp.roleid = tablecrolesu.roleid WHERE (tablecrolesu.userid = " & nuserid & ")"
                Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
                Do While rdr1.Read
                    pagename = pagename & "," & rdr1.GetValue(0).ToString
                    roleid = Convert.ToInt32(rdr1.GetValue(1).ToString)
                Loop
                rdr1.Close()
                con1.Close()
            End Using
            Dim collegename As String
            Using con1 As New SqlConnection
                con1.ConnectionString = ConfigurationManager.ConnectionStrings("constr1").ConnectionString 'constr1
                con1.Open()
                Dim cmd1 As New SqlCommand
                cmd1.Connection = con1
                cmd1.CommandText = "Select NameOfCollege, logo, toptext from collegedetails where id=" & colid
                Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
                Do While rdr1.Read
                    collegename = rdr1.GetValue(0).ToString
                    Try
                        logo = rdr1.GetValue(1).ToString

                    Catch ex As Exception

                    End Try
                    Try
                        toptext = rdr1.GetValue(2).ToString

                    Catch ex As Exception

                    End Try
                Loop
                rdr1.Close()
                con1.Close()
            End Using
            Dim designation As String = String.Empty
            Using con1 As New SqlConnection
                con1.ConnectionString = ConfigurationManager.ConnectionStrings("constr1").ConnectionString 'constr1
                con1.Open()
                Dim cmd1 As New SqlCommand
                cmd1.Connection = con1
                cmd1.CommandText = "Select designation from designation where id=" & nemployeeid
                Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
                Do While rdr1.Read
                    designation = rdr1.GetValue(0).ToString


                Loop
                rdr1.Close()
                con1.Close()
            End Using
            'Session("colid") = colid.ToString
            Dim cooki1 As New HttpCookie("colid")
            cooki1.Value = colid.ToString
            cooki1.Expires = DateTime.Now.AddMinutes(180)
            Dim cooki2 As New HttpCookie("nuserid")
            cooki2.Value = nuserid.ToString
            cooki2.Expires = DateTime.Now.AddMinutes(180)
            Dim cooki3 As New HttpCookie("collegename")
            cooki3.Value = collegename.ToString
            cooki3.Expires = DateTime.Now.AddMinutes(180)
            Dim cooki4 As New HttpCookie("pagename")
            cooki4.Value = pagename.ToString
            cooki4.Expires = DateTime.Now.AddMinutes(180)
            Dim cooki5 As New HttpCookie("nemployeeid")
            cooki5.Value = nemployeeid.ToString
            cooki5.Expires = DateTime.Now.AddMinutes(180)
            Dim cooki6 As New HttpCookie("roleid")
            cooki6.Value = roleid.ToString
            cooki6.Expires = DateTime.Now.AddMinutes(180)
            Dim cooki8 As New HttpCookie("empname")
            cooki8.Value = name1.ToString
            cooki8.Expires = DateTime.Now.AddMinutes(180)
            Dim cooki9 As New HttpCookie("logo")
            cooki9.Value = logo.ToString
            cooki9.Expires = DateTime.Now.AddMinutes(180)
            Dim cooki10 As New HttpCookie("toptext")
            cooki10.Value = toptext.ToString
            cooki10.Expires = DateTime.Now.AddMinutes(180)
            Dim cooki11 As New HttpCookie("upic")
            cooki11.Value = upic.ToString
            cooki11.Expires = DateTime.Now.AddMinutes(180)
            Dim cooki12 As New HttpCookie("designation")
            cooki12.Value = designation.ToString
            cooki12.Expires = DateTime.Now.AddMinutes(180)

            Response.Cookies.Add(cooki1)
            Response.Cookies.Add(cooki2)
            Response.Cookies.Add(cooki3)
            Response.Cookies.Add(cooki4)
            Response.Cookies.Add(cooki5)
            Response.Cookies.Add(cooki6)
            Response.Cookies.Add(cooki8)
            Response.Cookies.Add(cooki9)
            Response.Cookies.Add(cooki10)
            Response.Cookies.Add(cooki11)
            Response.Cookies.Add(cooki12)
            If roleid = -1 Then
                'Response.Redirect("section1home.aspx")
                Response.Redirect("adminlogin_student.aspx")
            Else
                Dim groupname As String = ""

                Using con1 As New SqlConnection
                    con1.ConnectionString = ConfigurationManager.ConnectionStrings("constr1").ConnectionString 'constr1
                    con1.Open()
                    Dim cmd1 As New SqlCommand
                    cmd1.Connection = con1
                    cmd1.CommandText = "Select distinct group1 from tablecrolesp where roleid=" & roleid
                    Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
                    Do While rdr1.Read
                        groupname = groupname & rdr1.GetValue(0).ToString & ","

                    Loop
                    rdr1.Close()
                    con1.Close()
                End Using
                Dim cooki7 As New HttpCookie("groupname")
                cooki7.Value = groupname.ToString
                cooki7.Expires = DateTime.Now.AddMinutes(180)
                Response.Cookies.Add(cooki7)
                'Response.Redirect("sectionmymenu.aspx")
                Response.Redirect("adminlogin_student.aspx")
            End If
            'Response.Redirect("section1home.aspx")
        End If
    End Sub

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Dim cooki1 As New HttpCookie("colid")
            cooki1.Value = ""
            cooki1.Expires = DateTime.Now.AddMinutes(-300)
            Dim cooki2 As New HttpCookie("nuserid")
            cooki2.Value = ""
            cooki2.Expires = DateTime.Now.AddMinutes(-300)
            Dim cooki3 As New HttpCookie("collegename")
            cooki3.Value = ""
            cooki3.Expires = DateTime.Now.AddMinutes(-300)
            Dim cooki4 As New HttpCookie("pagename")
            cooki4.Value = ""
            cooki4.Expires = DateTime.Now.AddMinutes(-300)
            Response.Cookies.Add(cooki1)
            Response.Cookies.Add(cooki2)
            Response.Cookies.Add(cooki3)
            Response.Cookies.Add(cooki4)

        End If

    End Sub
End Class
