﻿
Partial Class au_alloc_sem_change
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        If DropDownList1.SelectedIndex = -1 OrElse DropDownList2.SelectedIndex = -1 Then
            Literal1.Text = "Please select old and new semester"
            Exit Sub
        End If
        Dim str1 As String
        str1 = "Update au_assign_fac set semester=@payee where colid=" & colid & " and semester=@category"
        Dim cs1 As New schoolclass1
        cs1.insertdata(str1, DropDownList2.SelectedValue.ToString, DropDownList1.SelectedValue.ToString)
        Literal1.Text = "Data updated."
        DropDownList1.DataBind()

    End Sub
End Class
