﻿
Partial Class au_activity_con
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim colid As String
        Dim collegename As String
        Dim facultyid As String
        Try
            colid = Request.Cookies("colid").Value.ToString
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        collegename = Request.Cookies("collegename").Value.ToString.Replace(" ", "")
        facultyid = Request.Cookies("nemployeeid").Value.ToString
        Dim type As String

        type = "Consultancy"
        HyperLink1.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
        HyperLink2.NavigateUrl = "http://iqac.online/fileviewme1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
        'HyperLink2.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

    End Sub
End Class
