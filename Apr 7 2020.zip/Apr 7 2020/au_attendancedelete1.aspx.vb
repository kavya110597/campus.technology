﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class au_attendancedelete1
    Inherits System.Web.UI.Page
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        Dim classid, facid As Integer
        Try
            classid = Convert.ToInt32(class_rcb.SelectedValue.ToString)
            facid = Convert.ToInt32(fac_rcb.SelectedValue.ToString)
        Catch ex As Exception
            Label8.Text = "Select Class"
            Label8.ForeColor = System.Drawing.Color.Red
            Exit Sub
        End Try


        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString

        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            Dim cmd2 As New SqlCommand
            cmd1.Connection = con1
            cmd2.Connection = con1

            cmd1.CommandText = "Delete from nba_attendance where colid=@colid AND classid=@classid AND facultyid=@facultyid"
            cmd1.Parameters.AddWithValue("@colid", colid).DbType = DbType.Int32
            cmd1.Parameters.AddWithValue("@classid", classid).DbType = DbType.Int32
            cmd1.Parameters.AddWithValue("@facultyid", facid).DbType = DbType.Int32

            cmd2.CommandText = "Delete from au_periods where colid=@colid AND Id=@classid AND facultyid=@facultyid"
            cmd2.Parameters.AddWithValue("@colid", colid).DbType = DbType.Int32
            cmd2.Parameters.AddWithValue("@classid", classid).DbType = DbType.Int32
            cmd2.Parameters.AddWithValue("@facultyid", facid).DbType = DbType.Int32

            cmd1.ExecuteNonQuery()
            cmd2.ExecuteNonQuery()
            con1.Close()
        End Using

        ASPxGridView1.DataBind()
        class_rcb.ClearSelection()
        class_rcb.DataBind()
        Label8.Text = "Class and Attendance Deleted Successfully"
        Label8.ForeColor = System.Drawing.Color.Green
    End Sub
End Class
