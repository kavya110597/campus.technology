﻿Imports System.Data.SqlClient
Imports System.Data
Imports DevExpress.XtraPrinting
Imports DevExpress.XtraGrid.Views.Base
Imports DevExpress.XtraGrid.Views.Grid
Imports DevExpress.XtraGrid.Columns
Imports DevExpress.Web
Partial Class au_clientdetails_view
    Inherits System.Web.UI.Page

    Protected Sub ASPxGridView1_CustomUnboundColumnData(ByVal sender As Object, ByVal e As ASPxGridViewColumnDataEventArgs) Handles ASPxGridView1.CustomUnboundColumnData
        If e.Column.FieldName = "LowerBound" AndAlso e.IsGetData Then
            e.Value = GetExpenses(ASPxGridView1.GetRowValues(e.ListSourceRowIndex, "Id"))
        ElseIf e.Column.FieldName = "LowerBound1" AndAlso e.IsGetData Then
            e.Value = GetPayment(ASPxGridView1.GetRowValues(e.ListSourceRowIndex, "Id"))
        ElseIf e.Column.FieldName = "LowerBound2" AndAlso e.IsGetData Then
            e.Value = GetActivities(ASPxGridView1.GetRowValues(e.ListSourceRowIndex, "Id"))
        End If
    End Sub
    Protected Sub ImageExcel_Click(sender As Object, e As ImageClickEventArgs) Handles ImageExcel.Click

        ASPxGridViewExporter1.GridViewID = "ASPxGridView1"

        ASPxGridViewExporter1.WriteXlsxToResponse(New XlsxExportOptionsEx With {.ExportType = DevExpress.Export.ExportType.WYSIWYG})
    End Sub
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub
    Public Function GetExpenses(ByVal id As Integer) As String
        Dim expenses As String = ""
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "select clientid,sum(expenses) from au_client_te where clientid=" & id & " group by clientid"
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                expenses = rdr1.GetValue(1).ToString
            Loop
            rdr1.Close()
            con1.Close()
        End Using
        Return expenses
    End Function
    Public Function GetPayment(ByVal id As Integer) As String
        Dim expenses As String = ""
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "select clientid, sum(PaymentReceived) from au_milestone where clientid=" & id & " group by clientid"
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                expenses = rdr1.GetValue(1).ToString
            Loop
            rdr1.Close()
            con1.Close()
        End Using
        Return expenses

    End Function

    Public Function GetActivities(ByVal id As Integer) As String
        Dim expenses As String = ""
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "SELECT description + ', ' AS 'data()' " &
"FROM  " &
"(Select convert(varchar(11),dateofwork,106) + ' ' + description as description from au_client_te  " &
"where clientid=" & id & ") as a " &
"FOR XML PATH('')"
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                expenses = rdr1.GetValue(0).ToString
            Loop
            rdr1.Close()
            con1.Close()
        End Using
        Return expenses
    End Function
End Class
