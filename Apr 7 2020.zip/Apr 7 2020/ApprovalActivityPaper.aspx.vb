﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration
Partial Class ApprovalActivityPaper
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim cookie1 As HttpCookie = Request.Cookies("colid")
        If cookie1 Is Nothing Then
            Response.Redirect("activities_approvallogin.aspx")
        Else
        End If

    End Sub
    Protected Sub RowDataBound(ByVal sender As Object, ByVal e As GridViewRowEventArgs)
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes.Add("onmouseover", "MouseEvents(this, event)")
            e.Row.Attributes.Add("onmouseout", "MouseEvents(this, event)")

        End If
    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If (DropDownList1.SelectedItem.Text = "--Select--") Then
            Response.Write("<script type='text/javascript'>alert('Please select the Department!');</script>")
            Exit Sub
        End If
        Dim colid As Integer
        colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        'Dim facultyid As Integer = Convert.ToInt32(DropDownList1.SelectedValue.ToString)
        For Each gr As GridViewRow In GridView1.Rows
            Dim chk1 As CheckBox = gr.FindControl("CheckBox1")
            If chk1 IsNot Nothing AndAlso chk1.Checked Then
                Dim branch As Integer = Convert.ToInt32(gr.Cells(1).Text)

                Dim str1 As String
                str1 = "Update activity_paper set approvestatus='Approved' where colid=" & colid & "and id=" & branch
                Dim cs1 As New schoolclass1
                cs1.insertdata(str1)

            End If
        Next
        GridView1.DataBind()
        Response.Write("<script type='text/javascript'>alert('Approved Successfully');</script>")

    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If (DropDownList1.SelectedItem.Text = "--Select--") Then
            Response.Write("<script type='text/javascript'>alert('Please select the Department!');</script>")
            Exit Sub
        End If
        Dim colid As Integer
        colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        'Dim facultyid As Integer = Convert.ToInt32(DropDownList1.SelectedValue.ToString)
        For Each gr As GridViewRow In GridView1.Rows
            Dim chk1 As CheckBox = gr.FindControl("CheckBox1")
            If chk1 IsNot Nothing AndAlso chk1.Checked Then
                Dim branch As Integer = Convert.ToInt32(gr.Cells(1).Text)

                Dim str1 As String
                str1 = "Update activity_paper set approvestatus='Inactive' where colid=" & colid & "and id=" & branch
                Dim cs1 As New schoolclass1
                cs1.insertdata(str1)

            End If
        Next
        GridView1.DataBind()
        Response.Write("<script type='text/javascript'>alert('Inactive Status Added Successfully');</script>")

    End Sub
End Class
