﻿
Partial Class au_cr7_entry
    Inherits System.Web.UI.Page

End Class
