﻿
Partial Class au_doc_list_f
    Inherits System.Web.UI.Page

End Class
