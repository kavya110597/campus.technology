﻿Imports System.Security.Cryptography
Imports System.IO

Partial Class au_encrypt_code
    Inherits System.Web.UI.Page

    Private TripleDes As New TripleDESCryptoServiceProvider
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'Dim sPlainText As String = Request.Cookies("collegename").Value.ToString
        'Dim key As String = "kumropatash"
        '' Initialize the crypto provider.
        'TripleDes.Key = TruncateHash(key, TripleDes.KeySize \ 8)
        'TripleDes.IV = TruncateHash("", TripleDes.BlockSize \ 8)

        '' Convert the plaintext string to a byte array.
        'Dim plaintextBytes() As Byte =
        'System.Text.Encoding.Unicode.GetBytes(sPlainText)

        '' Create the stream.
        'Dim ms As New System.IO.MemoryStream
        '' Create the encoder to write to the stream.
        'Dim encStream As New CryptoStream(ms,
        'TripleDes.CreateEncryptor(),
        'System.Security.Cryptography.CryptoStreamMode.Write)

        '' Use the crypto stream to write the byte array to the stream.
        'encStream.Write(plaintextBytes, 0, plaintextBytes.Length)
        'encStream.FlushFinalBlock()
        'Label1.Text = Convert.ToBase64String(ms.ToArray)

        Dim empid As Integer = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
        Dim colid As Integer = Convert.ToInt32(Request.Cookies("colid").Value.ToString)

        Dim n1 As Double = (empid * colid + 10) * 2 + 20
        Label1.Text = n1.ToString
    End Sub


    Private Function TruncateHash(
    ByVal key As String,
    ByVal length As Integer) As Byte()

        Dim sha1 As New SHA1CryptoServiceProvider

        ' Hash the key.
        Dim keyBytes() As Byte =
            System.Text.Encoding.Unicode.GetBytes(key)
        Dim hash() As Byte = sha1.ComputeHash(keyBytes)

        ' Truncate or pad the hash.
        ReDim Preserve hash(length - 1)
        Return hash
    End Function
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim principalid As String = Request.Cookies("principalid").Value.ToString
        If principalid = -1 Then
            Response.Redirect("au_notauthorised.aspx")
        End If
    End Sub
End Class
