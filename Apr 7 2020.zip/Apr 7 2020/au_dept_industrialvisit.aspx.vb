﻿Imports DevExpress.XtraPrinting
Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Data.OleDb
Imports System.Drawing
Imports System.Drawing.Color
Partial Class au_dept_industrialvisit
    Inherits System.Web.UI.Page
    Protected Sub ImageWord_Click(sender As Object, e As ImageClickEventArgs) Handles ImageWord.Click

        ASPxGridViewExporter1.GridViewID = "ASPxGridView1"

        ASPxGridViewExporter1.WriteRtfToResponse()

    End Sub
    Protected Sub ImageExcel_Click(sender As Object, e As ImageClickEventArgs) Handles ImageExcel.Click

        ASPxGridViewExporter1.GridViewID = "ASPxGridView1"

        ASPxGridViewExporter1.WriteXlsxToResponse(New XlsxExportOptionsEx With {.ExportType = DevExpress.Export.ExportType.WYSIWYG})
    End Sub
    Protected Sub ImagePDF_Click(sender As Object, e As ImageClickEventArgs) Handles ImagePDF.Click

        ASPxGridViewExporter1.GridViewID = "ASPxGridView1"

        Dim options As New DevExpress.XtraPrinting.PdfExportOptions

        options.Compressed = False
        ASPxGridViewExporter1.WritePdfToResponse(options)

    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Label3.Text = ""
        If DLtitle.SelectedIndex = -1 Then
            Label3.Text = "Select Title"
            Label3.ForeColor = Red
            Exit Sub
        End If
        Dim titleid As Integer = Convert.ToInt32(DLtitle.SelectedValue.ToString)
        Dim filename As String
        If FileUploadsem.HasFile Then
            Dim file As HttpPostedFile = FileUploadsem.PostedFile
            Dim filesize As Integer = file.ContentLength
            If filesize > 1000000 Then
                Label3.Text = "File exceeds the maximum size limit i.e. 1MB"
                Label3.ForeColor = Red
                Exit Sub
            End If
            Dim extensionlist() As String = {".doc", ".docx", ".jpeg", ".gif", ".png", ".pdf", ".jpg"}
            filename = Path.GetFileName(FileUploadsem.FileName)
            Dim extension As String = Path.GetExtension(filename)

            If extensionlist.Contains(extension) = False Then
                Label3.Text = "Invalid file extension.Please upload .doc or .pdf or .jpeg or .png or .jpg or .gif"
                Label3.ForeColor = Red
                Exit Sub
            End If
            Dim newid As String = Guid.NewGuid().ToString()

            Dim newfilename As String = "_" & newid & "_" & filename
            Dim path1 As String = "employee/files/" & newfilename
            Dim dir1 As String = Server.MapPath(".") & "\employee\files"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If
            Dim fileLocation As String = String.Format("{0}\{1}\{2}", Server.MapPath("."), "employee\files", newfilename)

            FileUploadsem.SaveAs(fileLocation)
            Dim str1 As String
            str1 = "Update dept_industrial set document=@path1 where Id=@id"
            updatedata(str1, path1, titleid)
            Label3.Text = "File Uploaded."
            Label3.ForeColor = Green
            ASPxGridView2.DataBind()
        Else
            Label3.Text = "File is either not Selected or is Empty."
            Label3.ForeColor = Red
            Exit Sub
        End If
    End Sub
    Public Sub updatedata(ByVal str As String, ByVal path1 As String, ByVal rowid As Integer)
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = str

            cmd1.Parameters.AddWithValue("@id", rowid).DbType = DbType.Int32
            cmd1.Parameters.AddWithValue("@path1", path1).DbType = DbType.String
            cmd1.ExecuteNonQuery()
            con1.Close()

        End Using
    End Sub
End Class
