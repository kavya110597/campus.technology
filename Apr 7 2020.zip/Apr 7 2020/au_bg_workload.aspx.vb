﻿
Partial Class au_bg_workload
    Inherits System.Web.UI.Page

End Class
