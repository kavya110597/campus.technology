﻿
Partial Class au_attpcourse_report
    Inherits System.Web.UI.Page

End Class
