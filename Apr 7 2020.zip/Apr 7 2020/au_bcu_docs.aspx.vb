﻿
Partial Class au_bcu_docs
    Inherits System.Web.UI.Page


    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not Page.IsPostBack Then
            Dim colid As String
            Dim collegename As String
            Dim facultyid As String
            Try
                colid = Request.Cookies("colid").Value.ToString
            Catch ex As Exception
                Response.Redirect("facultylogin.aspx")
            End Try
            collegename = Request.Cookies("collegename").Value.ToString.Replace(" ", "")
            facultyid = Request.Cookies("nemployeeid").Value.ToString
            Dim type As String

            type = "TRUST/ SOCIETY"
            HyperLink7.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink8.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink8.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            type = "Certificate"
            HyperLink1.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink2.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink2.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            type = "Governing body"
            HyperLink3.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink4.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink4.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            type = "Audit"
            HyperLink5.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink6.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink6.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type


            type = " Land documents"
            HyperLink9.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink10.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink10.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type


            type = "Building documents"
            HyperLink15.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink16.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink16.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type



            type = "Building Plan"
            HyperLink21.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink22.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink22.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            type = "Geo-tagged Photo"
            HyperLink23.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink24.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink24.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            type = "NAAC"
            HyperLink29.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink30.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink30.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            type = "Laboratory Equipment"
            HyperLink31.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink32.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink32.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            type = "LIC"
            HyperLink33.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink34.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink34.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            'type = "Domicile"
            'HyperLink35.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            'HyperLink36.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            'HyperLink36.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

            'type = "BOS"
            'HyperLink11.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            'HyperLink12.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            ' HyperLink12.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
        End If
    End Sub
End Class
