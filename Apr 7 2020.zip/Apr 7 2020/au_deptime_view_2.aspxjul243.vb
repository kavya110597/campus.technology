﻿
Partial Class au_deptime_view_2
    Inherits System.Web.UI.Page

End Class
