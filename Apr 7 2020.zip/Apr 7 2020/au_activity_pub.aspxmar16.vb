﻿
Partial Class au_activity_pub
    Inherits System.Web.UI.Page

End Class
