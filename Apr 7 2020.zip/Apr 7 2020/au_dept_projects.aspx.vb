﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Data.OleDb
Imports System.Drawing
Partial Class au_dept_projects
    Inherits System.Web.UI.Page
    Protected Sub add_project_Click(sender As Object, e As EventArgs) Handles add_project.Click
        msg.Text = ""
        Labelpro.Text = ""
        If dept_rcb.SelectedItem Is Nothing OrElse [String].IsNullOrWhiteSpace(dept_rcb.SelectedItem.Text) Then
            msg.Text = "Please select department."
            msg.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If Title_tb.Text = "" OrElse duration_tb.Text = "" OrElse grants_tb.Text = "" OrElse grantr_tb.Text = "" OrElse funding_tb.Text = "" Then
            msg.Text = "Please enter all details."
            msg.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If status_rcb.SelectedItem Is Nothing OrElse [String].IsNullOrWhiteSpace(status_rcb.SelectedItem.Text) Then
            msg.Text = "Please select status."
            msg.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        Dim deptid As Integer = Convert.ToInt32(dept_rcb.SelectedValue.ToString)

        Dim grants, grantr As Double
        Dim startdate, enddate As Date
        If FileUpload1.HasFile Then
            Dim file As HttpPostedFile = FileUpload1.PostedFile
            Dim filesize As Integer = file.ContentLength
            If filesize > 1000000 Then
                msg.Text = "File exceeds the maximum size limit i.e. 1MB"
                msg.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim extensionlist() As String = {".doc", ".docx", ".jpeg", ".gif", ".png", ".pdf", ".jpg"}
            Dim filename As String = Path.GetFileName(FileUpload1.FileName)
            Dim extension As String = Path.GetExtension(filename)

            If extensionlist.Contains(extension) = False Then
                msg.Text = "Invalid file extension.Please upload .doc or .pdf or .jpeg or .png or .jpg or .gif"
                msg.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim newid As String = Guid.NewGuid().ToString()

            Dim newfilename As String = deptid & "_" & newid & "_" & filename
            Dim path1 As String = "employee/files/" & newfilename
            Dim dir1 As String = Server.MapPath(".") & "\employee\files"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If
            Dim fileLocation As String = String.Format("{0}\{1}\{2}", Server.MapPath("."), "employee\files", newfilename)

            'Dim path2 As String = Server.MapPath(".") & "\students\photos\" & filename
            FileUpload1.SaveAs(fileLocation)

            Try
                startdate = Convert.ToDateTime(start_tb.Text)
                enddate = Convert.ToDateTime(end_tb.Text)
            Catch ex As Exception
                msg.Text = "Invalid date."
                msg.ForeColor = Drawing.Color.Red
                Exit Sub
            End Try
            Try
                grants = Convert.ToDouble(grants_tb.Text)
                grantr = Convert.ToDouble(grantr_tb.Text)
            Catch ex As Exception
                msg.Text = "Invalid grant."
                msg.ForeColor = Drawing.Color.Red
                Exit Sub
            End Try

            SqlDataSource2.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
            SqlDataSource2.InsertParameters("deptid").DefaultValue = deptid
            SqlDataSource2.InsertParameters("title").DefaultValue = Title_tb.Text
            SqlDataSource2.InsertParameters("duration").DefaultValue = duration_tb.Text
            SqlDataSource2.InsertParameters("startdate").DefaultValue = startdate
            SqlDataSource2.InsertParameters("enddate").DefaultValue = enddate
            SqlDataSource2.InsertParameters("grantsanctioned").DefaultValue = grants
            SqlDataSource2.InsertParameters("grantreceived").DefaultValue = grantr
            SqlDataSource2.InsertParameters("fundingagency").DefaultValue = funding_tb.Text
            SqlDataSource2.InsertParameters("status").DefaultValue = status_rcb.SelectedValue.ToString()
            SqlDataSource2.InsertParameters("certificate").DefaultValue = path1
            SqlDataSource2.Insert()
            msg.Text = "Details Added."
            msg.ForeColor = Drawing.Color.Green
            GridView1.DataBind()

        Else
            Try
                startdate = Convert.ToDateTime(start_tb.Text)
                enddate = Convert.ToDateTime(end_tb.Text)
            Catch ex As Exception
                msg.Text = "Invalid date."
                msg.ForeColor = Drawing.Color.Red
                Exit Sub
            End Try
            Try
                grants = Convert.ToDouble(grants_tb.Text)
                grantr = Convert.ToDouble(grantr_tb.Text)
            Catch ex As Exception
                msg.Text = "Invalid grant."
                msg.ForeColor = Drawing.Color.Red
                Exit Sub
            End Try
            SqlDataSource2.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
            SqlDataSource2.InsertParameters("deptid").DefaultValue = dept_rcb.SelectedValue.ToString()
            SqlDataSource2.InsertParameters("title").DefaultValue = Title_tb.Text
            SqlDataSource2.InsertParameters("duration").DefaultValue = duration_tb.Text
            SqlDataSource2.InsertParameters("startdate").DefaultValue = startdate
            SqlDataSource2.InsertParameters("enddate").DefaultValue = enddate
            SqlDataSource2.InsertParameters("grantsanctioned").DefaultValue = grants
            SqlDataSource2.InsertParameters("grantreceived").DefaultValue = grantr
            SqlDataSource2.InsertParameters("fundingagency").DefaultValue = funding_tb.Text
            SqlDataSource2.InsertParameters("status").DefaultValue = status_rcb.SelectedValue.ToString()
            SqlDataSource2.Insert()
            msg.Text = "Details Added."
            msg.ForeColor = Drawing.Color.Green
            GridView1.DataBind()
        End If
    End Sub
    Private Sub GridView1_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView1.RowCommand
        Labelpro.Text = ""
        msg.Text = ""
        Dim deptid As Integer = Convert.ToInt32(dept_rcb.SelectedValue.ToString)

        If e.CommandName = "save" Then
            Dim rowid As Integer = Convert.ToInt32(e.CommandArgument.ToString)
            Dim lbl1 As Label = CType(GridView1.Rows(rowid).FindControl("Labelid2pro"), Label)
            Dim fileid As Integer = Convert.ToInt32(lbl1.Text.ToString)
            Dim FileUploadsave As FileUpload
            FileUploadsave = CType(GridView1.Rows(rowid).FindControl("FileUploadcertipro"), FileUpload)
            Dim filename As String = ""
            Dim path1 As String = ""

            If FileUploadsave.HasFile Then
                Dim file As HttpPostedFile = FileUploadsave.PostedFile
                Dim filesize As Integer = file.ContentLength
                If filesize > 1000000 Then
                    Labelpro.Text = "File exceeds the maximum size limit i.e. 1MB"
                    Labelpro.ForeColor = Drawing.Color.Red
                    Exit Sub
                End If
                Dim extensionlist() As String = {".doc", ".docx", ".jpeg", ".gif", ".png", ".pdf", ".jpg"}
                filename = Path.GetFileName(FileUploadsave.FileName)
                Dim extension As String = Path.GetExtension(filename)

                If extensionlist.Contains(extension) = False Then
                    Labelpro.Text = "Invalid file extension.Please upload .doc or .pdf or .jpeg or .png or .jpg or .gif"
                    Labelpro.ForeColor = Drawing.Color.Red
                    Exit Sub
                End If
                Dim newid As String = Guid.NewGuid().ToString()

                Dim newfilename As String = deptid & "_" & newid & "_" & filename
                path1 = "employee/files/" & newfilename
                Dim dir1 As String = Server.MapPath(".") & "\employee\files\"
                If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                    My.Computer.FileSystem.CreateDirectory(dir1)
                End If
                'Dim path2 As String = Server.MapPath(".") & "\students\photos\" & filename
                Dim fileLocation As String = String.Format("{0}\{1}\{2}", Server.MapPath("."), "employee\files", newfilename)

                FileUploadsave.SaveAs(fileLocation)


            End If
            Dim str1 As String
            str1 = "Update au_dept_projects set certificate=@path1 where Id=@id"
            updatedata(str1, path1, fileid)
            Labelpro.Text = "File Uploaded."
            Labelpro.ForeColor = Drawing.Color.Green
            GridView1.DataBind()

        End If
    End Sub
    Public Sub updatedata(ByVal str As String, ByVal path1 As String, ByVal rowid As Integer)
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = str

            cmd1.Parameters.AddWithValue("@id", rowid).DbType = DbType.Int32
            cmd1.Parameters.AddWithValue("@path1", path1).DbType = DbType.String
            cmd1.ExecuteNonQuery()
            con1.Close()

        End Using
    End Sub

    Protected Sub BSemExcel_Click(sender As Object, e As EventArgs) Handles BSemExcel.Click
        Label12.Text = ""
        Dim colid As Integer
        Dim startdate, enddate As Date
        Dim grants, grantr As Double
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)

        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        If dept_rcb.SelectedItem Is Nothing OrElse [String].IsNullOrWhiteSpace(dept_rcb.SelectedItem.Text) Then
            Label12.Text = "Please select department."
            Label12.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If FileUpload2.HasFile Then
            Dim file As HttpPostedFile = FileUpload2.PostedFile
            Dim filesize As Integer = file.ContentLength
            If filesize > 4194304 Then
                Label12.Text = "File exceeds the maximum size limit i.e. 4MB"
                Label12.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim filename As String = Path.GetFileName(FileUpload2.FileName)
            Dim extension As String = Path.GetExtension(filename)

            If extension <> ".xls" AndAlso extension <> ".xlsx" Then
                Label12.Text = "Invalid file extension.Please upload .xls or .xlsx file"
                Label12.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim path1 As String = "employee/photos/" & filename
            Dim dir1 As String = Server.MapPath(".") & "\employee\files"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If
            Dim path2 As String = Server.MapPath(".") & "\employee\files\" & filename

            FileUpload2.SaveAs(path2)


            Dim constr1 As String

            constr1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & path2 & ";Extended Properties=""Excel 12.0 Xml;HDR=YES"";"
            Using con1 As New OleDbConnection
                con1.ConnectionString = constr1
                con1.Open()
                Dim cmd1 As New OleDbCommand
                cmd1.Connection = con1
                cmd1.CommandText = "Select * from [Sheet1$]"
                Dim rdr1 As OleDbDataReader = cmd1.ExecuteReader

                Do While rdr1.Read
                    Try
                        startdate = Convert.ToDateTime(rdr1.GetValue(2).ToString)
                        enddate = Convert.ToDateTime(rdr1.GetValue(3).ToString)
                    Catch ex As Exception
                        Label12.Text = "Invalid date."
                        Label12.ForeColor = Drawing.Color.Red
                        Exit Sub
                    End Try
                    Try
                        grants = Convert.ToDouble(rdr1.GetValue(4).ToString)
                        grantr = Convert.ToDouble(rdr1.GetValue(5).ToString)
                    Catch ex As Exception
                        Label12.Text = "Invalid grant."
                        Label12.ForeColor = Drawing.Color.Red
                        Exit Sub
                    End Try
                    SqlDataSource2.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
                    SqlDataSource2.InsertParameters("deptid").DefaultValue = Convert.ToInt32(dept_rcb.SelectedValue.ToString())
                    SqlDataSource2.InsertParameters("title").DefaultValue = rdr1.GetValue(0).ToString
                    SqlDataSource2.InsertParameters("duration").DefaultValue = rdr1.GetValue(1).ToString
                    SqlDataSource2.InsertParameters("startdate").DefaultValue = startdate
                    SqlDataSource2.InsertParameters("enddate").DefaultValue = enddate
                    SqlDataSource2.InsertParameters("grantsanctioned").DefaultValue = grants
                    SqlDataSource2.InsertParameters("grantreceived").DefaultValue = grantr
                    SqlDataSource2.InsertParameters("fundingagency").DefaultValue = rdr1.GetValue(6).ToString
                    SqlDataSource2.InsertParameters("status").DefaultValue = rdr1.GetValue(7).ToString
                    SqlDataSource2.Insert()

                    GridView1.DataBind()


                Loop
                rdr1.Close()
                con1.Close()
            End Using

            Label12.Text = "Details Added."
            Label12.ForeColor = Drawing.Color.Green
            GridView1.DataBind()
        Else
            Label12.Text = "File is either not Selected or is Empty."
            Label12.ForeColor = Drawing.Color.Red
            Exit Sub
        End If

    End Sub
    Protected Sub ImageExcel_Click(sender As Object, e As ImageClickEventArgs) Handles ImageExcel.Click
        If GridView1.Rows.Count > 0 Then
            ExportToExcel()
        Else
            Label12.Text = "No data to export."
            Label12.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
    End Sub
    Public Sub ExportToExcel()
        Response.Clear()
        Response.Buffer = True
        Response.AddHeader("content-disposition", "attachment;filename=MyCustomReport.xls")
        Response.Charset = ""
        Response.ContentType = "application/vnd.ms-excel"
        Using sw As New StringWriter()
            Dim hw As New HtmlTextWriter(sw)

            ''To Export all pages
            'GridView1.AllowPaging = False
            'Me.BindGrid()

            GridView1.HeaderRow.BackColor = Color.White
            For Each cell As TableCell In GridView1.HeaderRow.Cells
                cell.BackColor = GridView1.HeaderStyle.BackColor
            Next
            For Each row As GridViewRow In GridView1.Rows
                row.BackColor = Color.White
                For Each cell As TableCell In row.Cells
                    If row.RowIndex Mod 2 = 0 Then
                        cell.BackColor = GridView1.AlternatingRowStyle.BackColor
                    Else
                        cell.BackColor = GridView1.RowStyle.BackColor
                    End If
                    cell.CssClass = "textmode"
                Next
            Next

            GridView1.RenderControl(hw)
            'style to format numbers to string
            Dim style As String = "<style> .textmode { } </style>"
            Response.Write(style)
            Response.Output.Write(sw.ToString())
            Response.Flush()
            Response.[End]()
        End Using
    End Sub

    Public Overrides Sub VerifyRenderingInServerForm(control As Control)
        ' Verifies that the control is rendered
    End Sub
End Class
