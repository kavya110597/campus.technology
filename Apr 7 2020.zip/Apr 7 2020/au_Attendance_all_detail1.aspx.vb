﻿
Partial Class au_Attendance_all_detail1
    Inherits System.Web.UI.Page

End Class
