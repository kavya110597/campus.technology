﻿
Partial Class au_centralunimarksheet
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If ASPxComboBox1.SelectedIndex = -1 OrElse ASPxComboBox2.SelectedIndex = -1 OrElse ASPxComboBox3.SelectedIndex = -1 Then
            Label1.Text = "Please Select Semester/Student"
            Label1.ForeColor = System.Drawing.Color.Red
            Exit Sub
        End If
        Dim semester As String = ASPxComboBox2.SelectedItem.ToString
        Dim studid As Integer = Convert.ToInt32(ASPxComboBox3.SelectedItem.Value.ToString)

        Response.Redirect("au_student_marksheet.aspx?semester=" & semester & "&studid=" & studid)
    End Sub
End Class
