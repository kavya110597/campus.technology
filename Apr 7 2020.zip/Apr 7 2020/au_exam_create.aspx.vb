﻿
Partial Class au_exam_create
    Inherits System.Web.UI.Page

End Class
