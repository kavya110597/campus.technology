﻿
Partial Class faculty_au_awarddetails
    Inherits System.Web.UI.Page

End Class
