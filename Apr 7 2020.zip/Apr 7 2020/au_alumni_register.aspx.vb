﻿
Partial Class Account_au_alumni_register
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Literal1.Text = ""
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.QueryString("colid").ToString)
        Catch ex As Exception
            Literal1.Text = "Invalid link"
            Exit Sub
        End Try
        If RadComboBox1.SelectedIndex = -1 OrElse RadComboBox2.SelectedIndex = -1 Then
            Literal1.Text = "Please select Program and Batch"
            Exit Sub
        End If
        SqlDataSource3.InsertParameters("colid").DefaultValue = colid
        SqlDataSource3.InsertParameters("name").DefaultValue = TextBox3.Text
        SqlDataSource3.InsertParameters("streetname").DefaultValue = Mid(TextBox5.Text, 1, 599)
        SqlDataSource3.InsertParameters("mob").DefaultValue = TextBox6.Text
        SqlDataSource3.InsertParameters("email").DefaultValue = ASPxTextBox1.Text
        SqlDataSource3.InsertParameters("batch").DefaultValue = RadComboBox2.SelectedValue.ToString
        SqlDataSource3.InsertParameters("login").DefaultValue = ASPxTextBox1.Text
        SqlDataSource3.InsertParameters("password").DefaultValue = TextBox2.Text
        SqlDataSource3.InsertParameters("programid").DefaultValue = Convert.ToInt32(RadComboBox1.SelectedValue.ToString)
        SqlDataSource3.InsertParameters("country").DefaultValue = TextBox4.Text
        SqlDataSource3.InsertParameters("status").DefaultValue = "Alumni"
        SqlDataSource3.Insert()
        Literal1.Text = "Thak you for registration.<br><br> A link will be sent to you <br>after approval for accessing <br>alumni portal."


    End Sub
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub
End Class
