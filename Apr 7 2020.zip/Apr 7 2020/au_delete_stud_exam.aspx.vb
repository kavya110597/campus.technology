﻿
Partial Class au_delete_stud_exam
    Inherits System.Web.UI.Page

End Class
