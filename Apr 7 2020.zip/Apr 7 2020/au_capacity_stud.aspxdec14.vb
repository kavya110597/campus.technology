﻿
Partial Class au_capacity_stud
    Inherits System.Web.UI.Page

End Class
