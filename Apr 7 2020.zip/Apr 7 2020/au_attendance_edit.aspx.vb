﻿
Partial Class au_attendance_edit
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        'Dim principalid As Integer = -1
        'Try
        '    principalid = Convert.ToInt32(Request.Cookies("principalid").Value.ToString)
        'Catch ex As Exception

        'End Try
        'If principalid = -1 Then
        '    Response.Redirect("au_notauthorized.aspx")
        'End If
    End Sub
    Protected Sub RadButton1_Click(sender As Object, e As EventArgs) Handles RadButton1.Click
        Dim colid, classid, classgid As Integer
        Try
            classid = Convert.ToInt32(Request.Cookies("classid").Value.ToString)
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
            classgid = Convert.ToInt32(Request.Cookies("classgid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        Dim str1 As String
        str1 = "Delete from nba_attendance where colid=" & colid & " and classgid=" & classgid & " and classid=" & classid
        Dim cs1 As New schoolclass1
        cs1.insertdata(str1)
        RadGrid3.DataBind()

    End Sub
End Class
