﻿
Partial Class au_course_report
    Inherits System.Web.UI.Page

End Class
