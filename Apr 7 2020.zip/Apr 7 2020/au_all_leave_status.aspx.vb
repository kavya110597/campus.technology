﻿
Partial Class au_all_leave_status
    Inherits System.Web.UI.Page

End Class
