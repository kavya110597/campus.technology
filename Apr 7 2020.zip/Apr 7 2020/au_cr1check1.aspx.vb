﻿Imports System.Data
Imports System.Data.SqlClient

Partial Class au_cr1check1
    Inherits System.Web.UI.Page
    Public constr1 As String
    Public colid As Integer
    Dim tp As Integer


    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try

        If Not Page.IsPostBack Then
            checkprograms()
            checkcode()
            checkvalueadded()
            checkfeedback()

        End If

    End Sub
    Public Sub checkprograms()
        Dim p1 As Integer = 0
        Dim d1 As Integer = 0
        Dim do1 As Integer = 0



        Dim str1 As String


        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "Select count(*) from depall1 where colid=" & colid
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                Try
                    d1 = Convert.ToInt32(rdr1.GetValue(0).ToString)
                Catch ex As Exception

                End Try
            Loop
            rdr1.Close()

            If d1 < 2 Then
                Literal1.Text = "You have not added any department. Add department from Configure - Department.<br>"
            Else
                Literal1.Text = "You have added " & d1 & " departments. Add more departments from Configure - Department.<br>"
            End If

            cmd1.CommandText = "select count(*) from depall1 where colid=" & colid & " and id not in (select distinct deptid from nba_programs where colid=" & colid & ")"
            rdr1 = cmd1.ExecuteReader
            Do While rdr1.Read
                Try
                    do1 = Convert.ToInt32(rdr1.GetValue(0).ToString)
                Catch ex As Exception

                End Try
            Loop
            rdr1.Close()

            If do1 > 1 Then
                str1 = "You have " & do1 & " departments with no program added."
                Literal1.Text = Literal1.Text & str1 & "<br>"
            End If


            cmd1.CommandText = "Select count(*) from nba_programs where colid=" & colid
            rdr1 = cmd1.ExecuteReader
            Do While rdr1.Read
                Try
                    p1 = Convert.ToInt32(rdr1.GetValue(0).ToString)
                Catch ex As Exception

                End Try
            Loop
            rdr1.Close()

            tp = p1


            If p1 = 0 Then
                str1 = "Please add programs from Configure - Program."
                Literal1.Text = Literal1.Text & str1 & "<br>"
                Panel1.Visible = False

            End If
            If p1 > 0 AndAlso do1 > 1 Then
                str1 = "You have added " & p1 & " programs. Is that all? You still have " & do1 & " departments with no program added."
                Literal1.Text = Literal1.Text & str1 & "<br>"
            End If
            If p1 > 0 AndAlso do1 < 1 Then
                str1 = "You have added " & p1 & " programs. Is that all?"
                Literal1.Text = Literal1.Text & str1 & "<br>"
            End If




            con1.Close()
        End Using



    End Sub
    Public Sub checkcode()
        Dim blankpcode As Integer = 0
        Dim blankccode As Integer = 0
        Dim str1 As String

        Literal2.Text = ""

        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1

            cmd1.CommandText = "Select count(*) from nba_programs where colid=" & colid & " and (programcode is null or programcode='')"
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                Try
                    blankpcode = Convert.ToInt32(rdr1.GetValue(0).ToString)
                Catch ex As Exception

                End Try
            Loop
            rdr1.Close()



            If blankpcode = 0 Then
                Button1.Visible = False
            Else
                    str1 = "There are " & blankpcode & " programs with blank program code."
                    Literal2.Text = Literal2.Text & str1 & "<br>"
                End If


            cmd1.CommandText = "Select count(*) from nba_course where colid=" & colid & " and (coursecode is null or coursecode='')"
            rdr1 = cmd1.ExecuteReader
            Do While rdr1.Read
                Try
                    blankccode = Convert.ToInt32(rdr1.GetValue(0).ToString)
                Catch ex As Exception

                End Try
            Loop
            rdr1.Close()

            If blankccode = 0 Then
                Button2.Visible = False
            Else
                str1 = "There are " & blankccode & " course with blank course code."
                Literal2.Text = Literal2.Text & str1 & "<br>"
            End If






            con1.Close()
        End Using





    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Literal3.Text = ""
        Dim program As String
        Dim programid As Integer
        Dim programcode As String


        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "Select id, programs from nba_programs where colid=" & colid & " and (programcode is null or programcode='')"
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                Try
                    programid = Convert.ToInt32(rdr1.GetValue(0).ToString)
                    program = rdr1.GetValue(1).ToString
                    programcode = Mid(program, 1, 2) & Mid(program, Len(program) - 2) & programid.ToString
                    Dim str1 As String
                    str1 = "Update nba_programs set programcode='" & programcode & "' where colid=" & colid & " and id=" & programid
                    Dim cs1 As New schoolclass1
                    cs1.insertdata(str1)

                Catch ex As Exception

                End Try
            Loop
            rdr1.Close()
            con1.Close()
        End Using
        Literal3.Text = "Program code is updated."
        checkcode()
        'ASPxGridView2.DataBind()

    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Literal3.Text = ""
        Dim program As String
        Dim programid As Integer
        Dim programcode As String


        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "Select id,coursename from nba_course where colid=" & colid & " and (coursecode is null or coursecode='')"
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                Try
                    programid = Convert.ToInt32(rdr1.GetValue(0).ToString)
                    program = rdr1.GetValue(1).ToString
                    programcode = Mid(program, 1, 2) & Mid(program, Len(program) - 2) & programid.ToString
                    Dim str1 As String
                    str1 = "Update nba_course set coursecode='" & programcode & "' where colid=" & colid & " and id=" & programid
                    Dim cs1 As New schoolclass1
                    cs1.insertdata(str1)

                Catch ex As Exception

                End Try
            Loop
            rdr1.Close()
            con1.Close()
        End Using
        Literal3.Text = "Course code is updated."
        checkcode()
        'ASPxGridView3.DataBind()

    End Sub
    Public Sub checkvalueadded()
        Dim blankpcode As Integer = 0
        Dim blankccode As Integer = 0
        Dim str1 As String

        Literal4.Text = ""

        checkaddondata("2013-14")
        checkaddondata("2014-15")
        checkaddondata("2015-16")
        checkaddondata("2016-17")
        checkaddondata("2017-18")
        checkaddondata("2018-19")
        checkaddondata("2019-20")

        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1



            cmd1.CommandText = "Select count(*) from au_valueadded where colid=" & colid & " and (CourseCode is null or CourseCode='')"
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                Try
                    blankccode = Convert.ToInt32(rdr1.GetValue(0).ToString)
                Catch ex As Exception

                End Try
            Loop
            rdr1.Close()

            If blankccode = 0 Then
                Button3.Visible = False
            Else
                str1 = "There are " & blankccode & " add on courses with blank course code."
                Literal4.Text = Literal4.Text & str1 & "<br>"
            End If
            con1.Close()
        End Using

    End Sub
    Public Sub checkaddondata(ByVal academicyear As String)
        Dim blankpcode As Integer = 0
        Dim blankccode As Integer = 0
        Dim str1 As String

        'Literal4.Text = ""

        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1

            cmd1.CommandText = "Select count(*) from au_valueadded where colid=" & colid & " and AcademicYear='" & academicyear & "'"
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                Try
                    blankpcode = Convert.ToInt32(rdr1.GetValue(0).ToString)
                Catch ex As Exception

                End Try
            Loop
            rdr1.Close()

            If blankpcode = 0 Then
                str1 = "You have not added any Add On Program for " & academicyear & ". It is recommended to introduce at least 10 value added courses per year. Please add Add On Programs from Configuration - Add On programs."
            Else
                If blankpcode < 10 Then
                    str1 = "There are " & blankpcode & " Value Added Programs for Academic Year " & academicyear & ". It is recommended to implement 10 value added programs per year."
                End If
            End If
            Literal4.Text = Literal4.Text & str1 & "<br>"

            con1.Close()
        End Using
    End Sub
    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim program As String
        Dim programid As Integer
        Dim programcode As String


        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "Select id, CourseName from au_valueadded where colid=" & colid & " and (CourseCode is null or CourseCode='')"
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                Try
                    programid = Convert.ToInt32(rdr1.GetValue(0).ToString)
                    program = rdr1.GetValue(1).ToString
                    programcode = Mid(program, 1, 2) & Mid(program, Len(program) - 2) & programid.ToString
                    Dim str1 As String
                    str1 = "Update au_valueadded set CourseCode='" & programcode & "' where colid=" & colid & " and id=" & programid
                    Dim cs1 As New schoolclass1
                    cs1.insertdata(str1)

                Catch ex As Exception

                End Try
            Loop
            rdr1.Close()
            con1.Close()
        End Using
        checkvalueadded()

    End Sub
    Public Sub checkfeedback()
        Dim blankpcode As Integer = 0
        Dim blankccode As Integer = 0
        Dim str1 As String

        Literal5.Text = ""

        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1

            cmd1.CommandText = "select count(*) from surveyexam1 where colid=" & colid

            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                Try
                    blankpcode = Convert.ToInt32(rdr1.GetValue(0).ToString)
                Catch ex As Exception

                End Try
            Loop
            rdr1.Close()

            If blankpcode = 0 Then
                str1 = "You have not added any Feedback. It is recommended to take five different type of feedback from all stakeholders each year. Please generate feedback from Feedback - Template."
            Else
                If blankpcode < 25 Then
                    str1 = "It is recommended to implement at least five feedback every year to be taken from all stakeholders. Please generate feedback from Feedback - Template."
                Else
                    str1 = "You have added " & blankpcode & " feedbacks. Please check if any feedback is missing."
                End If
            End If
            Literal5.Text = Literal5.Text & str1 & "<br>"

            con1.Close()
        End Using
    End Sub
End Class
