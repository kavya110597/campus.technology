﻿
Partial Class au_att_admin
    Inherits System.Web.UI.Page

End Class
