﻿
Partial Class au_edit_profile
    Inherits System.Web.UI.Page

End Class
