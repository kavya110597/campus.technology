﻿
Partial Class au_adm_assign_c
    Inherits System.Web.UI.Page

End Class
