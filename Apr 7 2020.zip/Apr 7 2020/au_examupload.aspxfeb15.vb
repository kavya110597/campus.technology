﻿Imports System.IO
Imports System.Data.OleDb
Imports DevExpress.XtraPrinting
Imports Telerik.Web.UI
Imports System.Data
Imports System.Data.SqlClient
Partial Class au_examupload
    Inherits System.Web.UI.Page
    Protected Sub ImageExcel_Click(sender As Object, e As ImageClickEventArgs) Handles ImageExcel.Click

        ASPxGridViewExporter1.GridViewID = "ASPxGridView1"

        ASPxGridViewExporter1.WriteXlsxToResponse(New XlsxExportOptionsEx With {.ExportType = DevExpress.Export.ExportType.WYSIWYG})
    End Sub
    Protected Sub BstudExcel_Click(sender As Object, e As EventArgs) Handles BstudExcel.Click
        If FileUpload1.HasFile Then
            Dim file As HttpPostedFile = FileUpload1.PostedFile
            Dim filesize As Integer = file.ContentLength
            If filesize > 4194304 Then
                Label1.Text = "File exceeds the maximum size limit i.e. 4MB"
                ' Label1.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            'Dim extensionlist() As String = {".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".txt", ".rtf", ".bmp", ".jpeg", ".gif", ".tiff", ".png", ".pcx", ".emf", ".rle", ".dib", ".pdf"}
            Dim filename As String = Path.GetFileName(FileUpload1.FileName)
            Dim extension As String = Path.GetExtension(filename)

            'If extensionlist.Contains(extension) = False Then
            '    Page.ClientScript.RegisterStartupScript(Me.[GetType](), "Alert", "alert('Invalid file extension.Please upload .jpeg or .png or .jpg image');", True)

            '    Exit Sub
            'End If

            If extension <> ".xls" AndAlso extension <> ".xlsx" Then
                Label1.Text = "Invalid file extension.Please upload .xls or .xlsx file"
                'Label1.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim path1 As String = "employee/photos/" & filename
            Dim dir1 As String = Server.MapPath(".") & "\employee\files"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If
            Dim path2 As String = Server.MapPath(".") & "\employee\files\" & filename

            FileUpload1.SaveAs(path2)

            'Dim msg1 As New msgbox11

            Dim constr1 As String

            constr1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & path2 & ";Extended Properties=""Excel 12.0 Xml;HDR=YES"";"
            Using con1 As New OleDbConnection
                con1.ConnectionString = constr1
                con1.Open()
                Dim cmd1 As New OleDbCommand
                cmd1.Connection = con1
                cmd1.CommandText = "Select * from [Sheet1$]"
                Dim rdr1 As OleDbDataReader = cmd1.ExecuteReader

                Do While rdr1.Read
                    Dim doresult As Date
                    Try
                        doresult = Convert.ToDateTime(rdr1.GetValue(65).ToString)

                    Catch ex As Exception
                        Label1.Text = "Invalid Date of Result. Valid Date format is MM-DD-YYYY"
                        Exit Sub
                    End Try
                    Try


                        upload_sql.InsertParameters("College").DefaultValue = rdr1.GetValue(0).ToString
                        upload_sql.InsertParameters("Program").DefaultValue = rdr1.GetValue(1).ToString
                        upload_sql.InsertParameters("Semester").DefaultValue = rdr1.GetValue(2).ToString
                        upload_sql.InsertParameters("Specialization").DefaultValue = rdr1.GetValue(3).ToString
                        upload_sql.InsertParameters("MSN").DefaultValue = rdr1.GetValue(4).ToString
                        upload_sql.InsertParameters("EnrollNo").DefaultValue = rdr1.GetValue(5).ToString
                        upload_sql.InsertParameters("RollNo").DefaultValue = rdr1.GetValue(6).ToString
                        upload_sql.InsertParameters("Code").DefaultValue = rdr1.GetValue(7).ToString
                        upload_sql.InsertParameters("StudentName").DefaultValue = rdr1.GetValue(8).ToString
                        upload_sql.InsertParameters("FatherName").DefaultValue = rdr1.GetValue(9).ToString
                        upload_sql.InsertParameters("MotherName").DefaultValue = rdr1.GetValue(10).ToString
                        upload_sql.InsertParameters("Subject").DefaultValue = rdr1.GetValue(11).ToString
                        If rdr1.GetValue(12).ToString = "" Then
                            upload_sql.InsertParameters("TH1SA").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TH1SA").DefaultValue = Convert.ToDouble(rdr1.GetValue(12).ToString)
                        End If
                        If rdr1.GetValue(13).ToString = "" Then
                            upload_sql.InsertParameters("TH1SAMM").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TH1SAMM").DefaultValue = Convert.ToDouble(rdr1.GetValue(13).ToString)
                        End If
                        If rdr1.GetValue(14).ToString = "" Then
                            upload_sql.InsertParameters("TH1SB").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TH1SB").DefaultValue = Convert.ToDouble(rdr1.GetValue(14).ToString)
                        End If

                        If rdr1.GetValue(15).ToString = "" Then
                            upload_sql.InsertParameters("TH1SBMM").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TH1SBMM").DefaultValue = Convert.ToDouble(rdr1.GetValue(15).ToString)
                        End If

                        If rdr1.GetValue(16).ToString = "" Then
                            upload_sql.InsertParameters("TH2SA").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TH2SA").DefaultValue = Convert.ToDouble(rdr1.GetValue(16).ToString)
                        End If

                        If rdr1.GetValue(17).ToString = "" Then
                            upload_sql.InsertParameters("TH2SAMM").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TH2SAMM").DefaultValue = Convert.ToDouble(rdr1.GetValue(17).ToString)
                        End If

                        If rdr1.GetValue(18).ToString = "" Then
                            upload_sql.InsertParameters("TH2SB").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TH2SB").DefaultValue = Convert.ToDouble(rdr1.GetValue(18).ToString)
                        End If

                        If rdr1.GetValue(19).ToString = "" Then
                            upload_sql.InsertParameters("TH2SBMM").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TH2SBMM").DefaultValue = Convert.ToDouble(rdr1.GetValue(19).ToString)
                        End If

                        If rdr1.GetValue(20).ToString = "" Then
                            upload_sql.InsertParameters("TOTH").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TOTH").DefaultValue = Convert.ToDouble(rdr1.GetValue(20).ToString)
                        End If

                        If rdr1.GetValue(21).ToString = "" Then
                            upload_sql.InsertParameters("TOTHMM").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TOTHMM").DefaultValue = Convert.ToDouble(rdr1.GetValue(21).ToString)
                        End If

                        If rdr1.GetValue(22).ToString = "" Then
                            upload_sql.InsertParameters("THIA1").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("THIA1").DefaultValue = Convert.ToDouble(rdr1.GetValue(22).ToString)
                        End If

                        If rdr1.GetValue(23).ToString = "" Then
                            upload_sql.InsertParameters("THIA1MM").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("THIA1MM").DefaultValue = Convert.ToDouble(rdr1.GetValue(23).ToString)
                        End If

                        If rdr1.GetValue(24).ToString = "" Then
                            upload_sql.InsertParameters("THIA2").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("THIA2").DefaultValue = Convert.ToDouble(rdr1.GetValue(24).ToString)
                        End If

                        If rdr1.GetValue(25).ToString = "" Then
                            upload_sql.InsertParameters("THIA2MM").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("THIA2MM").DefaultValue = Convert.ToDouble(rdr1.GetValue(25).ToString)
                        End If

                        If rdr1.GetValue(26).ToString = "" Then
                            upload_sql.InsertParameters("TOTHIA").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TOTHIA").DefaultValue = Convert.ToDouble(rdr1.GetValue(26).ToString)
                        End If

                        If rdr1.GetValue(27).ToString = "" Then
                            upload_sql.InsertParameters("TOTHIAMM").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TOTHIAMM").DefaultValue = Convert.ToDouble(rdr1.GetValue(27).ToString)
                        End If

                        If rdr1.GetValue(28).ToString = "" Then
                            upload_sql.InsertParameters("TOTHViva").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TOTHViva").DefaultValue = Convert.ToDouble(rdr1.GetValue(28).ToString)
                        End If

                        If rdr1.GetValue(29).ToString = "" Then
                            upload_sql.InsertParameters("TOTHVivaMM").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TOTHVivaMM").DefaultValue = Convert.ToDouble(rdr1.GetValue(29).ToString)
                        End If

                        If rdr1.GetValue(30).ToString = "" Then
                            upload_sql.InsertParameters("TOTHOral").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TOTHOral").DefaultValue = Convert.ToDouble(rdr1.GetValue(30).ToString)
                        End If

                        If rdr1.GetValue(31).ToString = "" Then
                            upload_sql.InsertParameters("TOTHOralMM").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TOTHOralMM").DefaultValue = Convert.ToDouble(rdr1.GetValue(31).ToString)
                        End If

                        If rdr1.GetValue(32).ToString = "" Then
                            upload_sql.InsertParameters("TOTHOralViva").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TOTHOralViva").DefaultValue = Convert.ToDouble(rdr1.GetValue(32).ToString)
                        End If

                        If rdr1.GetValue(33).ToString = "" Then
                            upload_sql.InsertParameters("TOTHOralVivaMM").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TOTHOralVivaMM").DefaultValue = Convert.ToDouble(rdr1.GetValue(33).ToString)
                        End If

                        If rdr1.GetValue(34).ToString = "" Then
                            upload_sql.InsertParameters("TotalTheoryPart").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TotalTheoryPart").DefaultValue = Convert.ToDouble(rdr1.GetValue(34).ToString)
                        End If

                        If rdr1.GetValue(35).ToString = "" Then
                            upload_sql.InsertParameters("TotalTheoryPartMM").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TotalTheoryPartMM").DefaultValue = Convert.ToDouble(rdr1.GetValue(35).ToString)
                        End If

                        'If rdr1.GetValue(36).ToString = "" Then
                        '    upload_sql.InsertParameters("THRE").DefaultValue = "NULL"
                        'Else
                        upload_sql.InsertParameters("THRE").DefaultValue = rdr1.GetValue(36).ToString
                        'End If

                        If rdr1.GetValue(37).ToString = "" Then
                            upload_sql.InsertParameters("PR1").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("PR1").DefaultValue = Convert.ToDouble(rdr1.GetValue(37).ToString)
                        End If

                        If rdr1.GetValue(38).ToString = "" Then
                            upload_sql.InsertParameters("PR1MM").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("PR1MM").DefaultValue = Convert.ToDouble(rdr1.GetValue(38).ToString)
                        End If

                        If rdr1.GetValue(39).ToString = "" Then
                            upload_sql.InsertParameters("PR2").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("PR2").DefaultValue = Convert.ToDouble(rdr1.GetValue(39).ToString)
                        End If

                        If rdr1.GetValue(40).ToString = "" Then
                            upload_sql.InsertParameters("PR2MM").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("PR2MM").DefaultValue = Convert.ToDouble(rdr1.GetValue(40).ToString)
                        End If

                        If rdr1.GetValue(41).ToString = "" Then
                            upload_sql.InsertParameters("TOPR").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TOPR").DefaultValue = Convert.ToDouble(rdr1.GetValue(41).ToString)
                        End If

                        If rdr1.GetValue(42).ToString = "" Then
                            upload_sql.InsertParameters("TOPRMM").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TOPRMM").DefaultValue = Convert.ToDouble(rdr1.GetValue(42).ToString)
                        End If

                        If rdr1.GetValue(43).ToString = "" Then
                            upload_sql.InsertParameters("PRIA1").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("PRIA1").DefaultValue = Convert.ToDouble(rdr1.GetValue(43).ToString)
                        End If

                        If rdr1.GetValue(44).ToString = "" Then
                            upload_sql.InsertParameters("PRIA1MM").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("PRIA1MM").DefaultValue = Convert.ToDouble(rdr1.GetValue(44).ToString)
                        End If

                        If rdr1.GetValue(45).ToString = "" Then
                            upload_sql.InsertParameters("PRIA2").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("PRIA2").DefaultValue = Convert.ToDouble(rdr1.GetValue(45).ToString)
                        End If

                        If rdr1.GetValue(46).ToString = "" Then
                            upload_sql.InsertParameters("PRIA2MM").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("PRIA2MM").DefaultValue = Convert.ToDouble(rdr1.GetValue(46).ToString)
                        End If

                        If rdr1.GetValue(47).ToString = "" Then
                            upload_sql.InsertParameters("TOPRIA").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TOPRIA").DefaultValue = Convert.ToDouble(rdr1.GetValue(47).ToString)
                        End If

                        If rdr1.GetValue(48).ToString = "" Then
                            upload_sql.InsertParameters("TOPRIAMM").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TOPRIAMM").DefaultValue = Convert.ToDouble(rdr1.GetValue(48).ToString)
                        End If

                        If rdr1.GetValue(49).ToString = "" Then
                            upload_sql.InsertParameters("TOPRViva").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TOPRViva").DefaultValue = Convert.ToDouble(rdr1.GetValue(49).ToString)
                        End If

                        If rdr1.GetValue(50).ToString = "" Then
                            upload_sql.InsertParameters("TOPRVivaMM").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TOPRVivaMM").DefaultValue = Convert.ToDouble(rdr1.GetValue(50).ToString)
                        End If

                        If rdr1.GetValue(51).ToString = "" Then
                            upload_sql.InsertParameters("TOPROral").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TOPROral").DefaultValue = Convert.ToDouble(rdr1.GetValue(51).ToString)
                        End If

                        If rdr1.GetValue(52).ToString = "" Then
                            upload_sql.InsertParameters("TOPROralMM").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TOPROralMM").DefaultValue = Convert.ToDouble(rdr1.GetValue(52).ToString)
                        End If

                        If rdr1.GetValue(53).ToString = "" Then
                            upload_sql.InsertParameters("TOPRVivaOral").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TOPRVivaOral").DefaultValue = Convert.ToDouble(rdr1.GetValue(53).ToString)
                        End If

                        If rdr1.GetValue(54).ToString = "" Then
                            upload_sql.InsertParameters("TOPRVivaOralMM").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TOPRVivaOralMM").DefaultValue = Convert.ToDouble(rdr1.GetValue(54).ToString)
                        End If

                        If rdr1.GetValue(55).ToString = "" Then
                            upload_sql.InsertParameters("TO_PR").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TO_PR").DefaultValue = Convert.ToDouble(rdr1.GetValue(55).ToString)
                        End If

                        If rdr1.GetValue(56).ToString = "" Then
                            upload_sql.InsertParameters("TO_PRMM").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("TO_PRMM").DefaultValue = Convert.ToDouble(rdr1.GetValue(56).ToString)
                        End If


                        upload_sql.InsertParameters("PRRE").DefaultValue = rdr1.GetValue(57).ToString


                        If rdr1.GetValue(58).ToString = "" Then
                            upload_sql.InsertParameters("STOOM").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("STOOM").DefaultValue = Convert.ToDouble(rdr1.GetValue(58).ToString)
                        End If

                        If rdr1.GetValue(59).ToString = "" Then
                            upload_sql.InsertParameters("STOMM").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("STOMM").DefaultValue = Convert.ToDouble(rdr1.GetValue(59).ToString)
                        End If

                        upload_sql.InsertParameters("FinalResult").DefaultValue = rdr1.GetValue(60).ToString
                        upload_sql.InsertParameters("RemarksofSubject").DefaultValue = rdr1.GetValue(61).ToString
                        upload_sql.InsertParameters("Attempt").DefaultValue = rdr1.GetValue(62).ToString
                        If rdr1.GetValue(63).ToString = "" Then
                            upload_sql.InsertParameters("ExamMonth").DefaultValue = Convert.ToDouble(rdr1.GetValue(63).ToString)
                        Else
                            upload_sql.InsertParameters("ExamMonth").DefaultValue = Convert.ToDouble(rdr1.GetValue(63).ToString)
                        End If

                        If rdr1.GetValue(64).ToString = "" Then
                            upload_sql.InsertParameters("ExamYear").DefaultValue = "NULL"
                        Else
                            upload_sql.InsertParameters("ExamYear").DefaultValue = Convert.ToInt32(rdr1.GetValue(64).ToString)
                        End If

                        upload_sql.InsertParameters("DateofResult").DefaultValue = doresult
                        upload_sql.InsertParameters("SPRemarks").DefaultValue = rdr1.GetValue(66).ToString

                        upload_sql.Insert()
                        ASPxGridView1.DataBind()
                    Catch ex As Exception

                        Label1.Text = "Invalid Data Entry. Please Check entered Data."
                        Exit Sub
                    End Try

                Loop
                rdr1.Close()
                con1.Close()
            End Using

            Label1.Text = "Data updated successfully."
            'Label1.ForeColor = Drawing.Color.Green

            ASPxGridView1.DataBind()
        Else
            Label1.Text = "File is either not Selected or is Empty."
            'Label1.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
    End Sub
End Class
