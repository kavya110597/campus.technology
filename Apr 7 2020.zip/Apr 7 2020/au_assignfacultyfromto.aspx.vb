﻿
Partial Class au_assignfacultyfromto
    Inherits System.Web.UI.Page

End Class
