﻿Imports System
Imports Telerik.Web.UI
Partial Class au_all_marks
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        For Each item As GridDataItem In RadGrid1.Items
            'Dim cell As TableCell = item("Marks")
            Dim textBox As RadTextBox = CType(item.FindControl("RadTextBox1"), RadTextBox)
            Dim textBox1 As RadTextBox = CType(item.FindControl("RadTextBox2"), RadTextBox)
            Dim btn2 As RadToggleButton = CType(item.FindControl("RadToggleButton1"), RadToggleButton)
            Dim studid As Integer = Convert.ToInt32(item("id").Text)
            Literal1.Text = Literal1.Text & id & " - " & textBox.Text & "<br>"
            Dim colid As Integer = Convert.ToInt32(Request.Cookies("colid").Value.ToString)

            Dim marks1 As Double
            Try
                marks1 = Convert.ToDouble(textBox.Text)
            Catch ex As Exception

            End Try

            Dim grade1 As String = textBox1.Text
            Dim status1 As String = btn2.SelectedToggleState.Value.ToString
            Dim examid As Integer = Convert.ToInt32(RadComboBox3.SelectedValue.ToString)

            SqlDataSource7.InsertParameters("colid").DefaultValue = colid

            SqlDataSource7.InsertParameters("examid").DefaultValue = examid
            SqlDataSource7.InsertParameters("studid").DefaultValue = studid
            SqlDataSource7.InsertParameters("marks1").DefaultValue = marks1
            SqlDataSource7.InsertParameters("grade1").DefaultValue = grade1
            SqlDataSource7.InsertParameters("STATUS1").DefaultValue = status1
            SqlDataSource7.Insert()
            Literal1.Text = "Marks / Grade updated."
        Next
    End Sub
End Class
