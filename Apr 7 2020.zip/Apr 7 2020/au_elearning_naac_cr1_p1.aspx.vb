﻿
Partial Class au_elearning_naac_cr1_p1
    Inherits System.Web.UI.Page

    Dim i As Integer

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            loadimage()

        End If
    End Sub
    Public Sub loadimage()
        'Image1.ImageUrl = "http://campus.technology/erpnew/faculty/elearning/naac-cr1/slide1.png"
        Image1.ImageUrl = "elearning/naac-cr1/slide1.png"
        i = 1
        Literal1.Text = "Screen " & i.ToString & " of 8"
        ViewState("i") = 1

    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim i As Integer = Convert.ToInt32(ViewState("i").ToString)

        If i < 8 Then
            i = i + 1
            ViewState("i") = i
            Literal1.Text = "Screen " & i.ToString & " of 8"
            Image1.ImageUrl = "elearning/naac-cr1/slide" & i.ToString & ".png"
        Else
            Response.Redirect("au_department.aspx")
        End If
        checkbuttons()

    End Sub
    Public Sub checkbuttons()
        If i = 8 Then
            Button2.Enabled = False
        Else
            Button2.Enabled = True
        End If
        If i = 1 Then
            Button1.Enabled = False
        Else
            Button1.Enabled = True

        End If
    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim i As Integer = Convert.ToInt32(ViewState("i").ToString)

        If i > 1 Then
            i = i - 1
            ViewState("i") = i
            Literal1.Text = "Screen " & i.ToString & " of 8"
            Image1.ImageUrl = "elearning/naac-cr1/slide" & i.ToString & ".png"
        End If
        checkbuttons()

    End Sub
End Class
