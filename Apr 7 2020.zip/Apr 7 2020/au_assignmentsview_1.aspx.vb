﻿Imports System.Data.SqlClient
Partial Class au_assignmentsview_1
    Inherits System.Web.UI.Page
    Public Function getpath(ByVal studid As Integer, ByVal assignmentid As Integer) As String
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString
        Dim a As String = String.Empty
        Dim em As String = ""
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "Select assignmentlink from au_studassignments where assignmentid=@assignmentid and studid=@studid"
            cmd1.Parameters.AddWithValue("@assignmentid", assignmentid)
            cmd1.Parameters.AddWithValue("@studid", studid)
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                em = rdr1.GetValue(0).ToString

            Loop
            rdr1.Close()
            con1.Close()
        End Using

        Return em

    End Function
    'Protected Sub DemoRichEdit_Callback(ByVal sender As Object, ByVal e As CallbackEventArgsBase)
    '    If FileManager.SelectedFile IsNot Nothing Then
    '        DemoRichEdit.Open(FileManager.SelectedFile.FullName)
    '    End If
    'End Sub
    'Protected Sub FileManager_FileUploading(ByVal sender As Object, ByVal e As FileManagerFileUploadEventArgs)
    '    e.Cancel = Utils.IsSiteMode
    '    e.ErrorText = Utils.GetReadOnlyMessageText()
    'End Sub
    Protected Sub DemoRichEdit_PreRender(ByVal sender As Object, ByVal e As EventArgs)
        DemoRichEdit.Focus()
    End Sub
    'Protected Sub FileManager_Load(ByVal sender As Object, ByVal e As EventArgs)
    '    If FileManager.Settings.RootFolder <> Server.MapPath(".") Then
    '        'String.Format("{0}\{1}\", Server.MapPath("."), "employee\files") Then
    '        'DirectoryManagmentUtils.DocumentBrowsingFolderPath Then
    '        'DirectoryManagmentUtils.AssertTimeout()
    '        'AssertTimeout()
    '    End If
    'End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Label1.Text = ""
        If RadComboBox1.SelectedIndex = -1 OrElse RadComboBox2.SelectedIndex = -1 OrElse RadComboBox3.SelectedIndex = -1 Then
            Label1.Text = "Please select assignment."
            Exit Sub
        End If
        ' "files/" & collegename & "/assignments/" & assignmentname & "/" & newfilename
        Dim studid As Integer
        studid = Convert.ToInt32(RadComboBox3.SelectedValue.ToString)
        ''Dim class As String = RadComboBox1.SelectedItem.Text.ToString
        Dim assignmentid As String = Convert.ToInt32(RadComboBox2.SelectedValue.ToString)
        'Dim path1 As String
        'path1 = "files/" & collegename & "/assignments/" & assignmentname & "/"
        'Dim dir1 As String = Server.MapPath(".") & "\files\" & collegename & "\assignments\" & assignmentname & "\"
        'If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
        '    My.Computer.FileSystem.CreateDirectory(dir1)
        'End If
        ''Dim path2 As String = Server.MapPath(".") & "\files\" & collegename & "\events\" & filename
        'Dim path3 As String = "~/" & path1
        'Literal1.Text = "Current Folder: " & path3


        Dim path1 As String
        Dim filepath As String = getpath(studid, assignmentid)
        If filepath = "" Then
            Label1.Text = "Assignment is not uploaded by the student."
            Exit Sub
        End If
        'Dim finalpath As String = Server.MapPath(".") & "\" & filepath.Replace("/", "\")
        Dim strnfilepath As String = "C:\inetpub\wwwroot\campus\erpnew\studentportal"
        Dim finalpath As String = strnfilepath & "\" & filepath.Replace("/", "\")
        Dim index As Integer = finalpath.LastIndexOf("\")
        If index > 0 Then
            path1 = finalpath.Substring(0, index)
        End If
        DemoRichEdit.Visible = True
        DemoRichEdit.Open(finalpath)
        'FileManager.Settings.RootFolder = Server.MapPath(".") & "\" & path1 & "\" 'path3
        'Try
        '    FileManager.Refresh()
        'Catch ex As Exception

        'End Try

        'FileManager.Enabled = True
        'FileManager.Visible = True
        'DemoRichEdit.Visible = True
        'Dim file As FileManagerFile = FileManager.SelectedFolder.GetFiles().FirstOrDefault()
        'If file IsNot Nothing Then
        '    FileManager.SelectedFile = file
        'DemoRichEdit.Open(file.FullName)
        'End If
    End Sub

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception

        End Try
    End Sub
End Class
