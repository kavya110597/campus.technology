﻿
Partial Class au_123report
    Inherits System.Web.UI.Page

End Class
