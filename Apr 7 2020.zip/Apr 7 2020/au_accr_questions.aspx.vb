﻿Imports System.IO
Imports System.Data.OleDb
Imports DevExpress.XtraPrinting
Imports Telerik.Web.UI
Imports System.Data
Imports System.Data.SqlClient

Partial Class au_accr_questions
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub


    Protected Sub ASPxButton1_Click(sender As Object, e As EventArgs) Handles ASPxButton1.Click
        Dim constr1 As String
        Dim path2 As String = "NAACQuestions.xlsx"
        constr1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & path2 & ";Extended Properties=""Excel 12.0 Xml;HDR=YES"";"
        Using con1 As New OleDbConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New OleDbCommand
            cmd1.Connection = con1
            cmd1.CommandText = "Select * from [Sheet1$]"
            Dim rdr1 As OleDbDataReader = cmd1.ExecuteReader

            Do While rdr1.Read



                Try

                    SqlDataSource1.InsertParameters("Accreditation").DefaultValue = rdr1.GetValue(0).ToString
                    SqlDataSource1.InsertParameters("Criteria").DefaultValue = rdr1.GetValue(1).ToString
                    SqlDataSource1.InsertParameters("QuestionNo").DefaultValue = rdr1.GetValue(2).ToString

                    SqlDataSource1.Insert()



                Catch ex As Exception
                    'Label1.Text = "Invalid Data Entry. Please check one or more data is in wrong format"
                    'Label1.ForeColor = Drawing.Color.Red
                    Exit Sub
                End Try

            Loop
            rdr1.Close()
            con1.Close()
        End Using

        ASPxGridView1.DataBind()

    End Sub
End Class
