﻿
Partial Class au_exam_paper_summary
    Inherits System.Web.UI.Page


    Dim c As Integer
    Dim basedir As String


    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        If Not Page.IsPostBack Then
            c = 0
        End If
    End Sub
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        Dim collegename As String
        Try
            collegename = Request.Cookies("collegename").Value.ToString
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try

        'Dim prog As String = RadComboBox1.SelectedItem.Text.ToString
        'Dim course As String = ASPxComboBox1.SelectedItem.Text.ToString
        Dim path1 As String
        'path1 = "files/" & collegename & "/ecampus/" & prog & "/" '& course & "/"
        'Literal1.Text = "<table id=""testTable"" border=""1"" cellspacing=""0"" cellpadding=""5""><tr><td>Sl. No.</td><td>Department/Program</td><td>File</td><td>Type</td></tr>"
        Literal1.Text = "<table id=""testTable"" border=""1"" cellspacing=""0"" cellpadding=""5""><tr><td>Sl. No.</td><td>Department/Program</td><td>File</td><td>Type</td><td>File Size (KB)</td><td>Comments</td></tr>"
        'Dim dir1 As String = Server.MapPath(".") & "\files\" & collegename & "\ecampus\" & prog & "\" '& course & "\"
        Dim dir1 As String = Server.MapPath(".") & "\files\" & collegename & "\exampapers\" ' & prog & "\" '& course & "\"
        basedir = Server.MapPath(".") & "\files\" & collegename & "\exampapers\"
        If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
            'My.Computer.FileSystem.CreateDirectory(dir1)
        Else

            checkfiles(dir1)
        End If
        Literal1.Text = Literal1.Text & "</table>"
        'Dim path2 As String = Server.MapPath(".") & "\files\" & collegename & "\events\" & filename
        'Dim path3 As String = "~/" & path1
        'Literal1.Text = "Current Folder: " & path3

        'ASPxFileManager1.Settings.RootFolder = dir1 'path3
        'Try
        '    ASPxFileManager1.Refresh()
        'Catch ex As Exception

        'End Try

        'ASPxFileManager1.Enabled = True
        'ASPxFileManager1.Visible = True
    End Sub
    Public Sub checkfiles(ByVal dir1 As String)
        'Literal1.Text = "<br><br>" & Literal1.Text & "<br>"
        'Literal1.Text = Literal1.Text & "<tr>"

        Dim d As String
        Dim dir2 As String = dir1.Replace(basedir, "")
        If dir2.Contains("\") Then
            Dim ar1() As String = dir2.Split("\")
            d = ar1(0).ToString
        Else
            d = dir2

        End If
        Dim filetype As String = ""
        If dir2.Contains("SessionPlan") Then
            filetype = "Session Plan"

        End If
        Dim i As Integer = 0

        'Literal1.Text = Literal1.Text & "<tr><td colspan=""3"">" & "Directory: " & dir1.Replace(basedir, "") & "</td></tr>"
        For Each f1 As String In My.Computer.FileSystem.GetFiles(dir1)
            i = i + 1
            Dim ok1 As String = "Format Ok. "
            'Literal1.Text = Literal1.Text & f1 & "<br>"
            If filetype = "" Then
                If f1.Contains("htm") Then
                    filetype = "Video/HTML"
                Else
                    filetype = "Content"
                End If
            End If
            If f1.Contains("pptx") OrElse f1.Contains("pdf") OrElse f1.Contains("htm") Then
            Else
                ok1 = "Incorrect file format. "
            End If
            Try
                If FileLen(f1) / 1000 > 400 Then
                    ok1 = ok1 & "File size exceeded."
                End If
            Catch ex As Exception
                ok1 = ok1 & "Invalid file name."
            End Try
            Dim size1 As String = "Too heavy"
            Try
                size1 = FileLen(f1) / 1000
            Catch ex As Exception

            End Try
            c = c + 1
            'i = i + 1
            'Literal1.Text = Literal1.Text & "<tr><td>" & c.ToString & "</td><td>" & d & "</td><td>" & f1.Replace(basedir, "") & "</td><td>" & filetype & "</td></tr>"
            Literal1.Text = Literal1.Text & "<tr><td>" & c.ToString & "</td><td>" & d & "</td><td>" & f1.Replace(basedir, "") & "</td><td>" & filetype & "</td><td>" & size1 & "</td><td>" & ok1 & "</td></tr>"
        Next
        'Literal1.Text = Literal1.Text & "</tr>"
        'Dim str1 As String
        'If i > 0 Then
        '    c = c + 1
        '    'str1 = "Summary:<br><br>Directory: " & dir1.Replace(basedir, "") & "<br>"
        '    'str1 = str1 & "Total files in this directory: " & i.ToString & "<br>"
        '    'Literal1.Text = Literal1.Text & "<tr><td colspan=""3"">" & str1 & "</td></tr>"
        '    'Literal1.Text = Literal1.Text & "<tr><td>" & c.ToString & "</td><td>" & dir1.Replace(basedir, "") & "</td><td>" & i.ToString & "</td></tr>"
        '    Literal1.Text = Literal1.Text & "<tr><td>" & c.ToString & "</td><td>" & d & "</td><td>" & dir1.Replace(basedir, "") & "</td><td>" & i.ToString & "</td></tr>"
        'End If
        'Literal1.Text = Literal1.Text & "<tr><td colspan=""3"">" & "Total files in this directory: " & i.ToString & "</td></tr>"
        For Each d1 As String In My.Computer.FileSystem.GetDirectories(dir1)
            checkfiles(d1)
        Next
    End Sub
End Class
