﻿
Partial Class au_capacity_bridge
    Inherits System.Web.UI.Page

End Class
