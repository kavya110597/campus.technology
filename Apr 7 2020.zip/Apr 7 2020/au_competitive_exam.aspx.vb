﻿
Partial Class au_competitive_exam
    Inherits System.Web.UI.Page

End Class
