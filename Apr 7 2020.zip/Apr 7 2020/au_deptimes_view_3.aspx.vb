﻿
Partial Class faculty_au_deptimes_view_3
    Inherits System.Web.UI.Page

    Protected Sub RadButton2_Click(sender As Object, e As EventArgs) Handles RadButton2.Click
        RadScheduler1.ExportToPdf()

    End Sub
End Class
