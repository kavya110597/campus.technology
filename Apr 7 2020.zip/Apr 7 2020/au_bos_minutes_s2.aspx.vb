﻿
Partial Class au_bos_minutes_s2
    Inherits System.Web.UI.Page

End Class
