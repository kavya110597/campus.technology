﻿
Partial Class au_accr_faculty
    Inherits System.Web.UI.Page

End Class
