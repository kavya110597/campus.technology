﻿
Partial Class au_bg_session
    Inherits System.Web.UI.Page

End Class
