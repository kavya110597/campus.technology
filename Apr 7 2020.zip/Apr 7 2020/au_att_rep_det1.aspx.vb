﻿
Partial Class au_att_rep_det1
    Inherits System.Web.UI.Page

End Class
