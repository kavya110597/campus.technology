﻿
Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Data.OleDb
Imports System.Drawing
Partial Class admin_att_count

    Inherits System.Web.UI.Page

    Protected Sub notifimessage(ByVal mesg As String)
        Page.ClientScript.RegisterStartupScript(Me.[GetType](), "Alert", "alert(' " & mesg & " ');", True)
    End Sub
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim cookie1 As HttpCookie = Request.Cookies("colid")
        If cookie1 Is Nothing Then
            Response.Redirect("adminlogin_attendance.aspx")
        Else


        End If
    End Sub
    Protected Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If GridView1.Rows.Count = 0 Then
            notifimessage("There is no data to export.")
            Exit Sub
        Else
            ExportToExcel()
        End If
    End Sub
    Public Sub ExportToExcel()
        Response.Clear()
        Response.Buffer = True
        Response.AddHeader("content-disposition", "attachment;filename=MyCustomReport.xls")
        Response.Charset = ""
        Response.ContentType = "application/vnd.ms-excel"
        Using sw As New StringWriter()
            Dim hw As New HtmlTextWriter(sw)

            ''To Export all pages
            GridView1.AllowPaging = False
            Me.BindGrid()

            GridView1.HeaderRow.BackColor = Color.White
            For Each cell As TableCell In GridView1.HeaderRow.Cells
                cell.BackColor = GridView1.HeaderStyle.BackColor
            Next
            For Each row As GridViewRow In GridView1.Rows
                row.BackColor = Color.White
                For Each cell As TableCell In row.Cells
                    If row.RowIndex Mod 2 = 0 Then
                        cell.BackColor = GridView1.AlternatingRowStyle.BackColor
                    Else
                        cell.BackColor = GridView1.RowStyle.BackColor
                    End If
                    cell.CssClass = "textmode"
                Next
            Next

            GridView1.RenderControl(hw)
            'style to format numbers to string
            Dim style As String = "<style> .textmode { } </style>"
            Response.Write(style)
            Response.Output.Write(sw.ToString())
            Response.Flush()
            Response.[End]()
        End Using
    End Sub

    Private Sub BindGrid()
        'Dim classid As Integer
        'Try
        '    classid = Convert.ToInt32(class_dlist.SelectedValue.ToString)
        'Catch ex As Exception

        'End Try
        Dim str As String = "SELECT a.studid, au_students.regno AS RegNo, au_students.firstname AS Name, au_students.mob AS Phone, au_students.email AS Email, a.programid, a.courseid, a.class_attended, b.total_class FROM (SELECT studid, programid, courseid, SUM(CASE WHEN attendancestatus = 1 THEN 1 ELSE 0 END) AS class_attended FROM nba_attendance WHERE (programid = @programid) AND (courseid = @courseid) GROUP BY studid, programid, courseid) AS a INNER JOIN (SELECT programid, courseid, COUNT(DISTINCT classid) AS total_class FROM nba_attendance AS nba_attendance_1 WHERE (programid = @programid) AND (courseid = @courseid) GROUP BY programid, courseid) AS b ON a.programid = b.programid AND a.courseid = b.courseid INNER JOIN au_students ON a.studid = au_students.Id"
        SqlDataSource1.SelectCommand = str
        GridView1.DataBind()

        'Dim strConnString As String = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        'Using con As New SqlConnection(strConnString)
        '    Using cmd As New SqlCommand("SELECT au_students.course, au_students.regno,au_students.name AS Name, au_students.mob AS Phone, au_students.email AS Email, nba_attendance.attendancestatus FROM au_students INNER JOIN nba_attendance ON au_students.Id = nba_attendance.studid WHERE (nba_attendance.classid = @classid)")
        '        Using sda As New SqlDataAdapter()
        '            cmd.Connection = con
        '            sda.SelectCommand = cmd
        '            cmd.Parameters.AddWithValue("@classid", classid).DbType = DbType.Int32
        '            Using dt As New DataTable()
        '                sda.Fill(dt)
        '                GridView1.DataSource = dt
        '                GridView1.DataBind()
        '            End Using
        '        End Using
        '    End Using
        'End Using
    End Sub

    Public Overrides Sub VerifyRenderingInServerForm(control As Control)
        ' Verifies that the control is rendered
    End Sub
End Class
