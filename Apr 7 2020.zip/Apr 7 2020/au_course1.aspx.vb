﻿
Partial Class au_course1
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim path1 As String
        Dim empid As String = Request.Cookies("nemployeeid").Value.ToString
        Dim path2 As String
        path2 = "Uploadimages\" & empid
        path1 = Server.MapPath(".") & "\" & path2
        If My.Computer.FileSystem.DirectoryExists(path1) Then
        Else
            My.Computer.FileSystem.CreateDirectory(path1)

        End If
        ASPxHtmlEditor1.SettingsDialogs.InsertImageDialog.SettingsImageUpload.FileSystemSettings.UploadFolder = "~/erpnew/faculty/" & path2.Replace("\", "/")
        'ASPxHtmlEditor1.SettingsHtmlEditing.AllowIFrames = True
        'ASPxHtmlEditor1.SettingsHtmlEditing.AllowHTML5MediaElements = True
        'ASPxHtmlEditor1.SettingsHtmlEditing.AllowScripts = True

    End Sub
    Protected Sub ASPxButton1_Click(sender As Object, e As EventArgs) Handles ASPxButton1.Click

        'ASPxHtmlEditor1.SettingsDialogs.InsertImageDialog.SettingsImageUpload.FileSystemSettings.UploadFolder=""
        Literal1.Text = ASPxHtmlEditor1.Html

    End Sub
End Class
