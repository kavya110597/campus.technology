﻿Imports Telerik.Web.UI.ExportInfrastructure
Imports Telerik.Web.UI
Imports System.Data
Imports System.Data.SqlClient
Partial Class faculty_au_521a
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try


        If Not Page.IsPostBack Then
            Dim collegename As String
            collegename = Request.Cookies("collegename").Value.ToString.Replace(" ", "")
            Dim type As String

            type = "Placement"
            'HyperLink3.NavigateUrl = "http://iqac.online/fileupload1.aspx?collegename=" & collegename & "&colid=" & colid & "&type=" & type & "&facultyid=" & facultyid
            HyperLink1.NavigateUrl = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type
            HyperLink1.Text = "http://iqac.online/files/" & collegename & "/" & colid & "/" & type

        End If

    End Sub

    Protected Sub RadGrid1_InfrastructureExporting(sender As Object, e As Telerik.Web.UI.GridInfrastructureExportingEventArgs) Handles RadGrid1.InfrastructureExporting

        Dim exportStructure As ExportStructure = e.ExportStructure

        Dim table As Telerik.Web.UI.ExportInfrastructure.Table = exportStructure.Tables(0)

        table.ShiftRowsDown(1, 1)

        table.Cells("A1").Value = "5.2.1 Average percentage of placement of outgoing students during the last five years  (20)"
        'table.Cells("A2").Value = "5.1 Student Support (50)"
        'table.Cells("A3").Value = "5.1.1 Average  percentage of students benefited by scholarships and freeships provided by the Government during the last five years  (12)"
        'table.Cells("A4").Value = "5.1.2 Average  percentage  of students benefited by scholarships, freeships, etc. provided by the institution besides government schemes during the last five years   (12)"

    End Sub
    Protected Sub RadButton1_Click(sender As Object, e As EventArgs) Handles RadButton1.Click
        Literal1.Text = ""
        Dim year1 As Double = 0
        Dim year2 As Double = 0
        Dim year3 As Double = 0
        Dim year4 As Double = 0
        Dim year5 As Double = 0
        Try
            year1 = RadNumericTextBox1.Value / RadNumericTextBox6.Value * 100
            year1 = Math.Round(year1, 2)
        Catch ex As Exception

        End Try
        Try
            year1 = RadNumericTextBox1.Value / RadNumericTextBox6.Value * 100
        Catch ex As Exception

        End Try
        Try
            year2 = RadNumericTextBox2.Value / RadNumericTextBox7.Value * 100
        Catch ex As Exception

        End Try
        Try
            year3 = RadNumericTextBox3.Value / RadNumericTextBox8.Value * 100
        Catch ex As Exception

        End Try
        Try
            year4 = RadNumericTextBox4.Value / RadNumericTextBox9.Value * 100
        Catch ex As Exception

        End Try
        Try
            year5 = RadNumericTextBox5.Value / RadNumericTextBox10.Value * 100
        Catch ex As Exception

        End Try
        Literal1.Text = "<h4>Summary</h4><br><br>"
        Literal1.Text = Literal1.Text & "Year 1 : " & getinterpretation(year1)
        Literal1.Text = Literal1.Text & "Year 2 : " & getinterpretation(year2)
        Literal1.Text = Literal1.Text & "Year 3 : " & getinterpretation(year3)
        Literal1.Text = Literal1.Text & "Year 4 : " & getinterpretation(year4)
        Literal1.Text = Literal1.Text & "Year 5 : " & getinterpretation(year5)

    End Sub
    Public Function getinterpretation(ByVal d1 As Double) As String
        Dim str1 As String = String.Empty
        If d1 <= 50 Then
            str1 = "Low Percentage. Current value " & Math.Round(d1, 2).ToString & "<br>"
        ElseIf d1 > 50 AndAlso d1 <= 70 Then
            str1 = "Medium Percentage. Current value " & Math.Round(d1, 2).ToString & "<br>"
        Else
            str1 = "Good Percentage. Current value " & Math.Round(d1, 2).ToString & "<br>"
        End If

        Return str1

    End Function
    Protected Sub ASPxButton1_Click(sender As Object, e As EventArgs) Handles ASPxButton1.Click
        Label1.Text = ""
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        Dim empid As Integer = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
        Dim str1 As String
        str1 = "Update au_accr_status set status='Completed',empid='" & empid & "' where colid='" & colid & "' and accr='NAAC' and questions='5.2.1' and type1='ACollege' and cr='5'"
        Dim c1 As Integer = update1(str1)
        If c1 = 0 Then
            str1 = "Insert into au_accr_status(status,empid,colid,accr,questions,type1,cr) values('Completed','" & empid & "','" & colid & "','NAAC','5.2.1','ACollege','5')"
            c1 = update1(str1)
        End If
        Label1.Text = "Status is updated"
    End Sub
    Protected Sub ASPxButton2_Click(sender As Object, e As EventArgs) Handles ASPxButton2.Click
        Label1.Text = ""
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        Dim empid As Integer = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
        Dim str1 As String
        str1 = "Update au_accr_status set status='Pending',empid='" & empid & "' where colid='" & colid & "' and accr='NAAC' and questions='5.2.1' and type1='ACollege' and cr='5'"
        Dim c1 As Integer = update1(str1)
        If c1 = 0 Then
            str1 = "Insert into au_accr_status(status,empid,colid,accr,questions,type1,cr) values('Pending','" & empid & "','" & colid & "','NAAC','5.2.1','ACollege','5')"
            c1 = update1(str1)
        End If
        Label1.Text = "Status is updated"
    End Sub
    Public Function update1(ByVal str1 As String) As Integer
        Dim c1 As Integer = 0
        Dim constr1 As String

        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = str1
            c1 = cmd1.ExecuteNonQuery

            con1.Close()
        End Using
        Return c1

    End Function

End Class