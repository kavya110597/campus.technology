﻿Imports System.IO
Imports System.Net
Imports System.Data
Imports System.Data.SqlClient
Partial Class au_clg_eventedit
    Inherits System.Web.UI.Page
    Protected Sub btnUpload_Click(sender As Object, e As EventArgs)
        If FileUpload1.HasFile Then
            'FileUpload1.SaveAs(MapPath("~/students/" + FileUpload1.FileName))
            'Dim filename As String = Path.GetFileName(FileUpload1.FileName)
            'Dim path1 As String = "~/students/" + FileUpload1.FileName
            'Dim str1 As String = "Insert into ajaxfileupload(filename,filelink) Values(@filename,@filelink)"
            'insertdata(str1, filename, path1)


            Dim filename As String
            Dim path1 As String
            Dim collegename As String = Request.Cookies("collegename").Value.ToString
            If FileUpload1.HasFile Then
                filename = Path.GetFileName(FileUpload1.FileName)
                path1 = "files/" & collegename & "/events/" & filename
                Dim dir1 As String = Server.MapPath(".") & "\files\" & collegename & "\events\"
                If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                    My.Computer.FileSystem.CreateDirectory(dir1)
                End If
                Dim path2 As String = Server.MapPath(".") & "\files\" & collegename & "\events\" & filename

                FileUpload1.SaveAs(path2)

                Dim colid, eventid As Integer
                colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
                eventid = Convert.ToInt32(Request.QueryString("id").ToString)
                Dim str1 As String = "Insert into au_clg_eventfile(colid,eventid,filename,filelink,status,type1,description) Values('" & colid & "','" & eventid & "',@filename,@filelink,'Uploaded','" & DropDownList1.SelectedValue.ToString & "',@description)"
                insertdata(str1, filename, path1, TextBox8.Text)
                Gridviewfile.DataBind()

            End If





        End If
    End Sub

    Protected Sub insertdata(ByVal str1 As String, ByVal filename As String, ByVal path1 As String, ByVal description As String)

        Using con1 As New SqlConnection
            con1.ConnectionString = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1

            cmd1.CommandText = str1
            cmd1.Parameters.AddWithValue("@filename", filename).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@filelink", path1).DbType = DbType.String
            cmd1.Parameters.AddWithValue("@description", description).DbType = DbType.String
            cmd1.ExecuteNonQuery()

            con1.Close()
        End Using

    End Sub

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'Dim programid As Integer = Convert.ToInt32(DropDownList1.SelectedValue.ToString)
        'Dim courseid As Integer = Convert.ToInt32(DropDownList2.SelectedValue.ToString)
        Dim colid As Integer = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Dim eventid As Integer = Convert.ToInt32(Request.QueryString("id").ToString)
        SqlDataSource3.InsertParameters("colid").DefaultValue = colid
        SqlDataSource3.InsertParameters("eventid").DefaultValue = eventid
        SqlDataSource3.InsertParameters("billnumber").DefaultValue = TextBox1.Text
        SqlDataSource3.InsertParameters("particulars").DefaultValue = TextBox2.Text
        SqlDataSource3.InsertParameters("amount").DefaultValue = Convert.ToDouble(TextBox3.Text)

        SqlDataSource3.Insert()

        GridView1.DataBind()
    End Sub
End Class
