﻿Imports System.Data.SqlClient
Imports System.Data

Partial Class au_co_generator
    Inherits System.Web.UI.Page

    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If RadComboBox2.SelectedIndex = -1 Then
            Exit Sub
        End If
        Dim ls1 As New ListBox
        Dim ls2 As New ListBox
        Dim ls3 As New ListBox

        ls1.Items.Add("Describe")
        ls1.Items.Add("Learn")
        ls1.Items.Add("Understand")
        ls1.Items.Add("Identify")
        ls1.Items.Add("Specify")
        ls1.Items.Add("Write down")
        ls1.Items.Add("Know")

        ls2.Items.Add("in details")
        ls2.Items.Add("the characteristics of")
        ls2.Items.Add("the details of")
        ls2.Items.Add("the classification and characteristics of")
        ls2.Items.Add("in depth")
        ls2.Items.Add("in details with examples")
        ls2.Items.Add("in details with application, if applicable, ")

        Dim str1 As String
        If TextBox1.Text = "" Then
        Else

            str1 = ls1.Items(GetRandom(1, 7)).Text & " " & ls2.Items(GetRandom(1, 7)).Text & " " & TextBox1.Text
        End If

        Dim i As Integer = getNumberOfCO(Convert.ToInt32(RadComboBox2.SelectedValue.ToString)) + 1

        SqlDataSource4.InsertParameters("name").DefaultValue = str1
        SqlDataSource4.InsertParameters("code").DefaultValue = "CO" & i.ToString
        SqlDataSource4.InsertParameters("group").DefaultValue = "2019"
        SqlDataSource4.Insert()

        ASPxGridView1.DataBind()

    End Sub

    Public Function GetRandom(ByVal Min As Integer, ByVal Max As Integer) As Integer
        ' by making Generator static, we preserve the same instance '
        ' (i.e., do not create new instances with the same seed over and over) '
        ' between calls '
        Static Generator As System.Random = New System.Random()
        Return Generator.Next(Min, Max)
    End Function
    Public Function getNumberOfCO(ByVal courseid As Integer) As Integer
        Dim i1 As Integer = -1
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "Select count(*) from au_po where courseid=" & courseid & " and type='CO'"
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                i1 = Convert.ToInt32(rdr1.GetValue(0).ToString)
            Loop
            rdr1.Close()
            con1.Close()
        End Using
        Return i1

    End Function
End Class
