﻿Imports System.Data
Imports System.Data.SqlClient


Partial Class au_enrollment_form
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim collegename As String
        Try
            collegename = Request.Cookies("collegename").Value.ToString
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")

        End Try
        Literal1.Text = collegename
        Literal2.Text = collegename

        Dim photos1 As String
        Dim studid As Integer
        Try
            studid = Convert.ToInt32(Request.QueryString("studid").ToString)
        Catch ex As Exception
            Exit Sub
        End Try
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString

        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "Select photos1 from au_students where id=" & studid
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                Image1.ImageUrl = "http://campus.technology/erpnew/studentportal/" & rdr1.GetValue(0).ToString
            Loop
            rdr1.Close()
            con1.Close()
        End Using

    End Sub
End Class
