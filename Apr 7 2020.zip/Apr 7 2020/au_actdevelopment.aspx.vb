﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Data.OleDb
Imports System.Drawing
Partial Class au_actdevelopment
    Inherits System.Web.UI.Page
    Protected Sub Button10_Click(sender As Object, e As EventArgs) Handles Button10.Click
        LRef.Text = ""
        If TBprogram.Text = "" OrElse TBstartdate3.Text = "" OrElse TBenddate3.Text = "" OrElse TBorganizedby.Text = "" OrElse TBsponsered.Text = "" OrElse TBuniversity.Text = "" Then
            LRef.Text = "Please enter all details."
            LRef.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        If IsDate(TBstartdate3.Text) = False OrElse IsDate(TBenddate3.Text) = False Then
            LRef.Text = "Invalid Date."
            LRef.ForeColor = Drawing.Color.Red
            Exit Sub
        End If
        Dim startdate As Date = Convert.ToDateTime(TBstartdate3.Text)
        Dim enddate As Date = Convert.ToDateTime(TBenddate3.Text)
        If Format(startdate, "MM/DD/YYYY") > Format(enddate, "MM/DD/YYYY") Then
            LRef.Text = "Invalid Date."
            LRef.ForeColor = Drawing.Color.Red
            Exit Sub
        End If

        If FileUploaddevelop.HasFile Then
            Dim file As HttpPostedFile = FileUploaddevelop.PostedFile
            Dim filesize As Integer = file.ContentLength
            If filesize > 1000000 Then
                LRef.Text = "File exceeds the maximum size limit i.e. 1MB"
                LRef.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim extensionlist() As String = {".doc", ".docx", ".jpeg", ".gif", ".png", ".pdf", ".jpg"}
            Dim filename As String = Path.GetFileName(FileUploaddevelop.FileName)
            Dim extension As String = Path.GetExtension(filename)

            If extensionlist.Contains(extension) = False Then
                LRef.Text = "Invalid file extension.Please upload .doc or .pdf or .jpeg or .png or .jpg or .gif"
                LRef.ForeColor = Drawing.Color.Red
                Exit Sub
            End If


            Dim path1 As String = "students/photos/" & filename
            Dim dir1 As String = Server.MapPath(".") & "\students\photos"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If
            Dim path2 As String = Server.MapPath(".") & "\students\photos\" & filename
            FileUploaddevelop.SaveAs(path2)
            SqlDataSource17.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
            SqlDataSource17.InsertParameters("empid").DefaultValue = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
            SqlDataSource17.InsertParameters("program").DefaultValue = TBprogram.Text
            SqlDataSource17.InsertParameters("startdate").DefaultValue = Convert.ToDateTime(TBstartdate3.Text)
            SqlDataSource17.InsertParameters("enddate").DefaultValue = Convert.ToDateTime(TBenddate3.Text)
            SqlDataSource17.InsertParameters("organizedby").DefaultValue = TBorganizedby.Text
            SqlDataSource17.InsertParameters("university").DefaultValue = TBuniversity.Text
            SqlDataSource17.InsertParameters("sponser").DefaultValue = TBsponsered.Text
            SqlDataSource17.InsertParameters("level").DefaultValue = DropDownList3.SelectedValue.ToString()
            SqlDataSource17.InsertParameters("type").DefaultValue = DropDownList4.SelectedValue.ToString()
            SqlDataSource17.InsertParameters("certificate").DefaultValue = path1
            SqlDataSource17.Insert()
            LRef.Text = "Refresher/Development Program(s) Added."
            LRef.ForeColor = Drawing.Color.Green
            GridView3.DataBind()

        Else
            SqlDataSource17.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
            SqlDataSource17.InsertParameters("empid").DefaultValue = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
            SqlDataSource17.InsertParameters("program").DefaultValue = TBprogram.Text
            SqlDataSource17.InsertParameters("startdate").DefaultValue = Convert.ToDateTime(TBstartdate3.Text)
            SqlDataSource17.InsertParameters("enddate").DefaultValue = Convert.ToDateTime(TBenddate3.Text)
            SqlDataSource17.InsertParameters("organizedby").DefaultValue = TBorganizedby.Text
            SqlDataSource17.InsertParameters("university").DefaultValue = TBuniversity.Text
            SqlDataSource17.InsertParameters("sponser").DefaultValue = TBsponsered.Text
            SqlDataSource17.InsertParameters("level").DefaultValue = DropDownList3.SelectedValue.ToString()
            SqlDataSource17.InsertParameters("type").DefaultValue = DropDownList4.SelectedValue.ToString()
            SqlDataSource17.Insert()
            LRef.Text = "Refresher/Development Program(s) Added."
            LRef.ForeColor = Drawing.Color.Green
            GridView3.DataBind()
        End If

    End Sub
    Private Sub GridView3_RowCommand(sender As Object, e As GridViewCommandEventArgs) Handles GridView3.RowCommand
        Labeldevelop.Text = ""
        LRef.Text = ""
        If e.CommandName = "save" Then
            Dim rowid As Integer = Convert.ToInt32(e.CommandArgument.ToString)
            Dim lbl1 As Label = CType(GridView3.Rows(rowid).FindControl("Labelid2develop"), Label)
            Dim fileid As Integer = Convert.ToInt32(lbl1.Text.ToString)
            Dim FileUploadsave As FileUpload
            FileUploadsave = CType(GridView3.Rows(rowid).FindControl("FileUploadcertidevelop"), FileUpload)
            Dim filename As String = ""
            Dim path1 As String = ""

            If FileUploadsave.HasFile Then
                Dim file As HttpPostedFile = FileUploadsave.PostedFile
                Dim filesize As Integer = file.ContentLength
                If filesize > 1000000 Then
                    Labeldevelop.Text = "File exceeds the maximum size limit i.e. 1MB"
                    Labeldevelop.ForeColor = Drawing.Color.Red
                    Exit Sub
                End If
                Dim extensionlist() As String = {".doc", ".docx", ".jpeg", ".gif", ".png", ".pdf", ".jpg"}
                filename = Path.GetFileName(FileUploadsave.FileName)
                Dim extension As String = Path.GetExtension(filename)

                If extensionlist.Contains(extension) = False Then
                    Labeldevelop.Text = "Invalid file extension.Please upload .doc or .pdf or .jpeg or .png or .jpg or .gif"
                    Labeldevelop.ForeColor = Drawing.Color.Red
                    Exit Sub
                End If
                path1 = "students/photos/" & filename
                Dim dir1 As String = Server.MapPath(".") & "\students\photos\"
                If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                    My.Computer.FileSystem.CreateDirectory(dir1)
                End If
                Dim path2 As String = Server.MapPath(".") & "\students\photos\" & filename

                FileUploadsave.SaveAs(path2)


            End If
            Dim str1 As String
            str1 = "Update activity_refresher set certificate=@path1 where Id=@id"
            updatedata(str1, path1, fileid)
            Labeldevelop.Text = "File Uploaded."
            Labeldevelop.ForeColor = Drawing.Color.Green
            GridView3.DataBind()

        End If
    End Sub
    Protected Sub BRefExcel_Click(sender As Object, e As EventArgs) Handles BRefExcel.Click
        LRef.Text = ""
        If FileUpload3.HasFile Then
            Dim file As HttpPostedFile = FileUpload3.PostedFile
            Dim filesize As Integer = file.ContentLength
            If filesize > 4194304 Then
                LRef.Text = "File exceeds the maximum size limit i.e. 4MB"
                LRef.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim filename As String = Path.GetFileName(FileUpload3.FileName)
            Dim extension As String = Path.GetExtension(filename)


            If extension <> ".xls" AndAlso extension <> ".xlsx" Then
                LRef.Text = "Invalid file extension.Please upload .xls or .xlsx file"
                LRef.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim path1 As String = "employee/photos/" & filename
            Dim dir1 As String = Server.MapPath(".") & "\employee\files"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If
            Dim path2 As String = Server.MapPath(".") & "\employee\files\" & filename

            FileUpload3.SaveAs(path2)


            Dim constr1 As String

            constr1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & path2 & ";Extended Properties=""Excel 12.0 Xml;HDR=YES"";"
            Using con1 As New OleDbConnection
                con1.ConnectionString = constr1
                con1.Open()
                Dim cmd1 As New OleDbCommand
                cmd1.Connection = con1
                cmd1.CommandText = "Select * from [Sheet1$]"
                Dim rdr1 As OleDbDataReader = cmd1.ExecuteReader

                Do While rdr1.Read


                    Dim startdate As Date
                    Try
                        startdate = Convert.ToDateTime(rdr1.GetValue(1).ToString)

                    Catch ex As Exception
                        LRef.Text = "Invalid Start Date."
                        LRef.ForeColor = Drawing.Color.Red
                        Exit Sub
                    End Try
                    Dim enddate As Date
                    Try
                        enddate = Convert.ToDateTime(rdr1.GetValue(2).ToString)

                    Catch ex As Exception
                        LRef.Text = "Invalid End Date."
                        LRef.ForeColor = Drawing.Color.Red
                        Exit Sub
                    End Try
                    If (DateAndTime.Year(startdate)) < 1950 OrElse (DateAndTime.Year(enddate)) > 2020 Then
                        LRef.Text = "Invalid Date Range."
                        LRef.ForeColor = Drawing.Color.Red
                        Exit Sub
                    End If

                    SqlDataSource17.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
                    SqlDataSource17.InsertParameters("empid").DefaultValue = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
                    SqlDataSource17.InsertParameters("program").DefaultValue = rdr1.GetValue(0).ToString
                    SqlDataSource17.InsertParameters("startdate").DefaultValue = startdate
                    SqlDataSource17.InsertParameters("enddate").DefaultValue = enddate
                    SqlDataSource17.InsertParameters("organizedby").DefaultValue = rdr1.GetValue(3).ToString
                    SqlDataSource17.InsertParameters("university").DefaultValue = rdr1.GetValue(7).ToString
                    SqlDataSource17.InsertParameters("sponser").DefaultValue = rdr1.GetValue(4).ToString
                    SqlDataSource17.InsertParameters("level").DefaultValue = rdr1.GetValue(6).ToString
                    SqlDataSource17.InsertParameters("type").DefaultValue = rdr1.GetValue(5).ToString
                    SqlDataSource17.Insert()

                    GridView3.DataBind()



                Loop
                rdr1.Close()
                con1.Close()
            End Using

            LRef.Text = "Refresher/Development Program(s) Added."
            LRef.ForeColor = Drawing.Color.Green
            GridView3.DataBind()
        Else
            LRef.Text = "File is either not Selected or is Empty."
            LRef.ForeColor = Drawing.Color.Red
            Exit Sub
        End If

    End Sub
    Public Sub updatedata(ByVal str As String, ByVal path1 As String, ByVal rowid As Integer)
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = str

            cmd1.Parameters.AddWithValue("@id", rowid).DbType = DbType.Int32
            cmd1.Parameters.AddWithValue("@path1", path1).DbType = DbType.String
            cmd1.ExecuteNonQuery()
            con1.Close()

        End Using
    End Sub
End Class
