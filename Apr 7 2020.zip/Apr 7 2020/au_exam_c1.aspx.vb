﻿Imports System.Data.SqlClient
Imports System.Data
Imports DevExpress.Spreadsheet

Partial Class au_exam_c1
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Label1.Text = ""
        If TextBox1.Text = "" Then
            Label1.Text = "Please enter batch."
            Exit Sub
        End If
        If ASPxComboBox1.SelectedIndex = -1 Then
            Label1.Text = "Please select course."
            Exit Sub
        End If
        Label1.Text = ""
        Dim collegename As String = Request.Cookies("collegename").Value.ToString
        Dim dir1 As String = Server.MapPath(".") & "\workdirectory\" & collegename & "\"
        If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
            My.Computer.FileSystem.CreateDirectory(dir1)
        End If
        ASPxSpreadsheet1.WorkDirectory = dir1

        If DropDownList1.SelectedIndex = -1 Then
            Label1.Text = "Please select program."
            Exit Sub
        End If
        Dim progid As Integer = Convert.ToInt32(DropDownList1.SelectedValue.ToString)
        Dim depid As Integer = Convert.ToInt32(DropDownList7.SelectedValue.ToString)
        Dim courseid As Integer = Convert.ToInt32(ASPxComboBox1.Value.ToString)
        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1

            cmd1.CommandText = "Select id, examname, examcode,dateconducted, batch, location, type, [external] from au_exam_code where courseid=" & courseid & " and progid=" & progid & " and batch='" & TextBox1.Text & "'"
            cmd1.CommandText = "Select id, examname, examcode,dateconducted, location, type, [external] from au_exam_code where courseid=" & courseid & " and progid=" & progid & " and batch='" & TextBox1.Text & "'"

            Dim da As SqlDataAdapter = New SqlDataAdapter(cmd1)
            Dim ds As New DataSet
            da.Fill(ds, "Fees")
            'ASPxSpreadsheet1.Document.Worksheets.ActiveWorksheet.import(ds.Tables(0), True, 0, 0)
            Dim workbook As IWorkbook = ASPxSpreadsheet1.Document
            ' Load the template document into the SpreadsheetControl.
            workbook.LoadDocument(Server.MapPath(".") & "\exam_template1.xlsx")
            Dim sheet As Worksheet = workbook.Worksheets(0)
            ' Load data from the "Suppliers" data table into the worksheet starting from the cell "B12".
            sheet.DataBindings.BindToDataSource(ds.Tables(0), 9, 1)

            con1.Close()
        End Using
        Panel1.Visible = True
        Dim worksheet As Worksheet = ASPxSpreadsheet1.Document.Worksheets.ActiveWorksheet
        worksheet.Cells(0, 1).Value = collegename & " - " & worksheet.Cells(0, 1).Value.ToString
        worksheet.Cells(2, 2).Value = DropDownList2.SelectedItem.Text
        worksheet.Cells(3, 2).Value = DropDownList7.SelectedItem.Text
        worksheet.Cells(4, 2).Value = DropDownList1.SelectedItem.Text
        worksheet.Cells(5, 2).Value = ASPxComboBox1.SelectedItem.Text

    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Label1.Text = ""
        If TextBox1.Text = "" Then
            Label1.Text = "Please enter batch."
            Exit Sub
        End If
        If ASPxComboBox1.SelectedIndex = -1 Then
            Label1.Text = "Please Select course."
            Exit Sub
        End If
        Dim worksheet As Worksheet = ASPxSpreadsheet1.Document.Worksheets.ActiveWorksheet
        Dim j As Integer = 0
        Dim amount As Integer
        Dim duedate As DateTime
        Dim id As Integer = -1
        ribbonchange()


        Dim progid As Integer = Convert.ToInt32(DropDownList1.SelectedValue.ToString)
        Dim colid As Integer = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Dim depid As Integer = Convert.ToInt32(DropDownList7.SelectedValue.ToString)
        Dim courseid As Integer = Convert.ToInt32(ASPxComboBox1.Value.ToString)
        Dim batch As String = TextBox1.Text
        For i = 9 To 100
            Try
                id = Convert.ToInt32(worksheet.Cells(i, 1).Value.ToString)
            Catch ex As Exception

            End Try


            Dim examname As String = worksheet.Cells(i, 2).Value.ToString
            Dim examcode As String = worksheet.Cells(i, 3).Value.ToString

            Try
                duedate = Convert.ToDateTime(worksheet.Cells(i, 4).Value.ToString)
                'Dim ar1() As String = worksheet.Cells(i, 5).Value.ToString.Split("/")
                'duedate = Convert.ToDateTime(ar1(0).ToString & "/" & ar1(1).ToString & "/" & Mid(ar1(2).ToString, 1, 4))
                'duedate = Convert.ToDateTime(worksheet.Cells(i, 6).Value.ToString & "/" & worksheet.Cells(i, 5).Value.ToString & "/" & worksheet.Cells(i, 7).Value.ToString)
                worksheet.Cells(i, 4).FillColor = Drawing.Color.White
            Catch ex As Exception
                worksheet.Cells(i, 4).FillColor = Drawing.Color.Orange
                Continue For
            End Try

            Dim location As String = worksheet.Cells(i, 5).Value.ToString
            Dim type As String = worksheet.Cells(i, 6).Value.ToString
            Dim external As String = worksheet.Cells(i, 7).Value.ToString

            If id > -1 Then
                SqlDataSource18.UpdateParameters("colid").DefaultValue = colid
                SqlDataSource18.UpdateParameters("progid").DefaultValue = progid
                SqlDataSource18.UpdateParameters("depid").DefaultValue = depid
                SqlDataSource18.UpdateParameters("courseid").DefaultValue = courseid
                SqlDataSource18.UpdateParameters("examname").DefaultValue = examname
                SqlDataSource18.UpdateParameters("examcode").DefaultValue = examcode
                SqlDataSource18.UpdateParameters("dateconducted").DefaultValue = duedate
                SqlDataSource18.UpdateParameters("batch").DefaultValue = batch
                SqlDataSource18.UpdateParameters("location").DefaultValue = location
                SqlDataSource18.UpdateParameters("type").DefaultValue = type
                SqlDataSource18.UpdateParameters("external").DefaultValue = external
                SqlDataSource18.UpdateParameters("id").DefaultValue = id
                SqlDataSource18.Update()

            Else
                SqlDataSource18.InsertParameters("colid").DefaultValue = colid
                SqlDataSource18.InsertParameters("progid").DefaultValue = progid
                SqlDataSource18.InsertParameters("depid").DefaultValue = depid
                SqlDataSource18.InsertParameters("courseid").DefaultValue = courseid
                SqlDataSource18.InsertParameters("examname").DefaultValue = examname
                SqlDataSource18.InsertParameters("examcode").DefaultValue = examcode
                SqlDataSource18.InsertParameters("dateconducted").DefaultValue = duedate
                SqlDataSource18.InsertParameters("batch").DefaultValue = batch
                SqlDataSource18.InsertParameters("location").DefaultValue = location
                SqlDataSource18.InsertParameters("type").DefaultValue = type
                SqlDataSource18.InsertParameters("external").DefaultValue = external


                SqlDataSource18.Insert()

            End If

            j = j + 1
        Next
        Label1.Text = "Request has been processed. " & j.ToString & " records updated."
    End Sub
    Public Function checkfeesitem(ByVal feeitem As String) As Boolean
        Label1.Text = ""
        If ASPxComboBox1.SelectedIndex = -1 Then
            Label1.Text = "Please Select course."
            Exit Function
        End If
        Dim t1 As Boolean = False
        Dim constr1 As String
        Dim progid As Integer = Convert.ToInt32(DropDownList1.SelectedValue.ToString)
        constr1 = ConfigurationManager.ConnectionStrings("constr1").ConnectionString
        Dim id1 As String = "-1"
        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "Select id from au_fees_items where progid=" & progid & " And feeitem='" & feeitem & "'"
            'cmd1.CommandText = "Select id as ID, feeitem as FeeItem, amount as Amount, Datepart(dd,duedate) as Day, Datepart(mm,duedate) as Month, datepart(yyyy,duedate) as Year, description as Batch from au_fees_items where progid=" & progid
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                id1 = rdr1.GetValue(0).ToString
            Loop
            rdr1.Close()

            con1.Close()
        End Using
        If id1 = "-1" Then
            t1 = False
        Else
            t1 = True
        End If
        Return t1

    End Function
    Public Sub ribbonchange()
        ASPxSpreadsheet1.RibbonTabs(0).Groups(0).Items(0).ClientEnabled = False
        ASPxSpreadsheet1.RibbonTabs(0).Groups(0).Items(1).ClientEnabled = False
        ASPxSpreadsheet1.RibbonTabs(0).Groups(0).Items(2).ClientEnabled = False
    End Sub
End Class
