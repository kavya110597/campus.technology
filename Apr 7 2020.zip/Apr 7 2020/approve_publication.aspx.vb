﻿
Partial Class approve_publication
    Inherits System.Web.UI.Page

    Protected Sub Btn_aprv_Click(sender As Object, e As EventArgs) Handles Btn_aprv.Click

        If DropDownListFaculty_name.SelectedItem.Text = "--Select--" Then
            Response.Write("<script type='text/javascript'>alert('Please select a Department! ');</script>")
        End If

        Dim colid As Integer = Convert.ToInt32(Request.Cookies("colid").Value)
        ' Dim fid As Integer = DropDownListFaculty_name.SelectedValue

        For Each gr As GridViewRow In GridView1.Rows
            Dim chk1 As CheckBox = gr.FindControl("CheckBox2")
            If chk1 IsNot Nothing AndAlso chk1.Checked Then
                Dim pid As Integer = gr.Cells(1).Text

                Dim str1 As String
                str1 = "Update activity_pub set approvestatus='Approved' where colid=" & colid & "and Id=" & pid
                Dim cs1 As New schoolclass1
                cs1.insertdata(str1)

            End If
        Next
        GridView1.DataBind()

        Response.Write("<script type='text/javascript'>alert('Successfully Approved!');</script>")
    End Sub

    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        If DropDownListFaculty_name.SelectedItem.Text = "--Select--" Then
            Response.Write("<script type='text/javascript'>alert('Please select a Department! ');</script>")
        End If

        Dim colid As Integer = Convert.ToInt32(Request.Cookies("colid").Value)
        ' Dim fid As Integer = DropDownListFaculty_name.SelectedValue

        For Each gr As GridViewRow In GridView1.Rows
            Dim chk1 As CheckBox = gr.FindControl("CheckBox2")
            If chk1 IsNot Nothing AndAlso chk1.Checked Then
                Dim pid As Integer = gr.Cells(1).Text

                Dim str1 As String
                str1 = "Update activity_pub set approvestatus='Inactive' where colid=" & colid & "and Id=" & pid
                Dim cs1 As New schoolclass1
                cs1.insertdata(str1)

            End If
        Next
        GridView1.DataBind()

        Response.Write("<script type='text/javascript'>alert('Inactive Status Added Successfully!');</script>")
    End Sub
    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Dim cookie1 As HttpCookie = Request.Cookies("colid")
        If cookie1 Is Nothing Then
            Response.Redirect("activities_approvallogin.aspx")
        Else


        End If
    End Sub


    Protected Sub RowDataBound(ByVal sender As Object, ByVal e As GridViewRowEventArgs)
        If e.Row.RowType = DataControlRowType.DataRow Then
            e.Row.Attributes.Add("onmouseover", "MouseEvents(this, event)")
            e.Row.Attributes.Add("onmouseout", "MouseEvents(this, event)")

        End If
    End Sub


End Class
