﻿Imports Telerik.Web.UI.ExportInfrastructure
Imports Telerik.Web.UI

Partial Class au_113n
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub
    Protected Sub RadGrid1_InfrastructureExporting(sender As Object, e As Telerik.Web.UI.GridInfrastructureExportingEventArgs) Handles RadGrid1.InfrastructureExporting

        Dim exportStructure As ExportStructure = e.ExportStructure

        Dim table As Telerik.Web.UI.ExportInfrastructure.Table = exportStructure.Tables(0)

        table.ShiftRowsDown(1, 1)

        table.Cells("A1").Value = "1.2.3 Average percentage of students enrolled in subject related Certificate/ Diploma /Add-on programs  as against the total number of students during the last five years (10)"
        'table.Cells("A2").Value = "1.3.2 Number of value-added courses imparting  transferable and life skills  offered during the last five years (15)"
        'table.Cells("A3").Value = "1.1.2 Number of certificate/diploma program introduced during last five years (5)"

    End Sub
    Protected Sub RadGrid2_InfrastructureExporting(sender As Object, e As Telerik.Web.UI.GridInfrastructureExportingEventArgs) Handles RadGrid2.InfrastructureExporting

        Dim exportStructure As ExportStructure = e.ExportStructure

        Dim table As Telerik.Web.UI.ExportInfrastructure.Table = exportStructure.Tables(0)

        table.ShiftRowsDown(1, 2)

        table.Cells("A1").Value = "1.3 Curriculum Enrichment (30)"
        table.Cells("A2").Value = "1.3.2 Number of value-added courses imparting  transferable and life skills  offered during the last five years (15)"
        'table.Cells("A3").Value = "1.1.2 Number of certificate/diploma program introduced during last five years (5)"

    End Sub
    Protected Sub RadGrid3_InfrastructureExporting(sender As Object, e As Telerik.Web.UI.GridInfrastructureExportingEventArgs) Handles RadGrid3.InfrastructureExporting

        Dim exportStructure As ExportStructure = e.ExportStructure

        Dim table As Telerik.Web.UI.ExportInfrastructure.Table = exportStructure.Tables(0)

        table.ShiftRowsDown(1, 1)

        table.Cells("A1").Value = "1.3.3 Percentage  of students undertaking field projects / internships (5)"
        'table.Cells("A2").Value = "1.3.2 Number of courses imparting  transferable and life skills  offered during the last five years (15)"

    End Sub
End Class
