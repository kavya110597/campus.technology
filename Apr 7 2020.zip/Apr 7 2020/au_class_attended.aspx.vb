﻿
Partial Class au_class_attended
    Inherits System.Web.UI.Page

End Class
