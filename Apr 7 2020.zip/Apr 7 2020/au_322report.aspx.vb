﻿
Partial Class au_322report
    Inherits System.Web.UI.Page

End Class
