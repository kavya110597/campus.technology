﻿Imports DevExpress.XtraPrinting
Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Data.OleDb

Partial Class au_bos
    Inherits System.Web.UI.Page
    Protected Sub ImageWord_Click(sender As Object, e As ImageClickEventArgs) Handles ImageWord.Click

        ASPxGridViewExporter1.GridViewID = "ASPxGridView1"

        ASPxGridViewExporter1.WriteRtfToResponse()

    End Sub
    Protected Sub ImageExcel_Click(sender As Object, e As ImageClickEventArgs) Handles ImageExcel.Click

        ASPxGridViewExporter1.GridViewID = "ASPxGridView1"

        ASPxGridViewExporter1.WriteXlsxToResponse(New XlsxExportOptionsEx With {.ExportType = DevExpress.Export.ExportType.WYSIWYG})
    End Sub
    Protected Sub ImagePDF_Click(sender As Object, e As ImageClickEventArgs) Handles ImagePDF.Click

        ASPxGridViewExporter1.GridViewID = "ASPxGridView1"

        Dim options As New DevExpress.XtraPrinting.PdfExportOptions

        options.Compressed = False
        ASPxGridViewExporter1.WritePdfToResponse(options)

    End Sub
    Protected Sub BSemExcel_Click(sender As Object, e As EventArgs) Handles BSemExcel.Click
        LSeminar.Text = ""

        If FileUpload1.HasFile Then
            Dim file As HttpPostedFile = FileUpload1.PostedFile
            Dim filesize As Integer = file.ContentLength
            If filesize > 4194304 Then
                LSeminar.Text = "File exceeds the maximum size limit i.e. 4MB"
                LSeminar.ForeColor = System.Drawing.Color.Red
                Exit Sub
            End If
            Dim filename As String = Path.GetFileName(FileUpload1.FileName)
            Dim extension As String = Path.GetExtension(filename)

            If extension <> ".xls" AndAlso extension <> ".xlsx" Then
                LSeminar.Text = "Invalid file extension.Please upload .xls or .xlsx file"
                LSeminar.ForeColor = System.Drawing.Color.Red
                Exit Sub
            End If
            Dim path1 As String = "employee/photos/" & filename
            Dim dir1 As String = Server.MapPath(".") & "\employee\files"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If
            Dim path2 As String = Server.MapPath(".") & "\employee\files\" & filename

            FileUpload1.SaveAs(path2)


            Dim constr1 As String

            constr1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & path2 & ";Extended Properties=""Excel 12.0 Xml;HDR=YES"";"
            Using con1 As New OleDbConnection
                con1.ConnectionString = constr1
                con1.Open()
                Dim cmd1 As New OleDbCommand
                cmd1.Connection = con1
                cmd1.CommandText = "Select * from [Sheet1$]"
                Dim rdr1 As OleDbDataReader = cmd1.ExecuteReader

                Do While rdr1.Read



                    Dim enddate As Date
                    Try
                        enddate = Convert.ToDateTime(rdr1.GetValue(2).ToString)

                    Catch ex As Exception
                        LSeminar.Text = "Invalid Date."
                        LSeminar.ForeColor = System.Drawing.Color.Red
                        Exit Sub
                    End Try
                    If (DateAndTime.Year(enddate)) < 1950 OrElse (DateAndTime.Year(enddate)) > 2020 Then
                        LSeminar.Text = "Invalid Date Range."
                        LSeminar.ForeColor = System.Drawing.Color.Red
                        Exit Sub
                    End If



                    SqlDataSource13.InsertParameters("colid").DefaultValue = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
                    SqlDataSource13.InsertParameters("empid").DefaultValue = Convert.ToInt32(Request.Cookies("nemployeeid").Value.ToString)
                    SqlDataSource13.InsertParameters("AcademicBody").DefaultValue = rdr1.GetValue(0).ToString
                    SqlDataSource13.InsertParameters("Type").DefaultValue = rdr1.GetValue(1).ToString
                    SqlDataSource13.InsertParameters("ParticipationDate").DefaultValue = enddate
                    SqlDataSource13.InsertParameters("InstitutionName").DefaultValue = rdr1.GetValue(3).ToString
                    SqlDataSource13.Insert()

                    ASPxGridView1.DataBind()


                Loop
                rdr1.Close()
                con1.Close()
            End Using

            LSeminar.Text = "Seminar(s) Added."
            LSeminar.ForeColor = System.Drawing.Color.Green
            ASPxGridView1.DataBind()
        Else
            LSeminar.Text = "File is either not Selected or is Empty."
            LSeminar.ForeColor = System.Drawing.Color.Red
            Exit Sub
        End If

    End Sub
End Class
