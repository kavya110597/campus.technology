﻿
Partial Class au_assessmente
    Inherits System.Web.UI.Page

End Class
