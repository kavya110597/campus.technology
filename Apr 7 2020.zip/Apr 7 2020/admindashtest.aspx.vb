﻿
Partial Class admindashtest
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub
    <System.Web.Services.WebMethod>
    Public Shared Function CheckDateTime(ByVal args As String) As String
        Dim cs1 As New schoolclass1

        Return args + " Current Datetime is " + DateTime.Now.ToString("dd/MMM/yyyy HH:mm:ss")

    End Function

End Class
