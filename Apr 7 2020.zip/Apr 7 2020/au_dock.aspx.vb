﻿
Partial Class au_dock
    Inherits System.Web.UI.Page

    Protected Sub ASPxDockPanel1_AfterDock(sender As Object, e As EventArgs) Handles ASPxDockPanel1.AfterDock
        Dim p1 As Panel = CType(ASPxDockPanel1.FindControl("Panel1"), Panel)
        Dim p2 As Panel = CType(ASPxDockPanel1.FindControl("Panel2"), Panel)
        p1.Visible = False
        p2.Visible = True

    End Sub
    Protected Sub ASPxDockPanel1_AfterFloat(sender As Object, e As EventArgs) Handles ASPxDockPanel1.AfterFloat
        Dim p1 As Panel = CType(ASPxDockPanel1.FindControl("Panel1"), Panel)
        Dim p2 As Panel = CType(ASPxDockPanel1.FindControl("Panel2"), Panel)
        p1.Visible = True
        p2.Visible = False
        ASPxDockPanel1.Width = 32
        ASPxDockPanel1.Height = 32

    End Sub
    Protected Sub ASPxDockPanel2_AfterDock(sender As Object, e As EventArgs) Handles ASPxDockPanel2.AfterDock
        Dim p1 As Panel = CType(ASPxDockPanel2.FindControl("Panel3"), Panel)
        Dim p2 As Panel = CType(ASPxDockPanel2.FindControl("Panel4"), Panel)
        p1.Visible = False
        p2.Visible = True
    End Sub
    Protected Sub ASPxDockPanel2_AfterFloat(sender As Object, e As EventArgs) Handles ASPxDockPanel2.AfterFloat
        Dim p1 As Panel = CType(ASPxDockPanel2.FindControl("Panel3"), Panel)
        Dim p2 As Panel = CType(ASPxDockPanel2.FindControl("Panel4"), Panel)
        p1.Visible = True
        p2.Visible = False
        ASPxDockPanel2.Width = 32
        ASPxDockPanel2.Height = 32
    End Sub
End Class
