﻿
Partial Class au_course_mcq_summary
    Inherits System.Web.UI.Page

End Class
