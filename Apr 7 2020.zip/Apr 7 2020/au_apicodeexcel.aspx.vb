﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Data.OleDb
Imports System.Drawing
Partial Class au_apicodeexcel
    Inherits System.Web.UI.Page
    Protected Sub BSemExcel_Click(sender As Object, e As EventArgs) Handles BSemExcel.Click
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try

        'If RadComboBox1.SelectedItem Is Nothing AndAlso [String].IsNullOrWhiteSpace(RadComboBox1.SelectedItem.Text) Then
        '    LSeminar.Text = "Select MCQ"
        '    LSeminar.ForeColor = Drawing.Color.Red
        '    Exit Sub
        'End If
        LSeminar.Text = ""
        If FileUpload1.HasFile Then
            Dim file As HttpPostedFile = FileUpload1.PostedFile
            Dim filesize As Integer = file.ContentLength
            If filesize > 4194304 Then
                LSeminar.Text = "File exceeds the maximum size limit i.e. 4MB"
                LSeminar.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim filename As String = Path.GetFileName(FileUpload1.FileName)
            Dim extension As String = Path.GetExtension(filename)

            If extension <> ".xls" AndAlso extension <> ".xlsx" Then
                LSeminar.Text = "Invalid file extension.Please upload .xls or .xlsx file"
                LSeminar.ForeColor = Drawing.Color.Red
                Exit Sub
            End If
            Dim path1 As String = "employee/photos/" & filename
            Dim dir1 As String = Server.MapPath(".") & "\employee\files"
            If My.Computer.FileSystem.DirectoryExists(dir1) = False Then
                My.Computer.FileSystem.CreateDirectory(dir1)
            End If
            Dim path2 As String = Server.MapPath(".") & "\employee\files\" & filename

            FileUpload1.SaveAs(path2)


            Dim constr1 As String

            constr1 = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & path2 & ";Extended Properties=""Excel 12.0 Xml;HDR=YES"";"
            Using con1 As New OleDbConnection
                con1.ConnectionString = constr1
                con1.Open()
                Dim cmd1 As New OleDbCommand
                cmd1.Connection = con1
                cmd1.CommandText = "Select * from [Sheet1$]"
                Dim rdr1 As OleDbDataReader = cmd1.ExecuteReader

                Do While rdr1.Read



                    SqlDataSource2.InsertParameters("colid").DefaultValue = colid
                    SqlDataSource2.InsertParameters("code").DefaultValue = rdr1.GetValue(0).ToString
                    SqlDataSource2.InsertParameters("title").DefaultValue = rdr1.GetValue(1).ToString
                    SqlDataSource2.Insert()

                    ASPxGridView1.DataBind()


                Loop
                rdr1.Close()
                con1.Close()
            End Using

            LSeminar.Text = "Details Added."
            LSeminar.ForeColor = Drawing.Color.Green
            ASPxGridView1.DataBind()
        Else
            LSeminar.Text = "File is either not Selected or is Empty."
            LSeminar.ForeColor = Drawing.Color.Red
            Exit Sub
        End If

    End Sub
End Class


