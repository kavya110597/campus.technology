﻿
Partial Class adminmaster_f_0
    Inherits System.Web.UI.MasterPage
End Class

