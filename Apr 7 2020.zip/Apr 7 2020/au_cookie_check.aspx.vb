﻿
Partial Class au_cookie_check
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        Literal1.Text = Session("colid").ToString & "-" & Request.Cookies("colid").Value.ToString

    End Sub
End Class
