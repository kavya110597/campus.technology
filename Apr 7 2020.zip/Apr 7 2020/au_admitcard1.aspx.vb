﻿Imports System.Data.SqlClient
Partial Class faculty_au_admitcard1
    Inherits System.Web.UI.Page
    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim colid As Integer
        Try
            colid = Convert.ToInt32(Request.Cookies("colid").Value.ToString)
        Catch ex As Exception
            Response.Redirect("facultylogin.aspx")
        End Try
        Label1.Text = ""
        If TextBox1.Text = "" Then
            Label1.Text = "Please Enter Enrollment Number"
            Label1.ForeColor = System.Drawing.Color.Red
            Exit Sub
        End If

        Dim enroll_no As String = TextBox1.Text
        Dim ret1 As String = loadgridview1(enroll_no)
        Dim array1 As String() = ret1.Split("~")

        If array1(0).ToString() = "" Then
            Label1.Text = "Entered Enrollment Number doesn't exist in database"
            Label1.ForeColor = System.Drawing.Color.Red
            Exit Sub
        End If

        Dim studid As Integer = Convert.ToInt32(array1(0).ToString())
        Dim studentname As String = array1(1).ToString()



        HyperLink1.NavigateUrl = "https://www.campus.technology/erpnew/faculty/admitcardview.aspx?studid=" & studid & "&studentname=" & studentname
        HyperLink1.Text = "https://www.campus.technology/erpnew/faculty/admitcardview.aspx?studid=" & studid & "&studentname=" & studentname

    End Sub
    Public Function loadgridview1(ByVal enroll_no As String) As String
        Dim ret1 As String

        Dim constr1 As String
        constr1 = ConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString

        Using con1 As New SqlConnection
            con1.ConnectionString = constr1
            con1.Open()
            Dim cmd1 As New SqlCommand
            cmd1.Connection = con1
            cmd1.CommandText = "Select id, studentname from au_studentadmitcard where enroll_no='" & enroll_no & "'"
            Dim rdr1 As SqlDataReader = cmd1.ExecuteReader
            Do While rdr1.Read
                ret1 = rdr1.GetValue(0).ToString & "~" & rdr1.GetValue(1).ToString


            Loop
            rdr1.Close()
            con1.Close()
        End Using
        Return ret1

    End Function
End Class