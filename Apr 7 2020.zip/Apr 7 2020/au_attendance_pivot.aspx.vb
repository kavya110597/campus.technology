﻿
Partial Class au_attendance_pivot
    Inherits System.Web.UI.Page

End Class
