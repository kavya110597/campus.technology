﻿
Partial Class au_ename
    Inherits System.Web.UI.Page

End Class
