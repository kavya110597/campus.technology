﻿
Partial Class au_assignment_edit
    Inherits System.Web.UI.Page

End Class
