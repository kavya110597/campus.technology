﻿
Partial Class au_cbcs_pivot1
    Inherits System.Web.UI.Page

End Class
