﻿
Partial Class au_att_sup_pc_admin
    Inherits System.Web.UI.Page

End Class
